import re
import traceback
from typing import NamedTuple

from ptw.libraries import apis
from ptw.libraries import control
from ptw.libraries import log_utils
from ptw.libraries import cache


class MediaLanguageDetails(NamedTuple):
    english_translated_result: dict
    original_title: str
    title: str
    original_name: str
    # english_name: str


class Crew(NamedTuple):
    writer: str
    director: str


class MediaItem:
    def __init__(self):
        self._item = {}

    def __setattr__(self, key, value):
        if key.startswith('_'):
            super().__setattr__(key, value)  # lub object.__setattr__(self, key, value)
        else:
            self._item[key] = value

    def __getattr__(self, key):
        return self._item.get(key, "")

    @property
    def item(self):
        return self._item

    @item.deleter
    def item(self):
        print("Delete item")
        del self._item



class SuperInfo:
    def __init__(self, media_list, session, lang="en", content_type='movie'):
        self.meta = []
        self.media_item = MediaItem()
        self.lang = lang
        self.content_type = content_type
        self.media_list = media_list
        self.session = session
        self.tm_user = control.setting("tm.user") or apis.tmdb_API

        self.quality = control.setting("image.quality")
        if self.quality == "0":
            self.qualityp = "w500"
            self.qualityf = "w780"
        elif self.quality == "1":
            self.qualityp = "w780"
            self.qualityf = "w1280"
        elif self.quality == "2":
            self.qualityp = "w780"
            self.qualityf = "original"

        self.fanartby = control.setting("image.fanartby")
        if self.fanartby == "0":
            self.fanartby = "vote_average"
        elif self.fanartby == "1":
            self.fanartby = "vote_count"
        self.posterby = control.setting("image.posterby")
        if self.posterby == "0":
            self.posterby = "vote_average"
        elif self.posterby == "1":
            self.posterby = "vote_count"

        self.user = str(control.setting("fanart.tv.user")) + str(control.setting("tm.user"))

        self.tmdb_by_imdb = f"https://api.themoviedb.org/3/find/%s?api_key={self.tm_user}&external_source=imdb_id"
        self.tmdb_api_link_movies = f"https://api.themoviedb.org/3/movie/%s?api_key={self.tm_user}&language={self.lang}&append_to_response=credits,external_ids,release_dates"
        self.tmdb_api_link_tvshows = f"https://api.themoviedb.org/3/tv/%s?api_key={self.tm_user}&language={self.lang}&append_to_response=credits,external_ids,release_dates"
        self.tm_img_link = "https://image.tmdb.org/t/p/w%s%s"
        self.tmdb_arts_movies = f"https://api.themoviedb.org/3/movie/%s/images?api_key={self.tm_user}"
        self.tmdb_arts_tvshows = f"https://api.themoviedb.org/3/tv/%s/images?api_key={self.tm_user}"
        self.tmdb_providers_movies = f"https://api.themoviedb.org/3/movie/%s/watch/providers?api_key={self.tm_user}"
        self.tmdb_providers_tvshows = f"https://api.themoviedb.org/3/tv/%s/watch/providers?api_key={self.tm_user}"

        self.my_language_order = []


    def get_info(self, i):
        try:
            self.media_item.next = self.media_list[i].get("next")

            imdb = self.media_list[i].get("imdb", "") if self.media_list[i].get("imdb", "") != "0" else ""
            self.media_item.imdb = imdb

            tmdb = self.media_list[i].get("tmdb", "") if self.media_list[i].get("tmdb", "") != "0" else ""
            self.media_item.tmdb = tmdb

            list_title = self.media_list[i].get("title")

            media_id = self.get_media_id(tmdb, imdb)  # ustalenie id: imdb lub tmdb

            tmdb_media_item_response = self.get_tmdb_api_item(media_id)  # pobranie z serwera

            if tmdb_media_item_response.get("success", False):  # jeśli błąd, to koniec
                return
            
            if not list_title:
                list_title = tmdb_media_item_response.get("title")

            original_language = tmdb_media_item_response.get("original_language", "")

            # Lista pasujących języków, wraz z `None`, bo czasem w JSON jest: "iso_639_1":null.
            self.my_language_order = [self.lang, "en", original_language, "00", "", None]

            if not imdb:
                imdb = self.media_item.imdb = tmdb_media_item_response.get("external_ids", {}).get("imdb_id", "")

            if not tmdb:
                tmdb = self.media_item.tmdb

            #media_titles = self.get_media_titles(list_title, tmdb_media_item_response, original_language, list_title)
            media_titles = self.get_media_titles(tmdb_media_item_response, original_language, list_title)

            plot = tmdb_media_item_response.get("overview", self.media_list[i].get("plot", ""))
            tagline = tmdb_media_item_response.get("tagline", "")
            if self.lang != "en":
                if not plot:
                    plot = media_titles.english_translated_result.get("overview", "")
                if not tagline:
                    en_tagline = media_titles.english_translated_result.get("tagline", "")
                    if en_tagline:
                        tagline = en_tagline
            self.media_item.plot = plot
            self.media_item.tagline = tagline

            premiered = tmdb_media_item_response.get("release_date", "") or tmdb_media_item_response.get("first_air_date", "")
            self.media_item.premiered = premiered
            match = re.search(r"(\d{4})", premiered)
            _year = match.group() if match else self.media_list[i].get("year")
            year = tmdb_media_item_response.get("year", _year)
            self.media_item.year = year

            mpaa = ", ".join(set(cert
                                 for it in tmdb_media_item_response.get("release_dates", {}).get("results", [])
                                 if it.get("iso_3166_1") in ("US", "PL")
                                 for rel in it.get("release_dates", [])
                                 for cert in (rel.get("certification"),) if cert))
            if mpaa:
                self.media_item.mpaa = mpaa

            status = tmdb_media_item_response.get("status") or ""
            self.media_item.status = status

            studio = tmdb_media_item_response.get("production_companies")
            studio = studio[0].get("name") if studio else ""
            self.media_item.studio = studio

            genre = tmdb_media_item_response.get("genres")
            genre = " / ".join([d["name"] for d in genre]) if genre else ""
            self.media_item.genre = genre

            country = tmdb_media_item_response.get("production_countries")
            country = " / ".join([c["name"] for c in country]) if country else ""
            self.media_item.country = country

            duration = str(tmdb_media_item_response.get("runtime", ""))
            self.media_item.duration = duration

            self.media_item.rating = tmdb_media_item_response.get("vote_average", -1.0)
            self.media_item.votes = tmdb_media_item_response.get("vote_count", -1.0)

            self.get_cast_with_thumbnail(tmdb_media_item_response)

            self.get_writer_and_director(tmdb_media_item_response)

            arts = self.get_arts(tmdb, imdb)

            self.get_best_poster(i, arts)
            self.get_best_landscape(tmdb_media_item_response, arts)
            self.get_best_fanart(tmdb_media_item_response, arts)

            self.get_other_arts()  # banner, clearlogo, clearart, discart

            self.get_providers(tmdb, imdb)

            tmdb_media_item_response = {k: v for k, v in self.media_item.item.items()}
            self.media_list[i].update(tmdb_media_item_response)

            kopia_mir = tmdb_media_item_response.copy()
            kopia_mir.pop("next", None)
            cache.cache_insert("superinfo" + f"_{imdb or tmdb}", repr(kopia_mir))

            meta = {"imdb": imdb, "tmdb": tmdb, "tvdb": "", "lang": self.lang, "user": self.user, "item": tmdb_media_item_response}
            self.meta.append(meta)

        except Exception as e:
            print(traceback.format_exc())
            pass


    def get_media_id(self, tmdb_id, imdb_id):
        if not tmdb_id and imdb_id:
            try:
                url = self.tmdb_by_imdb % imdb_id
                result = self.session.get(url, timeout=16).json()

                if self.content_type == "movie":
                    result = result.get("movie_results", [])[0]
                elif self.content_type == "tvshow" or self.content_type == "tv":
                    result = result.get("tv_results", [])[0]

                tmdb_id = str(result.get("id", ""))
                if tmdb_id:
                    self.media_item.tmdb = tmdb_id
            except Exception:
                pass
        media_id = tmdb_id or imdb_id
        if not media_id:
            raise Exception("Media id not found")
        return media_id


    def get_best_poster(self, i, arts):
        posters = [{"url": self.media_list[i].get("poster", ""), "priority": 2, "lang": ""}]
        _poster2 = self.get_best_image(arts["posters"], "iso_639_1", self.posterby)

        if isinstance(_poster2, dict):
            posters.append({"url": f"https://image.tmdb.org/t/p/{self.qualityp}{_poster2['file_path']}", "priority": 1,
                            "lang": _poster2["iso_639_1"]})
        if isinstance(_poster2, str):
            posters.append({"url": f"https://image.tmdb.org/t/p/{self.qualityp}{_poster2}", "priority": 1, "lang": ""})

        if posters:
            best_poster = min(posters, key=lambda x: x['priority']).get("url")
        else:
            best_poster = None

        self.media_item.poster = best_poster
        return best_poster


    def _get_best_landscape(self, tmdb_media_item_response, arts, *, no_lang: bool):
        fan_arts = []
        _fan_art2 = self.get_best_image(arts["backdrops"], "iso_639_1", self.fanartby, no_lang=no_lang)

        if isinstance(_fan_art2, dict):
            fan_arts.append({"url": f"https://image.tmdb.org/t/p/{self.qualityf}{_fan_art2['file_path']}", "priority": 1,
                             "lang": _fan_art2["iso_639_1"]})
        if isinstance(_fan_art2, str):
            fan_arts.append({"url": f"https://image.tmdb.org/t/p/{self.qualityf}{_fan_art2}", "priority": 1, "lang": ""})
        fan_art = tmdb_media_item_response.get("backdrop_path")
        fan_arts.append(
            {"url": self.tm_img_link % ("1920", tmdb_media_item_response.get("backdrop_path")), "priority": 2,
             "lang": ""}) if fan_art else ""

        if fan_arts:
            return min(fan_arts, key=lambda x: x['priority']).get("url")
        return None


    def get_best_fanart(self, tmdb_media_item_response, arts):
        art = self._get_best_landscape(tmdb_media_item_response, arts, no_lang=True)
        self.media_item.fanart = art
        return art


    def get_best_landscape(self, tmdb_media_item_response, arts):
        art = self._get_best_landscape(tmdb_media_item_response, arts, no_lang=False)
        self.media_item.landscape = art
        return art


    def get_other_arts(self):
        banner = clearlogo = clearart = discart = ""
        #self.media_item.banne = banner
        self.media_item.banner = banner
        self.media_item.clearlogo = clearlogo
        self.media_item.clearart = clearart
        self.media_item.discart = discart
        return banner, clearlogo, clearart, discart


    def get_tmdb_api_item(self, media_id):  # pobiera informacje o filmie bądź serialu
        # ustalenie adresu url
        if self.content_type == 'movie':
            en_url = self.tmdb_api_link_movies % media_id
        elif self.content_type == 'tvshow' or self.content_type == "tv":
            en_url = self.tmdb_api_link_tvshows % media_id
        f_url = f"{en_url},translations"
        url = en_url if self.lang == "en" else f_url

        r = self.session.get(url, timeout=10)  # zapytanie do serwera

        r.encoding = "utf-8"
        return r.json()


    # def get_media_titles(self, title_from_list, tmdb_media_item_response, original_language, list_title) -> MediaLanguageDetails:
    def get_media_titles(self, tmdb_media_item_response, original_language, list_title) -> MediaLanguageDetails:
    
        try:
            if self.lang == "en":
                english_translated_result = None
            else:
                english_translated_result = next(
                    (x["data"] for x in tmdb_media_item_response.get("translations", {}).get("translations", {}) if
                     x.get("iso_639_1") == "en"), {})

            name = tmdb_media_item_response.get("title", "")  # tłumaczenie na lokalny język interfejsu (czyli na 99% polski)
            if not name:
                name = tmdb_media_item_response.get("name", "")

            original_name = tmdb_media_item_response.get("original_title", "")  # tytuł oryginalny
            if not original_name:
                original_name = tmdb_media_item_response.get("original_name", "")

            en_trans_name = (english_translated_result.get("title", "") if not self.lang == "en" else None)  # angielski tytuł
            if not en_trans_name:
                en_trans_name = (english_translated_result.get("name", "") if not self.lang == "en" else None)

            if self.lang == "en":
                original_title = title = name
            elif self.lang == original_language:
                original_title = original_name
                title = name
            else:
                original_title = en_trans_name or original_name  # dlatego przeważnie ląduje tu angielski tytuł
                if name == original_name and en_trans_name:
                    title = en_trans_name
                else:
                    title = name

            self.media_item.title = title
            self.media_item.originaltitle = original_title  # a powinno być original_name
            self.media_item.label = title
            self.media_item.originalname = original_name  # nie ma takiego pola w ListItem
            # self.media_item.englishtitle = en_trans_name  # nieprzetestowane jeszcze
            # self.media_item.originaltitle = original_name

            # log_utils.fflog(f"\n {english_translated_result=} \n {original_title=} {title=} {original_name=} \n ({name=} {en_trans_name=})", 1)
            # log_utils.fflog(f"prawidłowo powinno być (standard ListItem): {title=} {original_name=} ({en_trans_name=})  |  {original_title=} {name=} {english_translated_result=}", 1)
            # log_utils.fflog(f"do wyszukiwarki źródeł powinno lecieć: {en_trans_name=} {name=} {original_name=}" ,1)
            #return MediaLanguageDetails(english_translated_result, original_title, title)
            return MediaLanguageDetails(english_translated_result, original_title, title, original_name)
        except Exception:
            #return MediaLanguageDetails({}, list_title, list_title)
            return MediaLanguageDetails({}, list_title, list_title, list_title)


    def get_best_image(self, images, lang_key, vote_key=None, size_key=None, *, no_lang: bool = False):
        """Get best image from `images` by `*_key` keys, matching to languages."""

        # Brak danych.
        if not images:
            return

        # Kolejnośc jezyków, z uwzględnieniem wymuszenia braku języka (przydatne dla fanart)
        if no_lang:
            my_language_order = (None, False, "", "00", *self.my_language_order)
        else:
            my_language_order = self.my_language_order

        # Przeglądając **po kolei** jezyki sortujemy po głosowaniu i wielkości (o ile klucze podane)
        best = [img for lang in my_language_order
                for img in sorted((img for img in reversed(images) if img[lang_key] == lang),
                                  key=lambda im: (vote_key and -im[vote_key], size_key and -im[size_key],))]

        # Obrazek pasujący, lub jakikolwiek.
        if best:
            return best[0]
        return images[0]


    def get_cast_with_thumbnail(self, media_item):
        cast_with_thumb = []
        cast = media_item.get("credits", {}).get("cast")
        cast = cast[:30] if cast else None
        if cast:
            for person in cast:
                _icon = person.get("profile_path")
                icon = self.tm_img_link % ("185", _icon) if _icon else ""
                cast_with_thumb.append(
                    {"name": person.get("name", ""), "role": person.get("character", ""), "thumbnail": icon, })

        if not cast_with_thumb:
            cast_with_thumb = ""

        self.media_item.castwiththumb = cast_with_thumb
        return cast_with_thumb


    def get_arts(self, tmdb, imdb):
        media_id = tmdb if tmdb else imdb
        if self.content_type == "movie":
            arts_url = self.tmdb_arts_movies % media_id
        elif self.content_type == "tvshow" or self.content_type == "tv":
            arts_url = self.tmdb_arts_tvshows % media_id
        result = self.session.get(arts_url, timeout=10)
        result.raise_for_status()
        result.encoding = "utf-8"
        return result.json()


    def get_providers(self, tmdb, imdb):
        media_id = tmdb if tmdb else imdb
        if self.content_type == "movie":
            result = self.session.get(self.tmdb_providers_movies % media_id, timeout=10)
        if self.content_type == "tvshow" or self.content_type == "tv":
            result = self.session.get(self.tmdb_providers_tvshows % media_id, timeout=10)
        result.raise_for_status()
        result.encoding = "utf-8"
        provider = result.json()

        providers_results = provider.get("results")
        providers_link = providers_results.get(self.lang.upper(), {}).get("link", "") if providers_results else ""
        providers_list = [i.get("provider_name", "") for i in
                          providers_results.get(self.lang.upper(), {}).get("flatrate", [])]
        if providers_link:
            providers = {"link": providers_link, "provider_list": providers_list}
            self.media_item.__setattr__("providers", providers)
            return providers
        else:
            self.media_item.__setattr__("providers", "")
            return ""


    def get_writer_and_director(self, media_item) -> Crew:
        crew = media_item.get("credits", {}).get("crew")
        if crew:
            director_jobs = []
            for x in crew:
                if x.get("job") == "Director":
                    director_jobs.append(x)
            director_name = []
            for d in director_jobs:
                director_name.append(d.get("name", ""))
            director = ", ".join(director_name)

            writer_jobs = []
            for y in crew:
                if y.get("job") in ["Writer", "Screenplay", "Author", "Novel"]:
                    writer_jobs.append(y)

            writer_name = []
            for w in writer_jobs:
                writer_name.append(w.get("name", ""))
            writer = ", ".join(writer_name)
        else:
            director = writer = ""

        self.media_item.__setattr__("director", director)
        self.media_item.__setattr__("writer", writer)
        return Crew(writer, director)
