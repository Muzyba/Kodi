Kodi Karaoke FREE
Version 1.0.0
Notes by MRFIXIT2001

The original Kodi Karaoke addon seems to be abandoned - it didn't work with Matrix (v19) and the .com expired.

But I really like this addon, so I've redeveloped it to work again. Most of the original source has
been retained, but it had a lot of problems. I've fixed as many as I could find and it's working
well for me at this point. I removed the link to all paid services as well, since the .com expired
and that was used to validate user accounts and enable things.

I have completely ignored the old paid feature that included sunflykaraoke integration. It's not
really needed for this addon to function, and that code is messy.

The author is not responsible for the use of this addon. The author is not responsible for the content found using this addon. The author does not host or own any content found within this addon. The author is in no way affiliated with Kodi, Team Kodi, or the XBMC Foundation. This is a Non-profit resource, organized solely for educational purposes which is protected under the Fair-Use doctrine of the Copyright Act, Specifically section 107, which does promote freedom of expression, by permitting the unlicensed use of copyright-protected works.
