# try:
#     import cfscrape
#     cfScraper = cfscrape.create_scraper()
# except:
#     pass
