# -*- coding: utf-8 -*-

"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import json
import re
import sys
from xbmcplugin import setResolvedUrl
from lib.ff import client
from lib.ff import control
from lib.ff.youtube_search import YoutubeSearch


class trailer:
    def __init__(self):
        self.youtube_watch = "https://www.youtube.com/watch?v=%s"

    def play(self, name="", url="", windowedtrailer=0):
        try:
            # Przygotuj URL dla traileru.
            url = self.worker(name, url)
            if not url:
                return

            # Pobierz informacje o elemencie.
            title = control.infoLabel("ListItem.Title") or control.infoLabel("ListItem.Label")
            icon = control.infoLabel("ListItem.Icon")

            # Ustaw atrybuty dla elementu.
            item = control.item(label=name, path=url)
            item.setArt({"thumb": icon, "icon": icon})
            item.getVideoInfoTag().setTitle(name)

            item.setProperty("IsPlayable", "true")

            # Rozpocznij odtwarzanie trailera.
            setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=item)

            # Kontrola odtwarzania trailera w trybie okienkowym.
            if windowedtrailer == 1:
                control.sleep(1000)
                while control.player.isPlayingVideo():
                    control.sleep(1000)
                control.execute("Dialog.Close(%s, true)" % control.getCurrentDialogId)
        except:
            pass

    def worker(self, name, url):
        # Przygotuj zapytanie do wyszukiwarki Youtube.
        query = name + " trailer"
        return self.search(query)

    def search(self, url):
        try:
            # Pobierz wyniki wyszukiwania z Youtube.
            results = json.loads(YoutubeSearch(url, max_results=1).to_json())
            url = self.resolve(results["videos"][0]["id"])
            if url:
                return url
        except:
            return

    def resolve(self, url):
        try:
            # Przetworz URL do odtworzenia trailera na Youtube.
            id = url.split("?v=")[-1].split("/")[-1].split("?")[0].split("&")[0]
            result = client.request(self.youtube_watch % id)

            message = "".join(client.parseDOM(result, "div", attrs={"id": "unavailable-submessage"}))
            alert = client.parseDOM(result, "div", attrs={"id": "watch7-notification-area"})

            # Sprawdź, czy trailer jest dostępny do odtworzenia.
            if len(alert) > 0 or re.search("[a-zA-Z]", message):
                raise Exception()

            url = "plugin://plugin.video.youtube/play/?video_id=%s" % id
            return url
        except:
            return
