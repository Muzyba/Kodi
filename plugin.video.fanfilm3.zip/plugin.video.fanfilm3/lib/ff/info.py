"""Tiny TheMovieDB.org API getter."""

from typing import Optional, Union, Any, Tuple, List, Dict, Set, Sequence, Mapping, Iterable, Iterator, Callable, NamedTuple
from typing import overload, TYPE_CHECKING
from typing_extensions import get_args as get_typing_args, Literal
from enum import Enum
from time import time as cur_time
from datetime import datetime, date as dt_date
import json
from ..api.tmdb import TmdbApi, TmdbCredentials, TmdbItemJson, ExternalIdType, DetailsAllowed
from ..api.trakt import TraktApi
from ..defs import MediaRef, MediaProgress, MediaProgressItem, NextWatchPolicy, VideoIds, Pagina, ItemList
from . import apis
from .types import JsonData
from .settings import settings
from .locales import country_translations
from .calendar import fromisoformat
from .item import FFItem, FFItemDict, FFActor
from .db.playback import get_playback, get_playback_info, MediaPlayInfo, MediaPlayInfoDict
from .db.media import find_media_info, get_media_info, set_media_info, MediaInfoRow
from .tmdb import tmdb as tmdb_provider
from .art import Art
from .trakt2 import trakt as trakt_provider, Trakt
from .tricks import pairwise, AlwaysFalse
from ..service.kodidb import video_db, KodiVideoInfo
from ..service.client import service_client
from ..kolang import KodiLabels
# from .calendar import fromisoformat
from .log_utils import fflog, fflog_exc
from .debug import logtime
try:
    from .control import apiLanguage
except ImportError:
    def apiLanguage():
        return {'tmdb': 'pl-PL'}
from const import const
if TYPE_CHECKING:
    from ..indexers.defs import CodeId


def tmdb_locale() -> str:
    """Get user locale (language)."""
    return apiLanguage().get('tmdb', 'pl-PL')


class Credits(NamedTuple):
    actors: List[FFActor]
    directors: List[str]
    writers: List[str]
    crew: Tuple[FFActor, ...] = ()


class MyTmdb(TmdbApi):
    """API for themoviedb.org."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)

    def credentials(self) -> TmdbCredentials:
        """Return current credencials."""
        api_key: str = const.dev.tmdb.api_key or settings.getString("tmdb.api_key") or apis.tmdb_API
        return TmdbCredentials(api_key=api_key)


class Progress(Enum):
    """FFItem progress mode."""
    NO = 'no'
    BASIC = 'basic'
    FULL = 'full'


class ProgressBarMode(Enum):
    """FFItem progress bar mode."""
    #: Do not show progressbar at all.
    NONE = 'none'
    #: Show video percent progress (PERCENT) if video progress >0% and < 100% else show nothing.
    WATCHING = 'watching'
    #: Show only watched videos (movies and episodes progresses are skiped).
    WATCHED = 'watched'
    #: Show video percent progress.
    PERCENT = 'percent'
    #: Show video percent progress and watched in background (use const.indexer.progressbar.watched.*).
    PERCENT_AND_WATCHED = 'percent_and_watched'


"""Object to mark already watched progress in progreassbar."""
AREADY_WATCHED = AlwaysFalse()


class InfoProvider:
    """Media info provider."""

    # Must be supported by TMDB API get_temss() to mark as broken.
    _supported_details_types = {'movie', 'show', 'season', 'episode', 'person', 'collection'}

    Progress = Progress

    # All language aliases
    LANGUAGE_ALIASES: Dict[str, Sequence[str]] = {lng: alias for alias in const.tmdb.language_aliases for lng in alias}

    # Field names in translation object.
    TRANSLATE_FILEDS: Iterable[str] = ('homepage', 'overview', 'runtime', 'tagline', 'title')

    def __init__(self, tmdb: Optional[TmdbApi] = None, trakt: Union[None, Trakt, TraktApi] = None) -> None:
        if tmdb is None:
            if trakt is not None and hasattr(trakt, 'tmdb'):
                tmdb = trakt.tmdb
            else:
                lang: str = tmdb_locale()
                tmdb = MyTmdb(lang=lang)

        self.tmdb: TmdbApi = tmdb
        self.trakt: Optional[TraktApi] = trakt
        #: Lazy loaded trakt playback progress.
        self._trakt_playback: Optional[MediaPlayInfoDict] = None
        #: Lazy loaded kodi playback progress.
        self._kodi_playback: Optional[List[KodiVideoInfo]] = None
        #: API locale labels
        self.api_labels: KodiLabels = KodiLabels(tmdb_locale())
        #: Art services
        self.art = Art()

    def reset(self) -> None:
        """Reset settings to obtain settings change."""
        # Forget current language, will be taken from settings (api.language).
        self.tmdb.lang = tmdb_locale()
        self.api_labels.set_locale(self.tmdb.lang)
        self.art.reset()

    def parse_credits(self, item: TmdbItemJson, *, limit: Optional[int] = None) -> Credits:
        """Parse movie/show/season/episode credits (cast and crew)."""

        def make_img(person: JsonData) -> str:
            img = person.get('profile_path')
            if img:
                img = f'{iurl}{img}'
            return img or ''

        def make_actor(persons: List[JsonData], i: int = -1) -> Iterator[FFActor]:
            for p in persons:
                # TODO: id, gender, popularity
                yield FFActor(name=p['name'], role=p.get('character'), order=p.get('order', i), thumbnail=make_img(p),
                              dbid=VideoIds.dbid_from_tmdb(p))

        def make_crew_name(persons: List[JsonData], jobs: Set[str]) -> Iterator[str]:
            for p in persons:
                if p.get('job') in jobs:
                    # TODO: id, gender, popularity, job, department
                    yield p['name']

        def make_crew(persons: List[JsonData]) -> Iterator[FFActor]:
            for i, p in enumerate(persons):
                # TODO: id, gender, popularity, job, department
                yield FFActor(name=p['name'], role=p.get('job'), order=p.get('order', i), thumbnail=make_img(p),
                              dbid=VideoIds.dbid_from_tmdb(p))

        def make_agg_actor(persons: List[JsonData]) -> Iterator[FFActor]:
            for i, p in enumerate(persons):
                # TODO: id, gender, popularity
                character = ', '.join(ch for r in p.get('roles', ()) for ch in (r.get('character'),) if ch)
                yield FFActor(name=p['name'], role=character, order=p.get('order', i), thumbnail=make_img(p),
                              dbid=VideoIds.dbid_from_tmdb(p))

        def make_agg_crew_name(persons: List[JsonData], jobs: Set[str]) -> Iterator[str]:
            for p in persons:
                for job in p.get('jobs', ()):
                    # TODO: id, gender, popularity, job, department
                    if job['job'] in jobs:
                        yield p['name']

        def make_agg_crew(persons: List[JsonData]) -> Iterator[FFActor]:
            for i, p in enumerate(persons):
                for job in p.get('jobs', ()):
                    # TODO: id, gender, popularity, job, department
                    if isinstance(job, Mapping):
                        job = job.get('job')
                    if isinstance(job, str):
                        yield FFActor(name=p['name'], role=job, order=p.get('order', i), thumbnail=make_img(p),
                                      dbid=VideoIds.dbid_from_tmdb(p))

        if limit is None:
            limit = settings.getInt('actor_count_limit')
        no_limit = 10**9
        if not limit:
            limit = no_limit
        iurl = self.tmdb.person_image_url
        dir_jobs = {'Director'}
        wr_jobs = {'Writer', 'Staff Writer', 'Story'}
        # TODO: parse "guest_stars" ?
        crew = ()
        if 'aggregate_credits' in item:
            credits = item['aggregate_credits']
            actors = make_agg_actor(credits.get('cast', ()))
            directors = make_agg_crew_name(credits.get('crew', ()), dir_jobs)
            writers = make_agg_crew_name(credits.get('crew', ()), wr_jobs)
            if limit >= no_limit:
                crew = make_agg_crew(credits.get('crew', ()))
        else:
            credits = item.get('credits', {})
            actors = make_actor(credits.get('cast', ()))
            directors = make_crew_name(credits.get('crew', ()), dir_jobs)
            writers = make_crew_name(credits.get('crew', ()), wr_jobs)
            if limit >= no_limit:
                crew = make_crew(credits.get('crew', ()))
        actors = list({a.getName(): a for a in actors}.values())
        directors = list(dict.fromkeys(directors))
        writers = list(dict.fromkeys(writers))
        crew = tuple(dict.fromkeys(crew))
        if limit:
            actors, directors, writers = actors[:limit], directors[:limit], writers[:limit]
        return Credits(actors=actors, directors=directors, writers=writers, crew=crew)

    def parse_tmdb_item(self,
                        item: TmdbItemJson,
                        *,
                        locale: Optional[str] = None,
                        limit: Optional[int] = None,
                        ) -> Optional[FFItem]:
        """Parse single movie/show/season/episode data."""

        def dget(dct: Dict, key: str, default: Any = None) -> Any:
            keys = key.split('/')
            for key in keys[:-1]:
                dct = dct.get(key, {})
            return dct.get(keys[-1], default)

        def set_if(meth: Callable, *keys: str) -> None:
            for data in (item, en_translation, orig_translation):
                for key in keys:
                    value = dget(data, key)
                    if value:
                        meth(value)
                        return

        def set_dt_if(meth: Callable, value: str, fmt: str = '%Y-%m-%d') -> None:
            if value:
                try:
                    dt = fromisoformat(value)
                except ValueError:
                    pass
                else:
                    meth(dt)

        def translate(*keys:
                      Literal['title', 'name', 'tagline', 'overview'],
                      default: str = '',
                      order: Optional[Sequence[str]] = None,
                      direct: bool = True,
                      ) -> str:
            if order is None:
                order = trans_order
            for lang in order:
                for key in keys:
                    if val := item_translations.get(lang, {}).get(key):
                        return val
            if direct:
                for key in keys:
                    if val := item.get(key):
                        return val
            return default

        def lang_aliases(lng: str) -> Sequence[str]:
            return self.LANGUAGE_ALIASES.get(lng, (lng,))

        if not item.get('success', True):
            return None

        if locale is None:
            locale = tmdb_locale()
        lang = locale.partition('-')[0]

        # Translation order.
        orig_lang: str = item.get('original_language', 'en')
        orig_langs: Sequence[str] = lang_aliases(orig_lang)
        trans_order = tuple(dict.fromkeys((locale, *(lang_aliases(lang)), 'en-US', 'en-GB', 'en',
                                           *(f'{lng}-{c}' for lng in orig_langs for c in item.get('origin_country', ())),
                                           *orig_langs)))
        en_trans_order = ('en-US', 'en-GB', 'en')

        # Translations by locale (eg. en-US) and language (eg. en),
        # values: name, homepage, tagline, overview.
        item_translations: Dict[str, JsonData] = {f"{t['iso_639_1']}-{t['iso_3166_1']}": t['data']
                                                  for t in item.get('translations', {}).get('translations', ())}
        # Add default translation if it's not in "translations" object.
        if 'original_language' in item:
            data = {key: value for key in ('title', 'name') if (value := item.get(f'original_{key}'))}
            for c in item.get('origin_country', ()):
                item_translations.setdefault(f'{orig_lang}-{c}', data)
            item_translations.setdefault(orig_lang, data)
        else:
            item_translations.setdefault(locale, item)
        # Fix missing names if translation is item direclty.
        # If lang == orig_lang same values (as "title") has empty value in translation object. But item['title'] has translated name.
        if orig_lang == lang:  # fix missing names if translation is item direclty
            for key in self.TRANSLATE_FILEDS:
                if value := item.get(key):
                    for c in ('', *item.get('origin_country', ())):
                        tr = item_translations.get(f'{lang}-{c}' if c else lang, {})
                        if not tr.get(key):
                            tr[key] = value
        # Add iso_639_1 keys (language only, without country code).
        item_translations = {k: tr for loc, tr in item_translations.items() if tr.get('name') or tr.get('title')
                             for k in (loc, loc.partition('-')[0])}
        # Fix broken translation for original language.
        if orig_lang == lang and lang not in item_translations:
            item_translations[lang] = {k: item[k] for k in self.TRANSLATE_FILEDS if item.get(k)}

        en_translation: JsonData = item_translations.get('en-US', item_translations.get('en-GB', {}))
        orig_translation: JsonData = {}
        if orig_lang:
            orig_translation = next(iter(tr for lng, tr in item_translations.items()
                                         if lng.partition('-')[0] == orig_lang), {})

        ref = MediaRef(*item['_ref'])
        ff = FFItem(ref)
        if ref.season is not None:
            if 'id' not in item:
                fflog(json.dumps(item, indent=2))
            if ref.is_season:
                # fake tmdb season id (show_id and season_number)
                # NOTE: now season DBID is replaced to volatile DBID in InfoProvider._set_volatile_dbid().
                if sz_ref := ref.denormalize():
                    ff.dbid = sz_ref.dbid
                else:
                    # TODO: find first episode and use its dbid as 'season' dbid
                    ...
        if not ff.dbid:
            ff.dbid = VideoIds.dbid_from_tmdb(item)
        if ref.real_type in ('movie', 'episode'):
            ff.mode = ff.Mode.Playable
        else:
            ff.mode = ff.Mode.Folder
        ff.source_data = item

        vtag = ff.getVideoInfoTag()
        titletag: str = 'title' if ref.type == 'movie' else 'name'

        if 'id' not in item:
            fflog(f'ERROR: XXXXXXXXXXXXXXXXX\n\n{json.dumps(item, indent=2)}')
        else:
            vtag.setDbId(ff.dbid)
        set_if(vtag.setIMDBNumber, 'imdb_id', 'external_ids/imdb_id')
        vtag.setUniqueIDs({name: str(val)
                           for name, key in (('tmdb', 'id'), ('tmdb_id', 'id'), ('imdb', 'imdb_id'), ('imdb', 'external_ids/imdb_id'))
                           for val in (dget(item, key),) if val},
                          'imdb')  # default id type
        vtag.setMediaType(ref.real_type)

        # season and episode should be set in FFItem(ref)
        # skip vtag.setSeason()
        # skip vtag.setEpisode()

        # duration
        runtime = item.get('runtime')
        if runtime is not None:
            vtag.setDuration(runtime * 60)

        # year and dates (premiered, first aired)
        date = None
        if ref.type == 'movie':
            date_keys = ('release_date', )
        else:
            date_keys = ('first_air_date', 'air_date')
        for date_key in date_keys:
            date_str = item.get(date_key)
            if date_str:
                try:
                    date = fromisoformat(date_str)
                    break
                except ValueError:
                    pass
        if date:
            vtag.setYear(date.year)
        set_if(vtag.setFirstAired, 'first_air_date', 'air_date')
        set_if(vtag.setPremiered, 'release_date')

        # titles
        vtag.setTitle(translate('title', 'name', default=ff.title))
        set_if(vtag.setOriginalTitle, f'original_{titletag}')
        orig_en_title = vtag.getOriginalTitle() if item.get('original_language', 'en') == 'en' else ''
        vtag.setEnglishTitle(translate('title', 'name', order=en_trans_order, direct=False, default=orig_en_title))
        if ref.main_type == 'show':
            vtag.setTvShowTitle(ff.title)
            vtag.setEnglishTvShowTitle(vtag.getEnglishTitle())
        ff.label = ff.title

        # plot, outline and tag line
        vtag.setPlotBase(translate('overview', default=vtag.getPlot()))
        # vtag.setPlotOutline()
        vtag.setTagLine(translate('tagline', default=vtag.getTagLine()))

        # set genres
        vtag.setGenres([g['name'] for g in item.get('genres', ())])

        # casts / actors, directors, writers
        if ref.type == 'person':
            self._parse_tmdb_person(item, ff, en_translation=en_translation, orig_translation=orig_translation)
        elif ref.type == 'collection':
            self._parse_tmdb_collection(item, ff, en_translation=en_translation, orig_translation=orig_translation)
        else:
            credits = self.parse_credits(item, limit=limit)
            vtag.setCast(credits.actors)
            vtag.setDirectors(credits.directors)
            vtag.setWriters(credits.writers)
            vtag.setCrew(credits.crew)  ## FF extension

            # --- art ---
            ff.setArt(self.art.parse_art(item=item, translate_order=trans_order, ref=ref))

        # countries and MPAA
        countries = country_translations()
        vtag.setCountries([countries.get(c['iso_3166_1'], c['name']) for c in item.get('production_countries', ())])
        vtag.setMpaaList(sorted(cert for rel in item.get('release_dates', {}).get('results', ())
                                for cert in (rel.get('certification', ''),) if cert))
        vtag.setStudios([name for st in item.get('production_companies', ()) for name in (st.get('name'),) if name])

        # ratings:
        vtag.setRatings({'tmdb': (item.get('vote_average', 0.0), item.get('vote_count', 0))}, 'tmdb')

        # rest:
        if episode_type := self.tmdb.parse_episode_type(item):
            vtag.setEpisodeType(episode_type)

        # vtag.setDateAdded() – LIBRARY
        # vtag.setEpisodeGuide() – JSON ?!
        # vtag.setFilenameAndPath ???

        # vtag.setPath ???
        # vtag.setProductionCode() ?
        # vtag.setSet() / vtag.setSetId() / vtag.setSetOverview() ???
        # vtag.setShowLinks()

        # vtag.setTags() - append_to_response=keywords & "keywords"
        # vtag.setTop250() ?
        # vtag.setTrailer()
        # vtag.setTvShowStatus() ?
        # vtag.setUniqueID() / vtag.setUniqueIDs()
        # vtag.setUserRating()

        # vtag.setSortTitle()
        # vtag.setSortSeason()
        # vtag.setSortEpisode()

        # vtag.setLastPlayed() - TRAKT
        # vtag.setPlaycount() – TRAKT
        # vtag.setResumePoint() – TRAKT

        # music videos info: vtag.setAlbum(), vtag.setArtists() vtag.setTrackNumber()

        # -- item --
        # setArt()
        # setAvailableFanart()
        # setContentLookup() – PLAYER
        # setDateTime() ???
        # setInfo() !!!  overlay, setoverview
        # setIsFolder()
        # setLabel()
        # setLabel2()
        # setProperties() / setProperty
        # setSubtitles() ???

        # --- seasons & episodes ---
        if ref.is_show:
            set_if(vtag.setSeriesStatus, 'status')
        if ref.type == 'show':
            if count := item.get('number_of_episodes'):
                ff.episodes_count = count
            if ep := item.get('last_episode_to_air'):
                ff.last_episode_to_air = self._make_sub_item(ff, ep)
            if ep := item.get('next_episode_to_air'):
                ff.next_episode_to_air = self._make_sub_item(ff, ep)
            self._parse_tmdb_item_children(item, ff, en_translation=en_translation, orig_translation=orig_translation)

        return ff

    def _make_sub_item(self, ff: FFItem, it: JsonData) -> FFItem:
        ref = ff.ref
        # fi = FFItem(ref._replace(**{itype: it[f'{itype}_number']}))
        fi = FFItem(ref._replace(**{itype: num for itype in ('season', 'episode') if (num := it.get(f'{itype}_number')) is not None}))
        vtag = fi.vtag
        # NOTE: now season DBID is replaced to volatile DBID in InfoProvider._set_volatile_dbid().
        if fi.ref.is_season and (denorm := fi.ref.denormalize()):
            fi.dbid = denorm.dbid
        if not fi.dbid:
            fi.dbid = VideoIds.dbid_from_tmdb(it)
        fi.title = it.get('name', str(fi.season))
        vtag.setUniqueIDs({'tmdb': str(it['id'])})
        if has_air := it.get('air_date'):
            air = datetime.fromisoformat(has_air).date()
            vtag.setFirstAired(str(air))
            vtag.setYear(air.year)
        if overview := it.get('overview'):
            fi.vtag.setPlotBase(overview)
        if 'vote_average' in it:
            vtag.setRatings({'tmdb': (it['vote_average'], it.get('vote_count', 0))}, 'tmdb')
        art, ff_art = {}, ff.getArt()
        if poster := it.get('poster_path'):
            art['poster'] = f'{self.tmdb.art_image_url}{poster}'
        runtime = it.get('runtime')
        if runtime is not None:
            vtag.setDuration(runtime * 60)
        if count := it.get('episode_count'):
            fi._children_count = fi.episodes_count = count
        if episode_type := self.tmdb.parse_episode_type(it, tvshow_status=ff.vtag.getSeriesStatus()):
            vtag.setEpisodeType(episode_type)
        vtag.setTvShowTitle(ff.vtag.getTVShowTitle())
        if img := ff_art.get('poster'):
            art['tvshow.poster'] = img
        if img := ff_art.get('fanart'):
            art['tvshow.fanart'] = img
        if art:
            fi.setArt(art)
        fi.source_data = it
        if ref.is_show:
            fi.show_item = ff
        elif ref.is_season:
            fi.season_item = ff
            fi.show_item = ff.show_item
        return fi

    def _parse_tmdb_item_children(self, item: JsonData, ff: FFItem, *,
                                  en_translation: JsonData, orig_translation: JsonData) -> None:
        """Parse single season/episode data for tv-show item."""

        ref = ff.ref
        if ref.season is None:
            # season_number > 0 -- omit season "0" (extra materials)
            seasons = item.get('seasons', ())
            if seasons:
                if seasons[-1]['season_number'] > 0 and 'episodes' in seasons[-1]:
                    # full season info, tv_episodes is True
                    ff.children_items = [sz for it in seasons if it['season_number'] > 0 for sz in (self.parse_tmdb_item(it),) if sz]
                else:
                    # shorten seasons info
                    ff.children_items = [self._make_sub_item(ff, it) for it in seasons if it['season_number'] > 0]
                # update kodi seasons
                    ff.vtag.addSeasons([(sz.season, sz.title) for sz in ff.children_items])
        elif ref.episode is None:
            ff.children_items = [self._make_sub_item(ff, it) for it in item.get('episodes', ())]

    def _parse_tmdb_person(self, item: JsonData, ff: FFItem,
                           en_translation: JsonData, orig_translation: JsonData) -> None:
        """Parse single person data."""

        def set_if(meth: Callable, *keys: str) -> None:
            for data in (item, en_translation, orig_translation):
                for key in keys:
                    value = data.get(key)
                    if value:
                        meth(value)
                        return

        vtag = ff.vtag
        set_if(vtag.setPlotOutline, 'biography')
        # year and dates (premiered, first aired)
        date = None
        try:
            birthday = item.get('birthday')
            if birthday:
                date = fromisoformat(birthday)
        except ValueError:
            pass
        if date:
            vtag.setYear(date.year)
            vtag.setPremiered(str(date))

        imgs = item.get('images', {}).get('profiles', [])
        if imgs:
            path = imgs[0]['file_path']
            if path:
                path = f'{self.tmdb.art_image_url}{path}'
                ff.setArt({'thumb': path, 'icon': path})

    def _parse_tmdb_collection(self, item: JsonData, ff: FFItem,
                               en_translation: JsonData, orig_translation: JsonData) -> None:
        """Parse single collection data."""

    def parse_item(self, item: JsonData) -> Optional[FFItem]:
        """Parse abstract item (get id, name, poster, etc.)."""

        def set_if(setter: Callable, key: str) -> None:
            val = item.get(key)
            if val:
                setter(val)

        if item is None:
            return None
        dbid = VideoIds.make_dbid(tmdb=item['id'])
        ff = FFItem(dbid=dbid)
        vtag = ff.vtag
        ff.label = ff.title = item.get('title', item.get('name', ''))
        set_if(vtag.setPlotBase, 'overview')
        poster = item.get('poster_path')
        if poster:
            poster = f'{self.tmdb.person_image_url}/{poster}'
            ff.setArt({'thumb': poster, 'poster': poster})
        return ff

    def parse_items(self, items: Sequence[JsonData]) -> List[Optional[FFItem]]:
        return [self.parse_item(it) for it in items]

    def item_to_row(self, item: FFItem, now: Optional[float] = None) -> MediaInfoRow:
        """Convert FFItem to cache media info row."""
        if now is None:
            now = cur_time()
        ref: MediaRef = item.ref
        vtag = item.vtag
        return MediaInfoRow(
            type=ref.type,
            dbid=item.dbid or 0,
            main_dbid=ref.sql_main_dbid,
            season=ref.sql_season,
            episode=ref.sql_episode,
            tmdb=None,
            imdb=None,
            trakt=None,
            ui_lang=None,
            title=item.title,
            en_title=None,
            duration=vtag.getDuration(),
            data_type='json',
            data=json.dumps(item.__to_json__()),
            updated_at=int(now),
        )

    def parse_tmdb_skel_item(self, item: TmdbItemJson) -> FFItem:
        """Create items with skeleton children items (eg. episodes based on episodes count only)."""

        def dget(dct: Dict, key: str, default: Any = None) -> Any:
            keys = key.split('/')
            for key in keys[:-1]:
                dct = dct.get(key, {})
            return dct.get(keys[-1], default)

        def set_if(meth: Callable, *keys: str) -> None:
            for data in (item,):
                for key in keys:
                    value = dget(data, key)
                    if value:
                        meth(value)
                        return

        ref = MediaRef(*item['_ref'])
        ff = FFItem(ref)
        if not ff.dbid:
            ff.dbid = VideoIds.dbid_from_tmdb(item)
        if ref.real_type in ('movie', 'episode'):
            ff.mode = ff.Mode.Playable
        else:
            ff.mode = ff.Mode.Folder
        ff.source_data = item
        vtag = ff.getVideoInfoTag()
        titletag: str = 'title' if ref.type == 'movie' else 'name'

        if 'id' not in item:
            fflog(f'ERROR: XXXXXXXXXXXXXXXXX\n\n{json.dumps(item, indent=2)}')
        else:
            vtag.setDbId(ff.dbid)
        set_if(vtag.setIMDBNumber, 'imdb_id', 'external_ids/imdb_id')
        vtag.setUniqueIDs({name: str(val)
                           for name, key in (('tmdb', 'id'), ('tmdb_id', 'id'), ('imdb', 'imdb_id'), ('imdb', 'external_ids/imdb_id'))
                           for val in (dget(item, key),) if val},
                          'imdb')  # default id type
        vtag.setMediaType(ref.real_type)

        # duration
        runtime = item.get('runtime')
        if runtime is not None:
            vtag.setDuration(runtime * 60)

        # year and dates (premiered, first aired)
        date = None
        if ref.type == 'movie':
            date_keys = ('release_date', )
        else:
            date_keys = ('first_air_date', 'air_date')
        for date_key in date_keys:
            date_str = item.get(date_key)
            if date_str:
                try:
                    date = fromisoformat(date_str)
                    break
                except ValueError:
                    pass
        if date:
            vtag.setYear(date.year)
        if date:
            if ref.type == 'show':
                vtag.setFirstAired(date)
            else:
                vtag.setPremiered(date)

        # titles
        set_if(vtag.setTitle, 'title', 'name')
        set_if(vtag.setOriginalTitle, f'original_{titletag}')
        en_title = vtag.getOriginalTitle() if item.get('original_language', 'en') == 'en' else vtag.getTitle()  # api lang is EN
        vtag.setEnglishTitle(en_title)
        if ref.main_type == 'show':
            vtag.setTvShowTitle(ff.title)
            vtag.setEnglishTvShowTitle(vtag.getEnglishTitle())
        ff.label = ff.title

        # ratings
        vtag.setRatings({'tmdb': (item.get('vote_average', 0.0), item.get('vote_count', 0))}, 'tmdb')

        # --- seasons & episodes ---
        if ref.type == 'show':
            if seasons := item.get('seasons'):
                last_ref: Optional[MediaRef]
                if last := item.get('last_episode_to_air', {}):
                    last_ref = ref.with_season(last['season_number']).with_episode(last['episode_number'])
                    last_aired = last['air_date']
                else:
                    last_ref = None
                    last_aired = None
                ff.children_items = []
                for sz in seasons:
                    if (snum := sz['season_number']) > 0:  # skip special "Season 0"
                        zref = ref.with_season(snum)
                        fz = FFItem(zref, dbid=VideoIds.dbid_from_tmdb(sz))
                        fz.show_item = ff
                        ff.children_items.append(fz)
                        fz.vtag.setTvShowTitle(vtag.getTitle())
                        fz.vtag.setEnglishTvShowTitle(vtag.getEnglishTitle())
                        if aired := sz.get('air_date'):
                            fz.vtag.setFirstAired(aired)
                        if title := sz.get('name'):
                            fz.title = title
                        if count := sz.get('episode_count'):
                            fz.children_items = []
                            for enum in range(1, count + 1):
                                fe = FFItem(zref.with_episode(enum))
                                fe.show_item = ff
                                fe.season_item = fz
                                fz.children_items.append(fe)
                                fe.vtag.setTvShowTitle(vtag.getTitle())
                                fe.vtag.setEnglishTvShowTitle(vtag.getEnglishTitle())
                                if last_aired:
                                    # all episodes up to last aired are marked with the same date
                                    fe.vtag.setFirstAired(last_aired)
                                if last_ref == fe.ref:
                                    last_aired = None
            if episodes := item.get('episodes'):
                ...

        return ff

    def row_to_item(self, row: MediaInfoRow) -> FFItem:
        """Convert cache media info row to FFItem."""
        ref = row.ref
        if type(row.data) is not str:
            raise TypeError(f'Data of {ref} row is unsupported')
        data = json.loads(row.data)
        # return FFItem.__from_json__(data)
        item = FFItem(ref)
        item.__set_json__(data)
        return item

    def _update_items_progress(self,
                               items: Mapping[MediaRef, FFItem],
                               *,
                               progress: Progress,
                               ) -> None:
        # Append progress info.
        if progress is Progress.BASIC:
            trakt_playback_dict = get_playback_info(items)
            for it in items.values():
                self.update_item_progress(it, playback_info=trakt_playback_dict)
        elif progress is Progress.FULL:
            trakt_playback_dict = get_playback_info(items)
            for it in items.values():
                self.update_item_progress_full(it, playback_info=trakt_playback_dict)

    def _set_volatile_dbid(self, items: FFItemDict) -> None:
        """Change seasons DBID for volatile one."""
        def list_all(items: Iterable[FFItem]) -> Iterator[Tuple[MediaRef, FFItem]]:
            for ffitem in items:
                yield ffitem.ref, ffitem
                if children := ffitem.children_items:
                    yield from list_all(children)

        all_items = dict(list_all(items.values()))

        if const.core.volatile_dbid and const.core.volatile_seasons:
            if seasons_refs := [ref for ref in all_items if ref.is_season]:
                for ref, dbid in service_client.create_dbid_dict(seasons_refs).items():
                    all_items[ref].dbid = dbid

    def find_item(self,
                  ref: Union[MediaRef, FFItem],
                  *,
                  progress: Progress = Progress.BASIC,
                  limit: Optional[int] = None,
                  tv_episodes: bool = False,
                  ) -> Optional[FFItem]:
        """Get single item info, ref can be denormalized."""
        # Take refs (from FFItem, ref.ref is correct too).
        ref = ref.ref
        # Resolve volatile DBID.
        if ref.is_volatile and const.core.volatile_dbid and (norm := service_client.get_dbid_ref(ref.dbid)):
            ref = norm
        # Resolve external ID (IMDB only).
        if not ref.tmdb_id:
            vid = ref.video_ids
            if vid.imdb:
                imdb = self.tmdb.find_id('imdb', vid.imdb)
                if imdb is None:
                    return None
                ref = imdb
            else:
                return None
        # try to normalize
        refs = ref.ref_list()  # all refs (ex. tvshow for episode)
        if ref.is_normalized:
            rows = get_media_info(refs)
        else:
            rows = find_media_info(ref)
            if rows:
                refs = tuple(rows)
                recovered_ref = next((row.ref for row in rows.values() if row.denormalized_ref() == ref), None)
                if recovered_ref is not None:
                    ref = recovered_ref
        items = {item.ref: item for row in rows.values() for item in (self.row_to_item(row),)}
        missing = tuple(set(refs) - rows.keys())
        # something is missing and ref is not normalized (ex. episode ID not show/se/ep)
        if missing and not ref.is_normalized:
            if norm := ref.normalize():
                ref = norm
            # elif ref.is_volatile and const.core.volatile_dbid and (norm := service_client.get_dbid_ref(ref.dbid)):
            #     ref = norm
            else:
                if self.trakt is None:
                    return None
                try:
                    vid = ref.video_ids
                    mid = self.trakt.id_lookup(id=vid.value or 0, service=vid.service() or 'tmdb', type=ref.type)
                except ValueError:
                    fflog_exc()
                    return None
                if mid.ref is None:
                    return None
                ref = mid.ref
                # we have normalized ref, then we can try get it again
            refs = ref.ref_list()  # all refs (ex. tvshow for episode)
            rows = get_media_info(refs)
            items = {item.ref: item for row in rows.values() for item in (self.row_to_item(row),)}
            missing = tuple(set(refs) - rows.keys())
        # something is missing need to get data from tmdb
        if missing:
            data = self.tmdb.get_media_list_by_ref(missing, tv_episodes=tv_episodes)
            if not data:
                return None
            new_items = [self.parse_tmdb_item(d, limit=limit) for d in data]
            if const.core.info.save_cache:
                set_media_info([self.item_to_row(item) for item in new_items if item])
            items.update((item.ref, item) for item in new_items if item)
        try:
            ffitem = items[ref]
        except KeyError:
            fflog(f'No {ref} found in TMDB')
            return None
        # Join show info (eg. show_item in episode).
        if ref.season:
            show = items[MediaRef.tvshow(ref.dbid)]
            ffitem.show_item = show
            if show is not None:
                ffitem.vtag.setTvShowTitle(show.title)
                ffitem.vtag.setEnglishTvShowTitle(show.vtag.getEnglishTitle())
            if ref.episode:
                season = items[MediaRef.tvshow(ref.dbid, ref.season)]
                season.show_item = show
                ffitem.season_item = season
        # Change seasons DBID for volatile one.
        self._set_volatile_dbid(items)
        # Append progress info.
        self._update_items_progress({ffitem.ref: ffitem}, progress=progress)
        return ffitem

    @overload
    def get_items(self,
                  refs: Pagina[Union[MediaRef, FFItem]],
                  *,
                  limit: Optional[int] = None,
                  progress: Progress = Progress.BASIC,
                  tv_episodes: bool = False,
                  keep_missing: Literal[False] = False,
                  duplicate: bool = True,
                  ) -> ItemList[FFItem]: ...

    @overload
    def get_items(self,
                  refs: Pagina[Union[MediaRef, FFItem]],
                  *,
                  limit: Optional[int] = None,
                  progress: Progress = Progress.BASIC,
                  tv_episodes: bool = False,
                  keep_missing: Literal[True] = True,
                  duplicate: bool = True,
                  ) -> ItemList[Optional[FFItem]]: ...

    @overload
    def get_items(self,
                  refs: Sequence[Union[MediaRef, FFItem]],
                  *,
                  limit: Optional[int] = None,
                  progress: Progress = Progress.BASIC,
                  tv_episodes: bool = False,
                  keep_missing: Literal[False] = False,
                  duplicate: bool = True,
                  ) -> List[FFItem]: ...

    @overload
    def get_items(self,
                  refs: Sequence[Union[MediaRef, FFItem]],
                  *,
                  limit: Optional[int] = None,
                  progress: Progress = Progress.BASIC,
                  tv_episodes: bool = False,
                  keep_missing: Literal[True] = True,
                  duplicate: bool = True,
                  ) -> List[Optional[FFItem]]: ...

    def get_items(self,
                  refs: Union[Sequence[Union[MediaRef, FFItem]], Pagina[Union[MediaRef, FFItem]]],
                  *,
                  limit: Optional[int] = None,
                  progress: Progress = Progress.BASIC,
                  tv_episodes: bool = False,
                  keep_missing: bool = False,
                  duplicate: bool = True,
                  ) -> Any:
        """Get list of item info in order, refs must be normalized."""

        # Find one item in received info.
        def get_ff(ref: MediaRef, source: Optional[Union[MediaRef, FFItem]]) -> Optional[FFItem]:
            if ff := used.get(ref):
                if ff and duplicate:
                    if not isinstance(source, FFItem):
                        source = in_items.get(ref)
                    return self._set_dynamic_stuff(ff.clone(), source)
                return ff
            ff = items.get(ref)
            if not ff:
                ff = in_items.get(ref)
                if ff and ff.type in self._supported_details_types:
                    # Broken item: no into in TMDB, we get input FFItem (from `refs`)
                    fflog(f'BROKEN ITEM: {ff.ref} {ff.vtag.getUniqueIDs()}')
                    ff.broken = True
                    if broken_details and not ff.vtag.getTagLine():
                        ids = '\n'.join(f'{k}: {v}' for k, v in ff.vtag.getUniqueIDs().items())
                        dbs = '/'.join(str(x) for x in ff.ref[1:] if x is not None)
                        ff.vtag.setPlotBase(f'[B]BROKEN ITEM[/B]\ntype: {ff.ref.type}\ndbid: {dbs}\n{ids}')
            if duplicate and ff and isinstance(source, FFItem):
                self._set_dynamic_stuff(ff, source)
            used[ref] = ff
            return ff

        # Get info.
        in_refs, in_items, items = self._get_items(refs, limit=limit, progress=progress, tv_episodes=tv_episodes)
        # Refs "used" to clone ref (and item) duplicated.
        used: Dict[MediaRef, Optional[FFItem]] = {}
        # Return list of FFItem in `refs` order.
        broken_details = bool(const.folder.style.broken)  # style is used in menu, here we check if add info for broken ffitem
        if keep_missing:
            it_gen = [get_ff(ref, src) for ref, src in zip(in_refs, refs) if ref]
        else:
            it_gen = [item for ref, src in zip(in_refs, refs) if ref and (item := get_ff(ref, src))]
        if isinstance(refs, Pagina):
            return ItemList(it_gen, page=refs.page, total_pages=refs.total_pages)
        return list(it_gen)

    def get_item_dict(self,
                      refs: Sequence[Union[MediaRef, FFItem]],
                      *,
                      limit: Optional[int] = None,
                      progress: Progress = Progress.BASIC,
                      tv_episodes: bool = False,
                      ) -> FFItemDict:
        """Get dict of item info, refs must be normalized."""
        # Get info.
        _, _, items = self._get_items(refs, limit=limit, progress=progress, tv_episodes=tv_episodes)
        # Restore children (seasons and episodes).
        stack = list(items.values())
        while stack:
            it = stack.pop()
            items.setdefault(it.ref, it)
            if it.children_items:
                stack.extend(it.children_items)
        # Return all known items.
        return items

    def get_item(self,
                 ref: Union[MediaRef, FFItem],
                 *,
                 limit: Optional[int] = None,
                 progress: Progress = Progress.BASIC,
                 tv_episodes: bool = False,
                 ) -> Optional[FFItem]:
        """Get single item info in order, refs must be normalized."""
        lst = self.get_items([ref], limit=limit, progress=progress, tv_episodes=tv_episodes)
        return lst[0] if lst else None

    def _get_items(self,
                   refs: Sequence[Union[MediaRef, FFItem]],
                   *,
                   limit: Optional[int] = None,
                   progress: Progress = Progress.BASIC,
                   tv_episodes: bool = False,
                   ) -> Tuple[Sequence[Optional[MediaRef]], FFItemDict, FFItemDict]:
        """Helper. Get list of item info in order, refs must be normalized."""
        # Take refs (from FFItem, ref.ref is correct too).
        in_items = {x.ref: x for x in refs if isinstance(x, FFItem)}
        refs = [x.ref for x in refs]
        # Easy normalize refs (TMDB seasons only).
        refs = [x.normalize() or x for x in refs]
        # Try to recover volatile dbid if allowed.
        if const.core.volatile_dbid:
            if volatile := [x.dbid for x in refs if x.is_volatile]:
                if norm := service_client.get_dbid_ref_dict(volatile):
                    refs = [ref if x.is_volatile and (ref := norm.get(x.dbid)) else x for x in refs]
        # Resolve external IDs (IMDB only).
        if any(not ref.tmdb_id for ref in refs):
            tmdb_refs = self.tmdb.find_ids('imdb', (vid.imdb for ref in refs for vid in (ref.video_ids,) if vid.imdb))
            xit = iter(tmdb_refs)
            in_refs = [next(xit) if vid.imdb else ref for ref in refs for vid in (ref.video_ids,)]
        else:
            in_refs = refs
        # Expand season/episode ref to all possible refs (parent season and show).
        all_refs: Set[MediaRef] = {ref for aref in in_refs if aref for ref in aref.ref_list() if ref}
        # Get rows from cache at once.
        rows = get_media_info(all_refs)
        # Create all existing items.
        items = {item.ref: item for row in rows.values() for item in (self.row_to_item(row),)}
        # Find missing refs and try get it from TMDB.
        allowed = get_typing_args(DetailsAllowed)
        missing = tuple(set(all_refs) - rows.keys() - {ref for ref in all_refs if ref.type not in allowed})
        if missing:
            # Get data from TMDB for all missing info at once.
            data = self.tmdb.get_media_dict_by_ref(missing, tv_episodes=tv_episodes)
            if data:
                # Parse data and create items.
                new_items = [self.parse_tmdb_item(d, limit=limit) for d in data.values()]
                # Save new items in he cache.
                if const.core.info.save_cache:
                    set_media_info([self.item_to_row(item) for item in new_items if item])
                # Take new items, now we should have all items.
                items.update((item.ref, item) for item in new_items if item)
        # Join show info (eg. show_item in episode).
        for ref, ffitem in items.items():
            if ref.season:
                show = items.get(MediaRef.tvshow(ref.dbid))
                ffitem.show_item = show
                if show is not None:
                    ffitem.vtag.setTvShowTitle(show.title)
                    ffitem.vtag.setEnglishTvShowTitle(show.vtag.getEnglishTitle())
                if ref.episode:
                    season = items.get(MediaRef.tvshow(ref.dbid, ref.season))
                    if season:
                        season.show_item = show
                        ffitem.season_item = season
        # Change seasons DBID for volatile one.
        self._set_volatile_dbid(items)
        # Append progress info.
        self._update_items_progress(items, progress=progress)
        # Rewrite roles and another dunamic stuff.
        for ref, ffitem in items.items():
            if iff := in_items.get(ref):
                self._set_dynamic_stuff(ffitem, iff)
        # Return finding parts (request, FFItems from request, found FFItems).
        return in_refs, in_items, items

    def _set_dynamic_stuff(self, item: FFItem, source: Optional[FFItem]) -> FFItem:
        """Rewrite roles and another dynamic stuff."""
        if source:
            item.role = source.role
            item.descr_style = source.descr_style
            item.vtag.setLastPlayed(source.vtag.getLastPlayedAsW3C())
            item.temp.__dict__.update(source.temp.__dict__)
            if item.progress is None:
                item.progress = source.progress
        return item

    def find_ids(self, source: ExternalIdType, refs: Iterable[Optional[MediaRef]]) -> Sequence[Optional[MediaRef]]:
        return self.tmdb.find_ids(source, (vid.imdb or '' for ref in refs if ref
                                           for vid in (ref.video_ids,) if vid.imdb))

    @overload
    def get_en_skel_items(self,
                          refs: Sequence[Union[MediaRef, FFItem]],
                          *,
                          keep_missing: Literal[False] = False,
                          ) -> List[FFItem]: ...

    @overload
    def get_en_skel_items(self,
                          refs: Sequence[Union[MediaRef, FFItem]],
                          *,
                          keep_missing: Literal[True] = True,
                          ) -> List[Optional[FFItem]]: ...

    def get_en_skel_items(self,
                          refs: Union[Sequence[Union[MediaRef, FFItem]], Pagina[Union[MediaRef, FFItem]]],
                          *,
                          keep_missing: bool = False,
                          ) -> Any:
        """Get list of item info in order, refs must be normalized."""

        # Find one item in received info.
        def get_ff(ref: MediaRef) -> Optional[FFItem]:
            if ff := items.get(ref):
                return ff
            ff = in_items.get(ref)
            if ff and ff.type in self._supported_details_types:
                # Broken item: no into in TMDB, we get input FFItem (from `refs`)
                fflog(f'BROKEN ITEM: {ff.ref} {ff.vtag.getUniqueIDs()}')
                ff.broken = True
            return ff

        # Get info.
        in_refs, in_items, items = self._get_en_skel_items(refs)
        # Return list of FFItem in `refs` order.
        if keep_missing:
            it_gen = [get_ff(ref) for ref in in_refs if ref]
        else:
            it_gen = [item for ref in in_refs if ref and (item := get_ff(ref))]
        if isinstance(refs, Pagina):
            return ItemList(it_gen, page=refs.page, total_pages=refs.total_pages)
        return list(it_gen)

    def _get_en_skel_items(self,
                           refs: Sequence[Union[MediaRef, FFItem]],
                           ) -> Tuple[Sequence[Optional[MediaRef]], FFItemDict, FFItemDict]:
        """Get skeleton items by refs (or ffitems). Only base EN info."""
        # Take refs (from FFItem, ref.ref is correct too).
        in_items = {x.ref: x for x in refs if isinstance(x, FFItem)}
        refs = [x.ref for x in refs]
        # Easy normalize refs (TMDB seasons only).
        refs = [x.normalize() or x for x in refs]
        # Resolve external IDs (IMDB only).
        if any(not ref.tmdb_id for ref in refs):
            tmdb_refs = self.tmdb.find_ids('imdb', (vid.imdb for ref in refs for vid in (ref.video_ids,) if vid.imdb))
            xit = iter(tmdb_refs)
            in_refs = [next(xit) if vid.imdb else ref for ref in refs for vid in (ref.video_ids,)]
        else:
            in_refs = refs
        # Get rows from cache at once.
        # TODO: cache support !!!
        items, missing = {}, tuple({ref for ref in in_refs if ref})
        if True:
            # Get data from TMDB for all missing info at once.
            data = self.tmdb.get_skel_en_media(missing)
            if data:
                # Parse data and create items.
                new_items = [self.parse_tmdb_skel_item(d) for d in data.values()]
                # Save new items in he cache.
                # if const.core.info.save_cache:
                #     set_media_info([self.item_to_row(item) for item in new_items if item])
                # Take new items, now we should have all items.
                items.update((item.ref, item) for item in new_items if item)
        # Change seasons DBID for volatile one.
        self._set_volatile_dbid(items)
        # Rewrite roles and another dunamic stuff.
        for ref, ffitem in items.items():
            iff = in_items.get(ref)
            if iff:
                ffitem.role = iff.role
                ffitem.descr_style = iff.descr_style
                ffitem.vtag.setLastPlayed(iff.vtag.getLastPlayedAsW3C())
                ffitem.temp.__dict__.update(iff.temp.__dict__)
                if ffitem.progress is None:
                    ffitem.progress = iff.progress
        # Return finding parts (request, FFItems from request, found FFItems).
        return in_refs, in_items, items

    def item_genres(self, item: FFItem, *, translations: Optional[Dict['CodeId', str]] = {}) -> List[FFItem]:
        """Return itm collection."""
        if item.source_data:
            genres = {g['id']: g['name'] for g in item.source_data.get('genres', ())}
            if translations is not None:
                genres = {gid: translations.get(gid, gname) for gid, gname in genres.items()}
            return [FFItem(type='genre', dbid=gid, mode=FFItem.Mode.Folder, label=gname)
                    for gid, gname in genres.items()]
        return []

    def item_collection(self, item: FFItem) -> Optional[FFItem]:
        """Return itm collection."""
        if item.source_data:
            return self.parse_item(item.source_data.get('belongs_to_collection'))
        return None

    # def recount_progress(self, item: FFItem) -> bool:
    #     """Recount progress from watched item.progress info. Item must have all episodes."""
    #     if item.progress is None:
    #         return False

    # --- trakt sync progress ---

    @property
    def trakt_playback(self) -> MediaPlayInfoDict:
        """Get trakt playback progress."""
        if self._trakt_playback is None:
            with logtime(name='load trakt playback'):
                self._trakt_playback = get_playback()
        return self._trakt_playback

    @property
    def kodi_playback(self) -> List[KodiVideoInfo]:
        """Get kodi playback progress."""
        if self._kodi_playback is None:
            with logtime(name='load kodi playback'):
                self._kodi_playback = video_db.get_plays()
        return self._kodi_playback

    def reset_playback_info(self) -> None:
        """Forget playback info, will be loaded again."""
        self._trakt_playback = None
        self._kodi_playback = None

    # def progress_analize(self, progress_list: TraktPlaybackList) -> List[FFItem]:
    #     """Return FFItem with progreass from low-level trakty sync progeress rows."""

    def find_last_next_episodes(self,
                                # full tv-show item (show item with seasons and episodes)
                                it: FFItem,
                                # tree of  watched episodes: [season][episode] = MediaProgressItem()
                                *,
                                policy: NextWatchPolicy = NextWatchPolicy.LAST,
                                today: Optional[dt_date] = None,
                                recount_progress: bool = True,
                                ) -> Tuple[Optional[FFItem], Optional[FFItem]]:
        """Find last and next episode in tv-show progress."""
        # linear all aired episodes
        if today is None:
            today = dt_date.today()
        episodes = tuple(ep for sz in it.season_iter() for ep in sz.episode_iter() if ep.aired_before(today))
        if not episodes:
            return None, None
        watched: Dict[MediaRef, datetime] = {}
        if it.progress is not None:
            watched = {epp.ref: epp.last_watched_at for epp in it.progress.bar if epp.has_last_watched_at}
        for ep in episodes:
            ep.temp.__dict__.setdefault('watched', watched.get(ep.ref))

        lst = nxt = None
        # Example: last watched: B, episodes: aBcDef
        if policy == NextWatchPolicy.LAST:
            # find first unwatched episode after latest watched episode (result: D, e)
            for ep in episodes:
                if ep.temp.watched:
                    lst = ep
            for pe, ne in pairwise(episodes):
                if pe.temp.watched and not ne.temp.watched:
                    nxt = ne
        elif policy == NextWatchPolicy.CONTINUED:
            # find last watched episode (result: B, c)
            ind, lst = max(enumerate(episodes), key=lambda x: x[1].temp.watched or datetime.min)
            for i in range(ind + 1, len(episodes)):
                if not (ep := episodes[i]).temp.watched:
                    nxt = ep
                    break
        elif policy == NextWatchPolicy.FIRST:
            # find first unwatched episode (result: B, a)
            for pe, ne in pairwise(episodes):
                if pe.temp.watched and not ne.temp.watched:
                    lst, nxt = pe, ne
                    break
        elif policy == NextWatchPolicy.NEWEST:
            # return newest episode (result: D, f)
            for ep in episodes:
                if ep.temp.watched:
                    lst = ep
                else:
                    nxt = ep

        if recount_progress:
            if it.progress is None:
                ep_progress = {}
            else:
                ep_progress = {epp.ref: epp for epp in it.progress.bar or () if epp.has_last_watched_at}
            bar = tuple(ep_progress.get(ep.ref, MediaProgressItem(ep.ref))
                        for sz in it.season_iter() for ep in sz.episode_iter() if ep.aired_before(today))
            progress = 100 * len(ep_progress) / (len(bar) or 1)
            play_count = min((epp.play_count for epp in bar), default=0)
            it.progress = MediaProgress(it.ref, bar=bar, progress=progress, play_count=play_count,
                                        last_episode=lst, next_episode=nxt)

        return lst, nxt  # last, next

    def update_item_progress(self, it: FFItem, *, playback_info: Optional[MediaPlayInfoDict] = None) -> FFItem:
        """Update item progress form playback DB (trakt sync cache). Base info."""
        if playback_info is None:
            playback_info = self.trakt_playback  # TODO: some optymalizations, try do not load all db
        if (pb := playback_info.get(it.ref)):
            it.progress = pb.as_media_progress()
            vtag = it.vtag
            if not vtag.getUniqueID('slug') and pb.slug:
                vtag.setUniqueID(pb.slug, 'slug')
        for ch in it.children_items or ():
            if ch.progress is None:
                self.update_item_progress(ch, playback_info=playback_info)
        return it

    def update_item_progress_full(self, it: FFItem, *, playback_info: Optional[MediaPlayInfoDict] = None) -> FFItem:
        """Update item progress form playback DB (trakt sync cache). Full info."""
        if playback_info is None:
            playback_info = self.trakt_playback  # TODO: some optymalizations, try do not load all db
        if (pb := playback_info.get(it.ref)):
            vtag = it.vtag
            if not vtag.getUniqueID('slug') and pb.slug:
                vtag.setUniqueID(pb.slug, 'slug')
        # TODO: implement it !!!
        return self.update_item_progress(it, playback_info=playback_info)  # TODO: replace it with full implementation

    def progressbar_str(self, watched: Sequence[Any], *, width: int = const.indexer.progressbar.width) -> str:
        """Return ||| progressbar for MediaProgress.bar."""
        col0 = const.indexer.progressbar.empty.color
        col1 = const.indexer.progressbar.partial.color
        col2 = const.indexer.progressbar.fill.color
        col3 = const.indexer.progressbar.watched.color
        ch0 = const.indexer.progressbar.empty.char
        ch1 = const.indexer.progressbar.partial.char
        ch2 = const.indexer.progressbar.fill.char
        ch3 = const.indexer.progressbar.watched.char
        bar, color = '', ''
        for i in range(width):
            a = len(watched) * i // width
            b = max(a + 1, len(watched) * (i + 1) // width)
            block = watched[a:b]
            if all(block):
                col, ch = col2, ch2
            elif any(block):
                col, ch = col1, ch1
            elif any(e is AREADY_WATCHED for e in block):
                col, ch = col3, ch3
            else:
                col, ch = col0, ch0
            if color != col:
                if color:
                    bar += '[/COLOR]'
                if col:
                    bar += f'[COLOR {col}]'
                color = col
            bar += ch
        if color:
            bar += '[/COLOR]'
        return bar

    def progress_descr_style(self, progress: MediaProgress) -> str:
        """Return progress description (tagline) style."""
        p = progress
        mtype = progress.ref.real_type
        # get const settings
        ON, OFF = 1, 0
        if mtype == 'movie':
            style = const.indexer.movies.progressbar.style
            bar_mode = ProgressBarMode(const.indexer.movies.progressbar.mode)
            width = const.indexer.movies.progressbar.width
        elif mtype == 'episode':
            style = const.indexer.episodes.progressbar.style
            bar_mode = ProgressBarMode(const.indexer.episodes.progressbar.mode)
            width = const.indexer.episodes.progressbar.width
        else:
            style = const.indexer.progressbar.style
            bar_mode = ProgressBarMode(const.indexer.progressbar.mode)
            width = const.indexer.progressbar.width
        # preselect mode
        if bar_mode is ProgressBarMode.NONE:
            return ''
        if bar_mode is ProgressBarMode.WATCHING:
            if 0 < p.progress < 100:
                bar_mode = ProgressBarMode.PERCENT
            else:
                return ''
        elif bar_mode is ProgressBarMode.PERCENT_AND_WATCHED:
            if progress.play_count and 0 < p.progress < 100:  # watching already watched video
                OFF = AREADY_WATCHED
            bar_mode = ProgressBarMode.PERCENT
        # select mode
        pp = p.total_progress
        if bar_mode is ProgressBarMode.WATCHED:
            bar = p.bar
        elif bar_mode is ProgressBarMode.PERCENT:
            if progress.play_count and not 0 < p.progress < 100:
                bar = (ON,)
            else:
                pp = p.progress
                bar = (ON,) * int(p.progress + .5) + (OFF,) * (100 - int(p.progress + .5))
        else:
            bar = (OFF,)
        # draw bar
        return style.format('{}', descr='{}', tagline='{}', p=p, progress=pp, percent=round(pp),
                            watching_progress=p.progress, progressbar=self.progressbar_str(bar, width=width))

    def web_url(self, ref: MediaRef) -> str:
        """Return link to media for humans."""
        if ref.tmdb_id:
            return self.tmdb.web_url(ref)
        return ''


#: Global media info provider.
ffinfo = InfoProvider(tmdb=tmdb_provider, trakt=trakt_provider)


if __name__ == '__main__':
    from typing import Tuple
    from sys import stderr
    # import pickle
    from argparse import ArgumentParser, ArgumentError
    from pprint import pformat
    import sty
    # from .tricks import dump_obj_gets
    from .cmdline import DebugArgumentParser, parse_ref
    from ..fake.fake_term import print_table, formatting, text_width, text_left

    def parse_id(v: str) -> Tuple[int, ...]:
        return tuple(map(int, v.split('/')))

    def show_info(item: FFItem, *, indent: int = 0) -> None:
        pre = ' ' * indent
        dim = sty.bg(240)
        it = item
        print(f'{pre}{sty.ef.bold}{sty.fg(35)}-- Info --{sty.rs.all}')
        vtag = it.getVideoInfoTag()
        descr = formatting(str(vtag.getPlot() or '')).replace('\n', f'{dim}[CR]{sty.rs.bg}')
        if text_width(descr) > 199:
            descr = f'{text_left(descr, 199)}{dim}…{sty.rs.bg}'
        print_table((
            ('Label:', repr(it.getLabel())),
            ('Label2:', repr(it.getLabel2())),
            ('Title:', repr(vtag.getTitle())),
            ('TVShowTitle:', repr(vtag.getTVShowTitle())),
            ('Year:', repr(vtag.getYear())),
            ('Duration:', repr(vtag.getDuration())),
            ('Art:', pformat(it.getArt())),
            ('Descr:', descr),
        ), indent=indent+1)
        print(f'{pre}{sty.ef.bold}{sty.fg(35)}--{sty.rs.all}')

    # def show_extra(item: FFItem) -> None:
    #     from .ff.info import ffinfo, FFItem, MediaRef
    #     show_info(item=item, index=index)
    #     print(33*'-')
    #     print(f'{item=}')
    #     ffitem: FFItem = item.item
    #     denorm = MediaRef(ffitem.ref.real_type, ffitem.dbid)
    #     print(denorm)
    #     print(ffinfo.find_item(denorm))

    def print_full(item: Optional[FFItem], *, level: int = 0, parents: bool = True, recursive: bool = True,
                   ref: Optional[MediaRef] = None, details: bool = False) -> None:
        indent = '  ' * level
        if item:
            if ref is None:
                ref = item.ref
            elif ref != item.ref:
                print(f'{indent}{ref:a} =/= {item.ref:a} !!!')
            print(f'{indent}{ref:a}, {item=}, en:{item.vtag.getEnglishTitle()!r}')
            if details:
                show_info(item, indent=2*level)
            if parents:
                if it := item.season_item:
                    print(f'{indent}  - season: {it.ref:a}, {it!r}, en:{it.vtag.getEnglishTitle()!r}')
                if it := item.show_item:
                    print(f'{indent}  - show:   {it.ref:a}, {it!r}, en:{it.vtag.getEnglishTitle()!r}')
            if recursive:
                for ch in item.children_items or ():
                    print_full(ch, level=level + 1, parents=False)
        else:
            if ref is None:
                print(f'{indent}-- None')
            else:
                print(f'{indent}{ref:a} -- None')

    p = DebugArgumentParser(dest='op')
    with p.with_subparser('find') as pp:
        pp.add_argument('type', choices=('movie', 'show', 'season', 'episode'))
        pp.add_argument('id', type=int)
        pp.add_argument('season', type=int, nargs='?')
        pp.add_argument('episode', type=int, nargs='?')
        pp.add_argument('--force-tmdb', action='store_true', help='skip cache and force TMDB')
        pp.add_argument('--recursive', '-r', action='store_true', help='print children')
        pp.add_argument('--episodes', '-e', action='store_true', help='get show episodes too')
        pp.add_argument('--info', '-i', action='store_true', help='print extra info')
    with p.with_subparser('list') as pp:
        pp.add_argument('type', choices=('movie', 'show'))
        pp.add_argument('ids', nargs='+', type=parse_id, help='list of ids (movie, show[/season[/episode]]')
        pp.add_argument('--recursive', '-r', action='store_true', help='print children')
        pp.add_argument('--episodes', '-e', action='store_true', help='get show episodes too')
        pp.add_argument('--info', '-i', action='store_true', help='print extra info')
    with p.with_subparser('dict') as pp:
        pp.add_argument('type', choices=('movie', 'show'))
        pp.add_argument('ids', nargs='+', type=parse_id, help='list of ids (movie, show[/season[/episode]]')
        pp.add_argument('--recursive', '-r', action='store_true', help='print children')
        pp.add_argument('--episodes', '-e', action='store_true', help='get show episodes too')
        pp.add_argument('--info', '-i', action='store_true', help='print extra info')
    with p.with_subparser('skel') as pp:
        pp.add_argument('type', choices=('movie', 'show'))
        pp.add_argument('ids', nargs='+', type=parse_id, help='list of ids (movie, show[/season[/episode]]')
        pp.add_argument('--recursive', '-r', action='store_true', help='print children')
        pp.add_argument('--info', '-i', action='store_true', help='print extra info')
    args = p.parse_args()

    item: Optional[FFItem]
    if args.op == 'find':
        ref = MediaRef(args.type, args.id, args.season, args.episode)
        if args.force_tmdb:
            # x = ffinfo.tmdb.get_media_list_by_ref([MediaRef('show', 84958)])
            x = ffinfo.tmdb.get_media_by_ref(ref)
            print(json.dumps(x, indent=2))
            y = ffinfo.parse_tmdb_item(x)
            print(('-----------------------------------------------------------------'
                   f' ({len(json.dumps(y.__to_json__()))} B)'), file=stderr)
            print(json.dumps(y.__to_json__(), indent=2), file=stderr)
            set_media_info([ffinfo.item_to_row(y)])
            # xx = get_media_info([ref])
        else:
            item = ffinfo.find_item(ref, tv_episodes=args.episodes)
            print_full(item, recursive=args.recursive, ref=ref, details=args.info)
    elif args.op == 'list':
        refs = [MediaRef(args.type, *id) for id in args.ids]
        items = ffinfo.get_items(refs, tv_episodes=args.episodes)
        for ref, item in zip(refs, items):
            print_full(item, recursive=args.recursive, ref=ref, details=args.info)
    elif args.op == 'dict':
        refs = [MediaRef(args.type, *id) for id in args.ids]
        for ref, item in ffinfo.get_item_dict(refs, tv_episodes=args.episodes).items():
            print_full(item, recursive=args.recursive, ref=ref, details=args.info)
    elif args.op == 'skel':
        refs = [MediaRef(args.type, *id) for id in args.ids]
        for ref, item in ffinfo.get_en_skel_items(refs):
            print_full(item, recursive=args.recursive, details=args.info)
    print(f'---\n  (( {ffinfo.tmdb._DEBUG_STATS} ))')
    if 0:
        f1 = FFItem()
        f1.title = 'Zupa zębowa'
        print(f'-----------------------------------------------------------------', file=stderr)
        print(json.dumps(FFItem().__to_json__(), indent=2), file=stderr)
        print(f'eq? {FFItem() == FFItem()}')
        f2 = FFItem.__from_json__(f1.__to_json__())
        print(f'{f1.title=}')
        print(f'f1→f2: {f1 == f2 = }, title: {f2.title!r}\n{json.dumps(f2.__to_json__(), indent=2)}\n--')
        # print('-----------------------------------------------------------------', file=stderr)
        # print(y.dumps(), file=stderr)
        # print(pickle.dumps(y), file=stderr)
        # print(y)
        # print(y.getVideoInfoTag().getGenres())
        # print(y.getVideoInfoTag().getFirstAiredAsW3C())
