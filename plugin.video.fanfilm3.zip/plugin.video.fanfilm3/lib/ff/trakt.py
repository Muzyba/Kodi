# -*- coding: utf-8 -*-

"""
    Fanfilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

raise AssertionError(f'Do NOT use this module {__name__}')

import json
import re
import sys
import time
from urllib.parse import quote_plus, urljoin

try:
    from sqlite3 import dbapi2 as database
except ImportError:
    from pysqlite2 import dbapi2 as database

import requests

from . import apis, bookmarks, cache, cleandate, client, control, utils #playcount
from .log_utils import LOGERROR, LOGWARNING, fflog, fflog_exc, log
from .utils import convert

BASE_URL = "https://api.trakt.tv"
V2_API_KEY = (
    apis.trakt_API
)  # "ccb4fbf0447d86edf30f71caf8f6a8c268e8d4014f84e536746b69752407bfd5"
CLIENT_SECRET = (
    apis.trakt_secret
)  # "ed7cff6b0c686789f101c91a5733d5b3e5122bafd1328f31dbd440d6fb5f4cbf"
REDIRECT_URI = "urn:ietf:wg:oauth:2.0:oob"


class TraktCredentialsManager:
    def __init__(self, settings_manager: control.settings) -> None:
        self._settings_manager = settings_manager
        self._credentials_info = None
        self._indicators_info = None

    def _get_trakt_credentials_info(self) -> bool:
        user = self._settings_manager.getString("trakt.user").strip()
        token = self._settings_manager.getString("trakt.token")
        refresh = self._settings_manager.getString("trakt.refresh")
        return bool(user and token and refresh)

    def _get_trakt_indicators_info(self) -> bool:
        # "indicators" – jesli nie mamy logowania, tylko jedna pozycja (lokalnie)
        # "indicators.alt" – jesli mamy logowaniae dwie pozycje (lokalnie, trakt)
        indicators = (
            self._settings_manager.getInt("indicators")
            if self.credentials_info is False
            else control.settings.getInt("indicators.alt")
        )
        return indicators == 1

    def reset(self) -> None:
        """Reset the cached credentials and indicators info."""
        self._credentials_info = None
        self._indicators_info = None

    @property
    def credentials_info(self) -> bool:
        if self._credentials_info is None:
            self._credentials_info = self._get_trakt_credentials_info()
        return self._credentials_info

    @property
    def indicators_info(self) -> bool:
        if self._indicators_info is None:
            self._indicators_info = self._get_trakt_indicators_info()
        return self._indicators_info


trakt_credentials_manager = TraktCredentialsManager(control.settings)


def _getTrakt(url, post=None):
    """
    Make an API request to Trakt and return the response.
    Args:
        url (str): The API endpoint.
        post (dict, optional): POST data. Defaults to None.
    Returns:
        tuple: Response text and headers, or None if an error occurs.
    """
    fflog(f"Trakt url: {url} | post: {post}")
    MAX_RETRIES = 3  # Define the max number of retries here
    RETRY_DELAY = 1  # Delay in seconds between retries

    def make_request(url, headers, post):
        if not post:
            return requests.get(url, headers=headers, timeout=30)
        return requests.post(url, data=post, headers=headers, timeout=30)

    try:
        url = urljoin(BASE_URL, url)
        post = json.dumps(post) if post else None
        headers = {
            "Content-Type": "application/json",
            "trakt-api-key": V2_API_KEY,
            "trakt-api-version": "2",
        }

        if trakt_credentials_manager.credentials_info:
            headers.update(
                {"Authorization": "Bearer %s" % control.settings.getString("trakt.token")}
            )

        retries = 0
        while retries < MAX_RETRIES:
            r = make_request(url, headers, post)
            resp_code = str(r.status_code)

            if resp_code == "429":  # Rate limit
                retries += 1
                log(f"Trakt Rate Limit Reached. Retrying in {RETRY_DELAY} seconds. URL: {url}. POST: {post}", LOGWARNING)
                time.sleep(RETRY_DELAY)
                continue
            elif resp_code in ["500", "502", "503", "504", "520", "521", "522", "524"]:
                log("Temporary Trakt Error: %s" % resp_code, LOGWARNING)
                return
            elif resp_code == "404":
                log("Object Not Found : %s" % resp_code, LOGWARNING)
                return
            elif resp_code not in ["401", "405"]:
                return r.text

            # Handle other codes like 401 here (Token Refresh Logic)
            oauth = urljoin(BASE_URL, "/oauth/token")
            opost = {
                "client_id": V2_API_KEY,
                "client_secret": CLIENT_SECRET,
                "redirect_uri": REDIRECT_URI,
                "grant_type": "refresh_token",
                "refresh_token": control.settings.getString("trakt.refresh"),
            }

            result = requests.post(
                oauth, data=json.dumps(opost), headers=headers, timeout=30
            ).json()

            token, refresh = result["access_token"], result["refresh_token"]

            control.settings.setString(id="trakt.token", value=token)
            control.settings.setString(id="trakt.refresh", value=refresh)

            headers["Authorization"] = "Bearer %s" % token

        # Log if all retries failed
        log("Failed after maximum retries.", LOGWARNING)
        return

    except Exception:
        fflog_exc()


def getTraktAsJson(url, post=None):
    try:
        r = _getTrakt(url, post)
        r = utils.json_loads_as_str_optimized(r)
        # if "X-Sort-By" in res_headers and "X-Sort-How" in res_headers:
        #     r = sort_list(res_headers["X-Sort-By"], res_headers["X-Sort-How"], r)
        return r
    except Exception:
        pass


def authTrakt():
    try:
        if trakt_credentials_manager.credentials_info:
            if control.yesnoDialog(
                control.lang(32511),
                control.lang(32512),
                "",
                "Trakt",
            ):
                control.settings.setString(id="trakt.user", value="")
                control.settings.setString(id="trakt.token", value="")
                control.settings.setString(id="trakt.refresh", value="")
                control.settings.setInt(id="indicators.alt", value=0)
                control.settings.setInt(id="resume.source", value=0)
                control.infoDialog(control.lang(32837), sound=False, icon="INFO")
            sys.exit()

        result = getTraktAsJson("/oauth/device/code", {"client_id": V2_API_KEY})
        verification_url = control.lang(32513) % result["verification_url"]
        user_code = control.lang(32514) % result["user_code"]
        expires_in = int(result["expires_in"])
        device_code = result["device_code"]

        progressDialog = control.progressDialog()
        progressDialog.create("Trakt", verification_url + "\n" + user_code)

        for i in range(0, expires_in):
            try:
                if progressDialog.iscanceled():
                    break
                time.sleep(1)
                progressDialog.update(int((i / expires_in) * 100))
                r = getTraktAsJson(
                    "/oauth/device/token",
                    {
                        "client_id": V2_API_KEY,
                        "client_secret": CLIENT_SECRET,
                        "code": device_code,
                    },
                )
                if "access_token" in r:
                    break
            except:
                pass

        try:
            progressDialog.close()
        except:
            pass

        token, refresh = r["access_token"], r["refresh_token"]

        headers = {
            "Content-Type": "application/json",
            "trakt-api-key": V2_API_KEY,
            "trakt-api-version": "2",
            "Authorization": "Bearer %s" % token,
        }

        result = client.request(urljoin(BASE_URL, "/users/me"), headers=headers)
        result = utils.json_loads_as_str_optimized(result)
        result = convert(result)

        user = result["username"]

        control.settings.setString(id="trakt.user", value=user)
        control.settings.setString(id="trakt.token", value=token)
        control.settings.setString(id="trakt.refresh", value=refresh)
        control.settings.setInt(id="indicators.alt", value=1)
        control.settings.setInt(id="resume.source", value=1)
        control.infoDialog(control.lang(32838) +repr(user), sound=False)
        try:
            if control.settings.getBool("syncTraktWithLocal"):
                synchronize_movies_with_trakt()
                synchronize_episodes_with_trakt()
        except:
            pass
        sys.exit()
    except:
        sys.exit()


def check_trakt_activity():
    try:
        fflog("#################### STARTING TRAKT ACTIVITY CHECK ################")

        # Odczytanie ostatniej znanej aktywności z ustawień
        last_known_activity = control.settings.getString("traktLastActivity")

        # Użycie funkcji _getTrakt
        response_text = _getTrakt("sync/last_activities")

        if response_text is None:
            log("Failed to fetch Trakt data", LOGERROR)
            return

        # Parsowanie odpowiedzi JSON
        current_activity_data = json.loads(response_text)

        # Przykład: używam tutaj "all" jako dowolnego pola aktywności
        current_activity = current_activity_data.get("all")

        if current_activity != last_known_activity:
            fflog("#################### NEW ACTIVITY DETECTED ################")

            # Usunięcie klucza z pamięci podręcznej
            cache.remove(getTraktAsJson, "/users/me/watched/movies?extended=full")
            cache.remove(getTraktAsJson, "/users/me/watched/shows?extended=full")
            cache.remove(_getTrakt, "/sync/playback/movies")
            cache.remove(_getTrakt, "/sync/playback/episodes")

            # Zaktualizowanie ostatniej znanej aktywności w ustawieniach
            control.setSetting("traktLastActivity", current_activity)  # setting type: str
        else:
            fflog("No new activity detected")

        playcount.getMovieIndicators(refresh=False, timeout=720)
        playcount.getTVShowIndicators(refresh=False, timeout=720)
        cache.get(getTraktAsJson, 720, "/users/me/watched/shows?extended=full")
        cache.get(getTraktAsJson, 720, "/users/me/watched/movies?extended=full")
        cache.get(_getTrakt, 720, "/sync/playback/movies")
        cache.get(_getTrakt, 720, "/sync/playback/episodes")
    except Exception as e:
        log(f"Trakt activity check error: {e}", LOGERROR)


def scrobbleMovie(imdb=None, progress=None, action="pause", trakt_id=None, tmdb=None):
    """
    Send scrobble for movie to Trakt API.
    Args:
        imdb (str): IMDb ID of the movie.
        progress (float): Percent of progress.
        action (str, optional): 'start', 'pause', or 'stop'. Defaults to 'pause'.
    """
    assert False
    if trakt_credentials_manager.indicators_info:
        if trakt_id:
            data = {"movie": {"ids": {"trakt": trakt_id}}, "progress": progress, "action": action}
        elif imdb:
            data = {"movie": {"ids": {"imdb": imdb}}, "progress": progress, "action": action}
        elif tmdb:
            data = {"movie": {"ids": {"tmdb": tmdb}}, "progress": progress, "action": action}

        url = "scrobble/" + action
        response = _getTrakt(url, post=data)  # Zakładamy, że _getTrakt zwraca odpowiedź i nagłówki
        return json.loads(response).get("status_code") == 201  # Upewnij się, że odpowiedź zawiera "status_code".
    else:
        return None


def scrobbleEpisode(imdb=None, season=None, episode=None, progress=None, action="pause", tmdb=None):
    """
    Send scrobble for episode to Trakt API.
    Args:
        imdb (str): IMDb ID of the show.
        season (int): Season number.
        episode (int): Episode number.
        progress (float): Percent of progress.
        action (str, optional): 'start', 'pause', or 'stop'. Defaults to 'pause'.
    """
    if trakt_credentials_manager.indicators_info:
        if imdb:
            data = {
                "show": {"ids": {"imdb": imdb}},
                "episode": {"season": season, "number": episode},
                "progress": progress,
                "action": action,
            }
        elif tmdb:
            data = {
                "show": {"ids": {"tmdb": tmdb}},
                "episode": {"season": season, "number": episode},
                "progress": progress,
                "action": action,
            }
        url = "scrobble/" + action
        response = _getTrakt(url, post=data)  # Zakładamy, że _getTrakt zwraca odpowiedź i nagłówki
        return json.loads(response).get("status_code") == 201  # Upewnij się, że odpowiedź zawiera "status_code".
    else:
        return None

def getWatchedMovies():
    """
    Retrieve all watched movies from Trakt API.
    Returns:
        list: List of IMDb IDs of watched movies.
    """
    return []
    url = "/sync/watched/movies"
    response_text = _getTrakt(url)
    if response_text:
        movies = json.loads(response_text)
    else:
        return []

    return [movie["movie"]["ids"]["imdb"] for movie in movies]


def getWatchedEpisodes():
    """
    Retrieve all watched episodes from Trakt API.
    Returns:
        list: List of watched episodes with IMDb ID, season and episode number.
    """
    return []
    url = "/sync/watched/shows"
    response_text = _getTrakt(url)
    if response_text:
        shows = json.loads(response_text)
    else:
        return []

    watched_episodes = []
    for show in shows:
        for ep in show["seasons"]:
            for episode in ep["episodes"]:
                watched_episodes.append(
                    {
                        "imdb": show["show"]["ids"]["imdb"],
                        "season": ep["number"],
                        "episode": episode["number"],
                    }
                )

    return watched_episodes


def synchronize_movies_with_trakt():
    watched_movies = set(getWatchedMovies())

    control.make_dir(control.dataPath)
    dbcon = database.connect(control.bookmarksFile)
    dbcur = dbcon.cursor()

    # Pobierz wszystkie filmy z bazy danych
    dbcur.execute("SELECT imdb FROM bookmarks WHERE type = 'movie'")
    movies_in_db = set(item[0] for item in dbcur.fetchall())

    # Znajdź filmy, które są w Trakt, ale nie w bazie danych
    movies_to_add = watched_movies - movies_in_db

    # Dodaj filmy do bazy danych
    for imdb in movies_to_add:
        bookmarks.reset(1, 1, "movie", imdb, dbcon=dbcon)

    dbcon.commit()


def synchronize_episodes_with_trakt():
    watched_episodes = getWatchedEpisodes()

    control.make_dir(control.dataPath)
    dbcon = database.connect(control.bookmarksFile)
    dbcur = dbcon.cursor()

    # Pobierz wszystkie odcinki z bazy danych
    dbcur.execute("SELECT imdb, season, episode FROM bookmarks WHERE type = 'episode'")
    episodes_in_db = set((item[0], item[1], item[2]) for item in dbcur.fetchall())

    # Stwórz zbiór odcinków z Trakt
    trakt_episodes = set(
        (ep["imdb"], ep["season"], ep["episode"]) for ep in watched_episodes
    )

    # Znajdź odcinki, które są w Trakt, ale nie w bazie danych
    episodes_to_add = trakt_episodes - episodes_in_db

    # Dodaj odcinki do bazy danych
    for episode_tuple in episodes_to_add:
        imdb, season, episode_number = episode_tuple
        bookmarks.reset(1, 1, "episode", imdb, season, episode_number, dbcon=dbcon)

    dbcon.commit()


def getAllStartedEpisodes():
    """
    Retrieve all started episodes from Trakt API.
    Returns:
        list: List of started episodes with details.
    """
    return []
    url = "/sync/playback/episodes"
    episodes = cache.get(_getTrakt, 720, url)
    episodes = json.loads(episodes)

    if not episodes:
        return []

    watched_episodes = getWatchedEpisodes()
    fflog(str(watched_episodes))

    started_episodes = []
    for ep in episodes:
        if ep["progress"] == 0:
            continue  # Przeskakuje elementy z progress == 0
        elif ep["progress"] >= 85:
            continue

        ep_key = {
            "imdb": ep["show"]["ids"]["imdb"],
            "season": ep["episode"]["season"],
            "episode": ep["episode"]["number"],
        }
        if tuple(sorted(ep_key.items())) not in [
            tuple(sorted(ep.items())) for ep in watched_episodes
        ]:
            episode_details = {
                "title": ep["show"]["title"],
                "year": ep["show"]["year"],
                "imdb": ep["show"]["ids"]["imdb"],
                "tmdb": ep["show"]["ids"]["tmdb"],
                "season": ep["episode"]["season"],
                "episode": ep["episode"]["number"],
                "progress": ep["progress"],
            }
            started_episodes.append(episode_details)

    return started_episodes


def getAllStartedMovies():
    """
    Retrieve all started movies from Trakt API.
    Returns:
        list: List of started movies with details.
    """
    return []
    url = "/sync/playback/movies"
    response_text = cache.get(_getTrakt, 720, url)
    if response_text:
        movies = json.loads(response_text)
        fflog(str(movies))
    else:
        return []

    watched_movies = getWatchedMovies()

    started_movies = []
    for movie in movies:
        if movie["progress"] == 0:
            # FIX NA PROGRESS UZYWAC W RAZIE KONIECZNOSCI
            # markMovieAsWatched(movie["movie"]["ids"]["imdb"])
            # markMovieAsNotWatched(movie["movie"]["ids"]["imdb"])
            # scrobbleMovie(progress=90, action="pause", imdb=movie["movie"]["ids"]["imdb"])
            # scrobbleMovie(progress=100, action="stop", imdb=movie["movie"]["ids"]["imdb"])
            # markMovieAsNotWatched(movie["movie"]["ids"]["imdb"])
            continue  # Przeskakuje elementy z progress == 0. FIX POWYZEJ
        elif movie["progress"] >= 85:
            continue
        if movie["movie"]["ids"]["imdb"] not in watched_movies:
            movie_details = {
                "title": movie["movie"]["title"],
                "imdb": movie["movie"]["ids"]["imdb"],
                "progress": movie["progress"],
            }
            started_movies.append(movie_details)

    return started_movies


def getMovieProgress(imdb):
    """
    Retrieve scrobble progress for movie from Trakt API.
    Args:
        imdb (str): IMDb ID of the movie.
    Returns:
        float: progress percent (0.0 to 100.0), or None if not found.
    """
    return []
    url = "/sync/playback/movies"
    response_text = cache.get(_getTrakt, 720, url)
    if response_text:
        movies = json.loads(response_text)
    else:
        return None

    for movie in movies:
        if movie["movie"]["ids"]["imdb"] == imdb:
            return movie["progress"]

    return None

def getMoviesProgress():
    """
    Fetches movie progress from the Trakt service.

    Uses the endpoint `/sync/playback/movies` on Trakt to retrieve a 
    list of movies and their progress. If data retrieval is unsuccessful, returns None.

    Returns:
        list: A list of movies and their progress if data retrieval is successful.
        None: If data retrieval is unsuccessful.
    """
    return []
    url = "/sync/playback/movies"
    response_text = cache.get(_getTrakt, 720, url)
    if response_text:
        movies = json.loads(response_text)
        return movies
    else:
        return None

def getEpisodesProgress():
    """
    Fetches episode progress from the Trakt service.

    Uses the endpoint `/sync/playback/episodes` on Trakt to retrieve a 
    list of episodes and their progress. If data retrieval is unsuccessful, returns None.

    Returns:
        list: A list of episodes and their progress if data retrieval is successful.
        None: If data retrieval is unsuccessful.
    """
    return []
    url = "/sync/playback/episodes"
    response_text = cache.get(_getTrakt, 720, url)
    if response_text:
        return json.loads(response_text)
    else:
        return None

def getEpisodeProgress(imdb, season, episode):
    """
    Retrieve scrobble progress for episode from Trakt API.
    Args:
        imdb (str): IMDb ID of the show.
        season (int): Season number.
        episode (int): Episode number.
    Returns:
        float: progress percent (0.0 to 100.0), or None if not found.
    """
    return []
    url = "/sync/playback/episodes"
    response_text = cache.get(_getTrakt, 720, url)
    if response_text:
        episodes = json.loads(response_text)
    else:
        return None

    for ep in episodes:
        if (
            ep["show"]["ids"]["imdb"] == imdb
            and ep["episode"]["season"] == season
            and ep["episode"]["number"] == episode
        ):
            return ep["progress"]

    return None


def getTraktAddonMovieInfo():
    try:
        scrobble = control.addon("script.trakt").getSetting("scrobble_movie")
    except:
        scrobble = ""
    try:
        ExcludeHTTP = control.addon("script.trakt").getSetting("ExcludeHTTP")
    except:
        ExcludeHTTP = ""
    try:
        authorization = control.addon("script.trakt").getSetting("authorization")
    except:
        authorization = ""
    if scrobble == "true" and ExcludeHTTP == "false" and not authorization == "":
        return True
    else:
        return False


def getTraktAddonEpisodeInfo():
    try:
        scrobble = control.addon("script.trakt").getSetting("scrobble_episode")
    except:
        scrobble = ""
    try:
        ExcludeHTTP = control.addon("script.trakt").getSetting("ExcludeHTTP")
    except:
        ExcludeHTTP = ""
    try:
        authorization = control.addon("script.trakt").getSetting("authorization")
    except:
        authorization = ""
    return scrobble == "true" and ExcludeHTTP == "false" and authorization != ""


def manager(name, imdb, tmdb, content):
    fflog('!!!!!')
    assert False  # XXX
    try:
        post = (
            {"movies": [{"ids": {"imdb": imdb}}]}
            if content == "movie"
            else {"shows": [{"ids": {"tmdb": tmdb}}]}
        )

        items = [(control.lang(32516), "/sync/collection")]
        items += [(control.lang(32517), "/sync/collection/remove")]
        items += [(control.lang(32518), "/sync/watchlist")]
        items += [(control.lang(32519), "/sync/watchlist/remove")]
        items += [(control.lang(32520), "/users/me/lists/%s/items")]

        result = getTraktAsJson("/users/me/lists")
        lists = [(i["name"], i["ids"]["slug"]) for i in result]
        lists = [lists[i // 2] for i in range(len(lists) * 2)]
        for i in range(0, len(lists), 2):
            lists[i] = (
                (control.lang(32521) % lists[i][0]),
                "/users/me/lists/%s/items" % lists[i][1],
            )
        for i in range(1, len(lists), 2):
            lists[i] = (
                (control.lang(32522) % lists[i][0]),
                "/users/me/lists/%s/items/remove" % lists[i][1],
            )
        items += lists

        select = control.selectDialog([i[0] for i in items], control.lang(32515))

        if select == -1:
            return
        elif select == 4:
            t = control.lang(32520)
            k = control.keyboard("", t)
            k.doModal()
            new = k.getText() if k.isConfirmed() else None
            if new is None or new == "":
                return
            result = _getTrakt(
                "/users/me/lists", post={"name": new, "privacy": "private"}
            )

            try:
                slug = utils.json_loads_as_str_optimized(result)["ids"]["slug"]
            except:
                return control.infoDialog(
                    control.lang(32515),
                    heading=str(name),
                    sound=True,
                    icon="ERROR",
                )
            result = _getTrakt(items[select][1] % slug, post=post)
            del k
        else:
            result = _getTrakt(items[select][1], post=post)

        if "/sync/collection" in items[select][1]:
            cache.remove_partial_key("tvshows.trakt_collections_and_recommendations_list")
            cache.remove_partial_key("getTraktAsJson")
        if "/sync/watchlist" in items[select][1]:
            cache.remove_partial_key("tvshows.trakt_list")

        icon = control.infoLabel("ListItem.Icon") if result is not None else "ERROR"

        control.infoDialog(
            control.lang(32515),
            heading=str(name),
            sound=True,
            icon=icon,
        )

        control.refresh()
    except:
        return


def slug(name):
    name = name.strip()
    name = name.lower()
    name = re.sub("[^a-z0-9_]", "-", name)
    name = re.sub("--+", "-", name)
    return name


def sort_list(sort_key, sort_direction, list_data):
    reverse = False if sort_direction == "asc" else True
    if sort_key == "rank":
        return sorted(list_data, key=lambda x: x["rank"], reverse=reverse)
    elif sort_key == "added":
        return sorted(list_data, key=lambda x: x["listed_at"], reverse=reverse)
    elif sort_key == "title":
        return sorted(
            list_data,
            key=lambda x: utils.title_key(x[x["type"]].get("title")),
            reverse=reverse,
        )
    elif sort_key == "released":
        return sorted(
            list_data, key=lambda x: _released_key(x[x["type"]]), reverse=reverse
        )
    elif sort_key == "runtime":
        return sorted(
            list_data, key=lambda x: x[x["type"]].get("runtime", 0), reverse=reverse
        )
    elif sort_key == "popularity":
        return sorted(
            list_data, key=lambda x: x[x["type"]].get("votes", 0), reverse=reverse
        )
    elif sort_key == "percentage":
        return sorted(
            list_data, key=lambda x: x[x["type"]].get("rating", 0), reverse=reverse
        )
    elif sort_key == "votes":
        return sorted(
            list_data, key=lambda x: x[x["type"]].get("votes", 0), reverse=reverse
        )
    else:
        return list_data


def _released_key(item):
    if "released" in item:
        return item["released"]
    elif "first_aired" in item:
        return item["first_aired"]
    else:
        return 0


def getActivity():
    return []  # XXX
    try:
        i = getTraktAsJson("/sync/last_activities")

        activity = [
            i["movies"]["collected_at"],
            i["episodes"]["collected_at"],
            i["movies"]["watchlisted_at"],
            i["shows"]["watchlisted_at"],
            i["seasons"]["watchlisted_at"],
            i["episodes"]["watchlisted_at"],
            i["lists"]["updated_at"],
            i["lists"]["liked_at"],
        ]
        activity = [int(cleandate.iso_2_utc(i)) for i in activity]
        activity = sorted(activity, key=int)[-1]

        return activity
    except:
        pass


def getWatchedActivity():
    return []  # XXX
    try:
        i = getTraktAsJson("/sync/last_activities")

        activity = [i["movies"]["watched_at"], i["episodes"]["watched_at"]]
        activity = [int(cleandate.iso_2_utc(i)) for i in activity]
        activity = sorted(activity, key=int)[-1]

        return activity
    except:
        pass


def timeoutsyncMovies():
    timeout = cache.timeout(syncMovies, control.settings.getString("trakt.user").strip())
    return timeout


def syncMovies(user=None, refreshCache=False):
    return []  # XXX
    if not trakt_credentials_manager.credentials_info:
        return
    try:
        if refreshCache:
            cache.remove(getTraktAsJson, "/users/me/watched/movies?extended=full")
            fflog("Zresetowano cache dla /users/me/watched/movies?extended=full")
        indicators = cache.get(getTraktAsJson, 720, "/users/me/watched/movies?extended=full")
        indicators = [i["movie"]["ids"] for i in indicators]
        indicators = [str(i["imdb"]) for i in indicators if "imdb" in i] # TODO TMDB
        return indicators
    except Exception:
        fflog_exc()


def timeoutsyncTVShows():
    timeout = cache.timeout(syncTVShows, control.settings.getString("trakt.user").strip())
    return timeout


def syncTVShows(user=None, refreshCache=False):
    return []  # XXX
    if not trakt_credentials_manager.credentials_info:
        return
    try:
        if refreshCache:
            cache.remove(getTraktAsJson, "/users/me/watched/shows?extended=full")
            fflog("Zresetowano cache dla /users/me/watched/shows?extended=full")

        watched_shows = cache.get(getTraktAsJson, 720, "/users/me/watched/shows?extended=full")
        indicators = [
            (
                show["show"]["ids"]["tmdb"],
                show["show"]["aired_episodes"],
                sum(
                    [
                        [(season["number"], episode["number"]) for episode in season["episodes"]]
                        for season in show["seasons"]
                    ],
                    [],
                ),
            )
            for show in watched_shows
        ]
        indicators = [(str(i[0]), int(i[1]), i[2]) for i in indicators]
        return indicators
    except:
        pass


def syncSeason(id):
    return []  # XXX
    if not trakt_credentials_manager.credentials_info:
        return
    try:
        indicators = getTraktAsJson(
            "/shows/%s/progress/watched?specials=false&hidden=false" % id
        )
        indicators = indicators["seasons"]
        # indicators = [(i["number"], [x["completed"] for x in i["episodes"]]) for i in indicators]
        # indicators = ["%01d" % int(i[0]) for i in indicators if False not in i[1]]
        return [str(ind["number"]) for ind in indicators if all(x["completed"] for x in ind["episodes"])]
    except Exception:
        fflog_exc()


def syncEpisode(imdb, refreshCache=False, tmdb=None):
    if not trakt_credentials_manager.credentials_info:
        return True  # Zwraca True, jeśli brak poświadczeń Trakt
    try:
        if refreshCache:
            cache.remove(getTraktAsJson, "/users/me/watched/shows?extended=full")
            fflog("Zresetowano cache dla /users/me/watched/shows?extended=full")

        # Pobieranie danych przy użyciu funkcji getTraktAsJson
        response = cache.get(getTraktAsJson, 720, "/users/me/watched/shows?extended=full")

        if imdb:
            # Szukanie odpowiedniego serialu po imdb
            show_data = next((item for item in response if item['show']['ids']['imdb'] == imdb), None)
        elif tmdb:
            # Szukanie odpowiedniego serialu po tmdb
            show_data = next((item for item in response if item['show']['ids']['tmdb'] == tmdb), None)
        if not show_data:
            return True  # Zwraca True, jeśli serial nie został znaleziony

        # Lista wszystkich obejrzanych odcinków w formie (numer_sezonu, numer_odcinka)
        watched_episodes = [
            (int(season["number"]), int(episode["number"]))
            for season in show_data["seasons"]
            for episode in season["episodes"]
        ]

        # Zwraca True, jeśli lista jest pusta
        if not watched_episodes:
            return True

        return watched_episodes

    except Exception as e:  # Dodano identyfikację wyjątku dla lepszego debugowania
        fflog(f"Wystąpił wyjątek: {e}")  # Opcjonalne logowanie wyjątku
        return False  # Zwraca False w przypadku wystąpienia wyjątku


def markMovieAsWatched(imdb=None, tmdb=None):
    if not imdb.startswith("tt"):
        imdb = "tt" + imdb
    fflog("Przed _getTrakt")
    if imdb:
        result = _getTrakt("/sync/history", {"movies": [{"ids": {"imdb": imdb}}]})
    elif tmdb:
        result = _getTrakt("/sync/history", {"movies": [{"ids": {"tmdb": tmdb}}]})
    fflog(result)
    return result


def markMovieAsNotWatched(imdb=None, tmdb=None):
    if not imdb.startswith("tt"):
        imdb = "tt" + imdb
    fflog("Przed _getTrakt")
    if imdb:
        result = _getTrakt("/sync/history/remove", {"movies": [{"ids": {"imdb": imdb}}]})
    if tmdb:
        result = _getTrakt("/sync/history/remove", {"movies": [{"ids": {"tmdb": tmdb}}]})
    fflog(result)
    return result


def markTVShowAsWatched(imdb=None, tmdb=None):
    if imdb:
        result =_getTrakt("/sync/history", {"shows": [{"ids": {"imdb": imdb}}]})
    elif tmdb:
        result =_getTrakt("/sync/history", {"shows": [{"ids": {"tmdb": tmdb}}]})
    fflog(result)
    return result


def markTVShowAsNotWatched(imdb=None, tmdb=None):
    if imdb:
        result = _getTrakt("/sync/history/remove", {"shows": [{"ids": {"imdb": imdb}}]})
    elif tmdb:
        result = _getTrakt("/sync/history/remove", {"shows": [{"ids": {"tmdb": tmdb}}]})
    fflog(result)
    return result


def markEpisodeAsWatched(imdb=None, season=None, episode=None, tmdb=None):
    season, episode = int("%01d" % int(season)), int("%01d" % int(episode))
    
    if imdb:
        result = _getTrakt(
            "/sync/history",
            {
                "shows": [
                    {
                        "seasons": [{"episodes": [{"number": episode}], "number": season}],
                        "ids": {"imdb": imdb},
                    }
                ]
            },
        )
        
    elif tmdb:
        result = _getTrakt(
        "/sync/history",
        {
            "shows": [
                {
                    "seasons": [{"episodes": [{"number": episode}], "number": season}],
                    "ids": {"tmdb": tmdb},
                }
            ]
        },
    )
    fflog(result)
    return result


def markSeasonAsWatched(imdb=None, season=None, tmdb=None):
    season = int("%01d" % int(season))

    if imdb:
        data = {
            "shows": [
                {
                    "seasons": [{"number": season}],
                    "ids": {"imdb": imdb},
                }
            ]
        }
        
    elif tmdb:
        data = {
        "shows": [
            {
                "seasons": [{"number": season}],
                "ids": {"tmdb": tmdb},
            }
        ]
    }

    result = _getTrakt("/sync/history", data)
    fflog(result)
    return result


def markSeasonAsNotWatched(imdb=None, season=None, tmdb=None):
    season = int("%01d" % int(season))
    
    if imdb:
        data = {
            "shows": [
                {
                    "seasons": [{"number": season}],
                    "ids": {"imdb": imdb},
                }
            ]
        }
    elif tmdb:
        data = {
        "shows": [
            {
                "seasons": [{"number": season}],
                "ids": {"tmdb": tmdb},
            }
        ]
    }

    result = _getTrakt("/sync/history/remove", data)
    fflog(result)
    return result


def markEpisodeAsNotWatched(imdb=None, season=None, episode=None, tmdb=None):
    season, episode = int("%01d" % int(season)), int("%01d" % int(episode))
    if imdb:
        result = _getTrakt(
            "/sync/history/remove",
            {
                "shows": [
                    {
                        "seasons": [{"episodes": [{"number": episode}], "number": season}],
                        "ids": {"imdb": imdb},
                    }
                ]
            },
        )
    elif tmdb:
        result = _getTrakt(
            "/sync/history/remove",
            {
                "shows": [
                    {
                        "seasons": [{"episodes": [{"number": episode}], "number": season}],
                        "ids": {"tmdb": tmdb},
                    }
                ]
            },
        )
    fflog(result)
    return result


def getMovieTranslation(id, lang, full=False):
    url = "/movies/%s/translations/%s" % (id, lang)
    try:
        item = getTraktAsJson(url)[0]
        return item if full else item.get("title")
    except:
        pass


def getTVShowTranslation(id, lang, season=None, episode=None, full=False):
    if season and episode:
        url = "/shows/%s/seasons/%s/episodes/%s/translations/%s" % (
            id,
            season,
            episode,
            lang,
        )
    else:
        url = "/shows/%s/translations/%s" % (id, lang)

    try:
        item = getTraktAsJson(url)[0]
        return item if full else item.get("title")
    except:
        pass


def getMovieAliases(id):
    try:
        return getTraktAsJson("/movies/%s/aliases" % id)
    except:
        return []


def getTVShowAliases(id):
    try:
        return getTraktAsJson("/shows/%s/aliases" % id)
    except:
        return []


def getMovieSummary(id, full=True):
    try:
        url = "/movies/%s" % id
        if full:
            url += "?extended=full"
        return getTraktAsJson(url)
    except:
        return


def getTVShowSummary(id, full=True):
    try:
        url = "/shows/%s" % id
        if full:
            url += "?extended=full"
        return getTraktAsJson(url)
    except:
        return


def getPeople(id, content_type, full=True):
    try:
        url = "/%s/%s/people" % (content_type, id)
        if full:
            url += "?extended=full"
        return getTraktAsJson(url)
    except:
        return


def SearchAll(title, year, full=True):
    try:
        return SearchMovie(title, year, full) + SearchTVShow(title, year, full)
    except:
        return


def SearchMovie(title, year, full=True):
    try:
        url = "/search/movie?query=%s" % quote_plus(title)

        if year:
            url += "&year=%s" % year
        if full:
            url += "&extended=full"
        return getTraktAsJson(url)
    except:
        return


def SearchTVShow(title, year, full=True):
    try:
        url = "/search/show?query=%s" % quote_plus(title)

        if year:
            url += "&year=%s" % year
        if full:
            url += "&extended=full"
        return getTraktAsJson(url)
    except:
        return


def IdLookup(content, type, type_id):
    try:
        r = getTraktAsJson("/search/%s/%s?type=%s" % (type, type_id, content))
        return r[0].get(content, {}).get("ids", [])
    except:
        return {}


def getGenre(content, type, type_id):
    try:
        r = "/search/%s/%s?type=%s&extended=full" % (type, type_id, content)
        r = getTraktAsJson(r)
        r = r[0].get(content, {}).get("genres", [])
        return r
    except:
        return []


def trakt_languages(content: str = 'movies'):
    res = _getTrakt(f'languages/{content}')
    if res:
        return json.loads(res)
