
import re
from typing import Optional, Any, Tuple, List, Sequence, Iterator, TYPE_CHECKING
from typing_extensions import TypedDict, Unpack, NotRequired, Type, Literal
from contextlib import contextmanager
from argparse import ArgumentParser, Namespace, Action
from ..defs import MediaRef
if TYPE_CHECKING:
    from argparse import _FormatterClass


class ParserKwArgs(TypedDict):
    prog: NotRequired[Optional[str]]
    usage: NotRequired[Optional[str]]
    description: NotRequired[Optional[str]]
    epilog: NotRequired[Optional[str]]
    parents: NotRequired[Sequence[ArgumentParser]]
    formatter_class: NotRequired['_FormatterClass']
    prefix_chars: NotRequired[str]
    fromfile_prefix_chars: NotRequired[Optional[str]]
    argument_default: NotRequired[Optional[str]]
    conflict_handler: NotRequired[Literal['error', 'resolve']]
    add_help: NotRequired[bool]
    allow_abbrev: NotRequired[bool]
    exit_on_error: NotRequired[bool]


class AddSubparsersKwArgs(TypedDict):
    title: NotRequired[str]
    description: NotRequired[Optional[str]]
    prog: NotRequired[Any]
    parser_class: NotRequired[Type[ArgumentParser]]
    action: NotRequired[str]
    option_strings: NotRequired[Optional[str]]
    dest: NotRequired[Optional[str]]
    required: NotRequired[bool]
    help: NotRequired[Optional[str]]
    metavar: NotRequired[Optional[str]]


class AddParserKwArgs(TypedDict):
    help: NotRequired[Optional[str]]
    aliases: NotRequired[Sequence[str]]
    prog: NotRequired[Optional[str]]
    usage: NotRequired[Optional[str]]
    description: NotRequired[Optional[str]]
    epilog: NotRequired[Optional[str]]
    parents: NotRequired[Sequence[ArgumentParser]]
    formatter_class: NotRequired['_FormatterClass']
    prefix_chars: NotRequired[str]
    fromfile_prefix_chars: NotRequired[Optional[str]]
    argument_default: NotRequired[Any]
    conflict_handler: NotRequired[str]
    add_help: NotRequired[bool]
    allow_abbrev: NotRequired[bool]
    exit_on_error: NotRequired[bool]


class DebugArgumentParser(ArgumentParser):

    def __init__(self, *, dest: Optional[str] = None, **kwargs: Unpack[ParserKwArgs]) -> None:
        super().__init__(**kwargs)
        self._ff_subparsers_dest: Optional[str] = dest
        self._ff_subparsers: Optional[Action] = None

    def parse_known_args(self,  # type: ignore
                         args: Optional[Sequence[str]] = None,
                         namespace: Any = None,
                         ) -> Tuple[Namespace, List[str]]:
        if args is None:
            from .. import cmdline_argv
            args = cmdline_argv[1:]
        return super().parse_known_args(args, namespace)

    @contextmanager
    def with_subparser(self, name: str, dest: Optional[str] = None, **kwargs: Unpack[AddParserKwArgs]) -> Iterator['DebugArgumentParser']:
        if self._ff_subparsers is None:
            pp_kwargs = {}
            if self._ff_subparsers_dest is not None:
                pp_kwargs['dest'] = self._ff_subparsers_dest
            self._ff_subparsers = self.add_subparsers(**pp_kwargs)
        yield self._ff_subparsers.add_parser(name, dest=dest, **kwargs)  # type: ignore


def parse_ref(v: str) -> MediaRef:
    if mch := re.fullmatch(r'movie/(\d+)', v):
        return MediaRef.movie(int(mch[1]))
    if mch := re.fullmatch(r'show/(\d+(?:/\d+(?:/\d+)?)?)', v):
        return MediaRef.tvshow(*map(int, mch[1].split('/')))
        # return MediaRef.tvshow(*map(int, mch.group(1, 2, 3)))
    if v[:1] in 'Mm':
        return MediaRef('movie', int(v[1:]))
    if v[:1] in 'Ttse':
        return MediaRef('show', *map(int, v[1:].split('/')))
    if v[:1] in 'S':
        return MediaRef('season', int(v[1:]))
    if v[:1] in 'E':
        return MediaRef('episode', int(v[1:]))
    raise ValueError(f'Incorrect media ref {v!r}')


if __name__ == '__main__':
    p = DebugArgumentParser(dest='x')
    with p.with_subparser('aa') as o:
        o.add_argument('-a')
    with p.with_subparser('bb') as o:
        o.add_argument('-b')
    print(p.parse_args())
