# coding:utf-8
from ._typing import Details

__all__ = [
    'Details'
]
