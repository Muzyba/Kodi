"""
    FanFilm Add-on
    Copyright (C) 2018 :)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
from datetime import datetime

import requests

try:
    pass
except Exception:
    pass

from lib.ff import cleantitle, client, control, source_utils

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.75 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Pragma": "no-cache",
    "Cache-Control": "no-cache",
    "TE": "Trailers",
}


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["shinden.pl"]

        self.base_link = "https://shinden.pl"
        self.search_link = "https://shinden.pl/titles?search=%s"
        self.user_name = control.settings.getString("shinden.username")
        self.user_pass = control.settings.getString("shinden.password")
        self.session = requests.Session()
        self.cookies = ""
        self.anime = True

    def levenshtein_distance(self, s1, s2):
        if len(s1) > len(s2):
            s1, s2 = s2, s1

        distances = range(len(s1) + 1)
        for index2, char2 in enumerate(s2):
            new_distances = [index2 + 1]
            for index1, char1 in enumerate(s1):
                if char1 == char2:
                    new_distances.append(distances[index1])
                else:
                    new_distances.append(
                        1
                        + min(
                            (
                                distances[index1],
                                distances[index1 + 1],
                                new_distances[-1],
                            )
                        )
                    )
            distances = new_distances

        return distances[-1]

    def contains_word(self, str_to_check, word, max_distance=2):
        words_in_str = str_to_check.split()
        for w in words_in_str:
            if self.levenshtein_distance(w, word) <= max_distance:
                return True
        return False

    def contains_all_words(
        self, str_to_check, words, allowed_missing=0, max_distance=2
    ):
        missing_count = 0
        for word in words:
            if not self.contains_word(str_to_check, word, max_distance):
                missing_count += 1
                # Check the length of the words list
                if len(words) > 2 and missing_count > allowed_missing:
                    return False
                elif len(words) <= 2:
                    return False
        return True

    def tvshow(self, imdb, tmdb, tvshowtitle, localtvshowtitle, aliases, year):
        return (tvshowtitle, localtvshowtitle), year, aliases

    def episode(self, url, imdb, tmdb, title, premiered, season, episode):
        return self.search_ep(url[0], season, episode, tmdb, url[1], premiered, url[2])

    def get_normalized_title(self, title):
        return cleantitle.normalize(title)

    def get_search_results(self, titles, headers, aliases):
        results = []

        # Extract Japanese titles from the aliases list
        jp_titles_from_aliases = [
            alias["title"] for alias in aliases if alias["country"] == "jp"
        ]

        # Concatenate them with the original titles
        combined_titles = jp_titles_from_aliases + list(titles)

        for title in combined_titles:
            normalized_title = self.get_normalized_title(title)
            search_title = normalized_title.replace(" ", "+").replace(
                "shippuden", "shippuuden"
            )
            filtr = "&series_type%5B0%5D=TV&series_type%5B1%5D=ONA&series_type%5B2%5D=OVA&series_status%5B0%5D=Currently+Airing&series_status%5B1%5D=Finished+Airing&series_length%5B0%5D=7_to_18&series_length%5B1%5D=19_to_27&series_length%5B2%5D=28_to_48&series_length%5B3%5D=over_48&series_number%5B0%5D=2_to_14&series_number%5B1%5D=15_to_28&series_number%5B2%5D=29_to_100&series_number%5B3%5D=over_100&one_online=true"
            r = self.session.get(
                self.search_link % search_title + filtr, headers=headers
            ).text
            results.extend(client.parseDOM(r, "li", attrs={"class": "desc-col"}))

        return results

    def search_ep(self, titles, season, episode, tmdb, year, premiered, aliases):
        try:
            data_premiered = datetime.strptime(premiered, "%Y-%m-%d").date()
            cookies = client.request("https://shinden.pl/", output="cookie")

            if self.user_name and self.user_pass:  # Logowanie
                headers = {
                    "authority": "shinden.pl",
                    "cache-control": "max-age=0",
                    "origin": "https://shinden.pl",
                    "upgrade-insecure-requests": "1",
                    "dnt": "1",
                    "content-type": "application/x-www-form-urlencoded",
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.27 Safari/537.36",
                    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
                    "referer": "https://shinden.pl/",
                    "accept-encoding": "gzip, deflate, br",
                    "accept-language": "pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7",
                }
                headers.update({"Cookie": cookies})
                data = {
                    "username": self.user_name,
                    "password": self.user_pass,
                    "login": "",
                }

                cookie = requests.post(
                    "https://shinden.pl/main/0/login", headers=headers, data=data
                )
                kuki = cookie.cookies.items()
                self.cookies = "; ".join([str(x) + "=" + str(y) for x, y in kuki])
                if not cookie:
                    self.cookies = cookies

            HEADERS["Cookie"] = self.cookies

            total_episodes, absolute_number = source_utils.get_absolute_number_tmdb(
                tmdb, season, episode
            )

            results = self.get_search_results(titles, HEADERS, aliases)

            for result in results:
                if not result.startswith("<h3>"):
                    continue

                try:
                    link, tytul = self.process_result_row(result)
                except Exception:
                    continue

                if not link or not tytul:
                    continue

                # Concatenate titles and Japanese aliases
                jp_titles_from_aliases = [
                    alias["title"] for alias in aliases if alias["country"] == "jp"
                ]
                combined_titles = jp_titles_from_aliases + list(titles)

                for combined_title in combined_titles:
                    normalized_title = self.get_normalized_title(combined_title)
                    words = normalized_title.split(" ")
                    if self.contains_all_words(tytul, words, allowed_missing=1):
                        episode_link = self.get_episode_link(
                            link,
                            data_premiered,
                            HEADERS,
                            total_episodes,
                            absolute_number,
                        )
                        if episode_link:
                            return episode_link

        except Exception as e:
            print(e)
            return

    def process_result_row(self, result):
        link = next(
            (
                item
                for item in client.parseDOM(result, "a", ret="href")
                if item.startswith(("/titles", "/series"))
            ),
            None,
        )
        print(link)
        tytul_matches = re.findall(r"<a href.*?>(.*?)</a>", result)

        if not tytul_matches:
            return None, None

        tytul = tytul_matches[0].replace("<em>", "").replace("</em>", "")
        return link, self.get_normalized_title(tytul)

    def get_episode_link(
        self, link, data_premiered, headers, total_episodes, absolute_number
    ):
        try:
            full_link = self.base_link + link + "/all-episodes"
            result = self.session.get(full_link, headers=headers).text
            episodes = client.parseDOM(
                result, "tbody", attrs={"class": "list-episode-checkboxes"}
            )
            episodes = client.parseDOM(episodes, "tr")
            aired_date_exception = False
            for episode in episodes:
                try:
                    aired_date = datetime.strptime(
                        client.parseDOM(episode, "td")[4], "%Y-%m-%d"
                    ).date()
                    difference = abs((aired_date - data_premiered).days)
                    if difference <= 2:
                        return (
                            self.base_link
                            + client.parseDOM(episode, "a", ret="href")[0]
                        )
                except Exception:
                    aired_date_exception = True
                    continue

            if aired_date_exception:
                start_date_match = re.search(
                    r"Data emisji:<\/dt>.*?(\d{2}\.\d{2}\.\d{4})<\/dd>",
                    result,
                    re.M | re.S | re.I,
                )
                end_date_match = re.search(
                    r"Koniec emisji:<\/dt>.*?(\d{2}\.\d{2}\.\d{4})<\/dd>",
                    result,
                    re.M | re.S | re.I,
                )
                if start_date_match and end_date_match:
                    start_date_match = datetime.strptime(
                        start_date_match.group(1), "%d.%m.%Y"
                    ).date()
                    end_date_match = datetime.strptime(
                        end_date_match.group(1), "%d.%m.%Y"
                    ).date()
                    if (
                        data_premiered >= start_date_match
                        and data_premiered <= end_date_match
                        and len(episodes) == total_episodes
                    ):
                        print(
                            f"shinden, daty sie zgadzają. Total={total_episodes}, absolute={absolute_number}"
                        )
                        return (
                            self.base_link
                            + [
                                x
                                for x in client.parseDOM(episodes, "a", ret="href")
                                if "view" in x
                            ][absolute_number - 1]
                        )
            return None
        except Exception as e:
            print(e)
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.75 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Pragma": "no-cache",
            "Cache-Control": "no-cache",
            "TE": "Trailers",
            "Cookie": self.cookies,
        }

        try:
            content = requests.get(url, headers=headers).text
            results = client.parseDOM(
                content, "section", attrs={"class": "box episode-player-list"}
            )
            results = client.parseDOM(results, "tr")

            for item in results:
                try:
                    item_elems = client.parseDOM(item, "td")
                    host = (
                        "VIDOZA" if "vidoza" in item_elems[0].lower() else item_elems[0]
                    )
                    quality = source_utils.check_sd_url(item_elems[1])

                    audio = client.parseDOM(
                        item_elems[2], "span", attrs={"class": "mobile-hidden"}
                    )[0]
                    jezyk = "pl" if "Polski" in audio else "en"

                    napisy = (
                        client.parseDOM(
                            item_elems[3], "span", attrs={"class": "mobile-hidden"}
                        )[0]
                        if jezyk == "en"
                        else ""
                    )

                    info = (
                        "Polskie Audio"
                        if "Polski" in audio
                        else ("Napisy " + napisy if napisy else "")
                    )

                    id = re.findall('''data_(.*?)\"''', str(item_elems[5]))[0]
                    code = re.findall(r"""_Storage\.basic.*=.*'(.*?)'""", content)[0]
                    video_link = (
                        f"https://api4.shinden.pl/xhr/{id}/player_load?auth={code}"
                    )

                    source_data = {
                        "source": host,
                        "quality": quality,
                        "language": jezyk,
                        "url": video_link,
                        "info": info,
                        "direct": False,
                        "debridonly": False,
                    }

                    sources.append(source_data)
                except Exception as e:
                    print(str(e))

            return sources

        except Exception as e:
            print(str(e))
            return sources

    def get_lang_by_type(self, lang_type):
        if "dubbing" in lang_type.lower():
            if "kino" in lang_type.lower():
                return "pl", "Dubbing Kino"
            return "pl", "Dubbing"
        elif "lektor pl" in lang_type.lower():
            return "pl", "Lektor"
        elif "lektor" in lang_type.lower():
            return "pl", "Lektor"
        elif "napisy pl" in lang_type.lower():
            return "pl", "Napisy"
        elif "napisy" in lang_type.lower():
            return "pl", "Napisy"
        elif "POLSKI" in lang_type.lower():
            return "pl", None
        elif "pl" in lang_type.lower():
            return "pl", None
        return "en", None

    def resolve(self, url):
        import time

        headers = {
            "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Cache-Control": "max-age=0",
            "TE": "Trailers",
        }
        if str(url).startswith("//"):
            url = "http://" + url
        cookies = client.request(url, headers=headers, output="cookie")
        headers.update({"Cookie": cookies})
        time.sleep(5)
        video = client.request(
            url.replace("player_load", "player_show") + "&width=508", headers=headers
        )
        try:
            video = client.parseDOM(video, "iframe", ret="src")[0]
        except Exception:
            video = client.parseDOM(video, "a", ret="href")[0]
        if str(video).startswith("//"):
            video = "https:" + video
        return str(video)
