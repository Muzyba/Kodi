"""
    FanFilm Add-on
    Copyright (C) 2024 :)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
import threading
import time
from ast import literal_eval
from html import unescape
from urllib.parse import unquote

import requests
import urllib3

from lib.ff import (
    cache,
    cleantitle,
    client,
    control,
    source_utils,
)
from lib.ff.debug import log_exception
from lib.ff.log_utils import fflog, fflog_exc

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class source:
    """Scraper dla serwisu xt7.pl"""

    # This class has support for *.sort.order setting
    has_sort_order: bool = True
    # This class has support for *.color.identify2 setting
    has_color_identify2: bool = True
    # This class has support for *.library.color.identify2 setting
    has_library_color_identify2: bool = True
    # Mark sources with prem.color.identify2 setting
    use_premium_color: bool = True

    def __init__(self):
        self.VIDEO_EXTENSIONS = ("avi", "mkv", "mp4", "mpg", ".ts")  # trzymać 3 znaki długości dla każdego elementu
        self.lock = threading.Lock()
        self.raw_results = []
        self.results = []
        self.trash = []
        self.titles = []
        self.titles_requested = []
        self.pages = []
        self.priority = 1
        # self.tit_val_filt_for_one_title = None
        self.dodatkowy_filtr = None
        self.dodatkowy_filtr2 = None
        self.language = ["pl"]
        self.domains = ["xt7.pl"]
        self.base_link = "https://xt7.pl/"
        self.login_link = "login"
        self.mylibrary_link = "mojekonto/pliki"
        self.mynotepad_link = "mojekonto/notes"

        if control.settings.getBool("xt7.wiele_serwerow"):
            self.search_link = "mojekonto/szukaj"
            self.support_search_link = "mojekonto/szukaj/{}"  # do paginacji wyników
        else:
            self.search_link = "mojekonto/szukajka"
            self.support_search_link = "mojekonto/szukajka/{}"  # do paginacji wyników

        self.session = requests.Session()
        self.user_name = control.settings.getString("xt7.username")
        self.user_pass = control.settings.getString("xt7.password")
        self.headers = {
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.53 Safari/537.36",
            "DNT": "1",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7",
        }


    def movie(self, imdb, title, localtitle, aliases, year):
        fflog('szukanie żródeł filmu', 0)
        return self.search(title, localtitle, year, aliases=aliases)

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        """ jakaś proteza pomocnicza przed szukaniem odcinka """
        return (tvshowtitle, localtvshowtitle, aliases), year

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        fflog('szukanie źródeł odcinka', 0)
        try:
            anime = source_utils.is_anime("show", "tvdb", tvdb)
        except Exception:
            anime = None
        if anime:
            epNo = source_utils.absoluteNumber(tvdb, episode, season)
        else:
            epNo = f"s{season.zfill(2)}e{episode.zfill(2)}"
            # epNo = f"s{season.zfill(2)}e{episode.zfill(3)}"  # dla seriali co mają więcej niż 99 odcinków na sezon, tylko jak to wykryć ?
        return self.search(url[0][0], url[0][1], episode=epNo, aliases=url[0][2])

    def search(self, title, localtitle, year="", episode="", aliases=None):
        """Funkcja wysyła do serwera zapytania:
        oryginalny tytuł filmu oraz tłumaczenie tytułu
        """
        results = []

        if aliases is None:
            aliases = []

        year = str(year)  # dla kompatybilności, gdy zmienna jest innego typu niż string

        try:
            # przechowanie zmiennej pod inną nazwą (będzie potrzebna później)
            title0 = title

            # jak brak opisu polskiego, a powinien być, to by nie odrzucało filmów co w nazwie mają polski tytuł
            # self.tit_val_filt_for_one_title = (title == localtitle)

            aliases1 = [
                (a.get("title") or a.get("originalname") or "")
                + " ("
                + a.get("country", "")
                + ")"
                for a in aliases
                # if a.get("country") in ("us", "en", "uk", "gb", "au", "pl", "original")
            ]
            aliases2 = [a.partition(" (")[0] for a in aliases1]  # country out
            aliases2 = [a.replace(year, "").strip(" ()") for a in aliases2]
            # aliases2 = [a for a in aliases2 if re.search(r"[a-z0-9]", a, flags=re.I)]  # krzaczki out
            aliases2 = [a for a in aliases2 if not source_utils.czy_litery_krzaczki(a)]  # krzaczki out
            # aliases2 = list(dict.fromkeys(aliases2))  # duplicates out (ale tylko o tej samej wielkości liter)
            aliases2 = [alias for i, alias in enumerate(aliases2) if alias.lower() not in [x.lower() for x in aliases2[:i]]]  # kolejne duplikaty są usuwane niezależnie od wielkości liter
            # fflog(f'{aliases2=}')
            # aliases2.append('Rogue One: A Star Wars')  # test tylko
            # dodanie do późniejszego porównywania z nazwami plików
            self.titles = aliases2

            log_text = ""
            log_text += f"tytuł: {title!r}"
            log_text += f", polski tytuł: {localtitle!r}" if localtitle != title else ""
            log_text += f", rok (premiery): {year!r}" if year else ""
            log_text += f", odcinek: {episode!r}" if episode else ""
            log_text += f', aliasy tytułów: {aliases2!r}' if aliases else ''
            # log_text += "\nALIASY2:\n "+("\n"+chr(32)).join(map(repr,aliases2)) if aliases else ''
            # log_text += "\nALIASY1:\n "+("\n"+chr(32)).join(map(repr,aliases1)) if aliases else ''
            fflog(f" {log_text}")

            titles = [title, localtitle]
            # dodanie do późniejszego porównywania z nazwami plików
            self.titles = titles + self.titles

            # # sprawdzenie, czy można zredukować listę tytułów
            # if (
            #     re.sub(r"\bthe\b", "", title, flags=re.I).strip().lower()
            #     == localtitle.lower()
            # ):  # np. film "The Batman"
            #     titles = [title]

            # czysczenie z "niepożądanych" znaków (w tym diakrytycznych)
            titles = [cleantitle.normalize(cleantitle.getsearch(t)) for t in titles]

            titles = list(filter(None, titles))  # usunięcie pustych
            titles = list(dict.fromkeys(titles))  # pozbycie się duplikatów

            titles0 = titles.copy()  # potrzebne do powiązania zadanego title i localtitle z wynikami

            # dodanie do późniejszego porównywania z nazwami plików
            self.titles = titles + self.titles

            self.titles = list(filter(None, self.titles))
            self.titles = list(dict.fromkeys(self.titles))
            # fflog(f"self.titles:{new_line}{new_line.join(self.titles)}")

            # przekształcenia tak jak dla titles (przyda się później)
            aliases2 = [cleantitle.normalize(cleantitle.getsearch(a)) for a in aliases2]
            # dla filmów można próbować redukować zapytania,
            #  ale dla seriali ponieważ może być doklejany numer odcinka
            #  i trzeba to robić oddzielnie dla tytułu oryginalnego i polskiego
            if not episode:
                aliases2 += titles
                aliases2 = list(dict.fromkeys(aliases2))
            # fflog(f"{aliases2=}")

            # """ serwis xt7 bardzo długo kazał czekać na wyniki, więc wymyśliłem
            # zapamiętywanie wyników, aby następne zapytania dotyczące tego samego tytułu
            # były szybciej zwracane użytkownikowi """
            # ostatni czas, jaki był potrzebny do zakończenia obsługi wszystkich requestów
            last_total_time = cache.cache_get("xt7_results-last_total_time", control.sourcescacheFile)
            if last_total_time:
                last_total_time = int(last_total_time["value"])
            else:
                last_total_time = 0

            # funkcja pomocnicza
            def check_if_finished():
                results_cache_fin = cache.cache_get("xt7_results_finished", control.sourcescacheFile)
                # fflog(f'{results_cache_fin=} ')
                if results_cache_fin:
                    results_cache_val = results_cache_fin["value"]
                    if results_cache_val and klucz in results_cache_val:
                        results_cache_val = literal_eval(results_cache_val)
                        finished = results_cache_val[klucz]
                        return finished
                return None

            # czy wykonywać ponowny request do serwera, bo może można wykorzystać ostatnie wyniki
            # zależy od szukanych tytułów (rok i episod nie mają znaczenia)
            dont_request = False
            klucz = repr(titles0)
            results_cache_fin = cache.cache_get("xt7_results_finished", control.sourcescacheFile)
            # fflog(f'{results_cache_fin=} ')
            if results_cache_fin:
                results_cache_val = results_cache_fin["value"]
                results_cache_date = results_cache_fin["date"]
                # klucz = repr(titles0)
                # if any(re.search(r'e\d{2,3}', v) for v in literal_eval(results_cache_val)):
                if re.search(r'e\d{2,3}', results_cache_val):
                    klucz += episode
                if klucz not in results_cache_val:
                    # brak zgodności tytułów
                    cache.cache_insert("xt7_results", "", control.sourcescacheFile)
                    cache.cache_insert("xt7_results_finished", "", control.sourcescacheFile)
                    cache.cache_insert("xt7_raw_results", "", control.sourcescacheFile)
                else:
                    # tytuły się zgadzają
                    # czy nie jest pusty i czy jest tam tytuł jako klucz
                    if results_cache_val and klucz in results_cache_val:
                        results_cache_val = literal_eval(results_cache_val)
                        # czy skończone, czy w trakcie (liczba to czas, jaki był wymagany do zakończenia wyszukiwania dla tych tytułów)
                        finished = results_cache_val[klucz]
                        # fflog(f'{finished=}')
                        now = int(time.time())
                        delta_t = now - int(results_cache_date)
                        # delta_t = 0  # dla testów tylko
                        if delta_t < (5 * 60):  # 5 minut
                            dont_request = True  # bezpieczniej dać także tu
                            if not finished:
                                timeout = control.settings.getInt("scrapers.timeout.1")
                                check_interval = 5  # w sekundach
                                fflog("... czekam na zakończenie poprzedniego requesta")
                                for i in range(
                                    int(
                                        max(10, int(timeout - 10))
                                        / check_interval
                                    )
                                ):  # czeka prawie do końca timeoutu
                                    # fflog(f"pętla czekająca na zakończenie zapisu z poprzedniego requesta {i=}")
                                    time.sleep(check_interval)
                                    f = check_if_finished()
                                    # fflog(f"?czy skończony poprzedni request: {f=}")
                                    if f is None:
                                        dont_request = False  # choć nie wiem ile czasu zostało i czy nowy request zdąży się wykonać
                                        break
                                    if f:
                                        dont_request = True
                                        break
                                # tu można by (w tej linijce) dać kod, gdy nie doczekaliśmy się skończenia poprzedniego requestu
                                if (not dont_request
                                    and ( (timeout - int(time.time()) - now)
                                            < (last_total_time + 10)
                                    )
                                ):
                                    return []  # bo nie zdąży się wykonać następny request
                            else:
                                dont_request = True

            saved_to_cache = False

            def korekty_dla_wyszukiwarki_xt7(title):
                # korekty specyficzne dla wyszukiwarki xt7
                title = title.replace(" - ", " ")  # pomaga np. dla "mission impossible - ghost protocol"
                title = title.replace("-", "_")  # pomogło dla filmu "'E.T. the Extra-Terrestrial"
                title = title.replace(". ", ".")  # np. dla serialu Mr. Robot
                title = title.replace(".", "_")
                # title = title.replace(".", "_") if "_" in title else title  # 'Book Club.Następny rozdział'
                title = title.replace(" ", "_")  # np. "transformers_rise_of_the_beasts"
                title = title.replace(",", "")  # na przypadek "Poszukiwany, poszukiwana"
                title = title.replace("#", "")  # na przypadek "#BringBackAlice"
                title = re.sub(r'_?(\d)⁄', r'_\1_', title)  # na przypadek "Naga Broń 2 1/2"
                title = title.replace("_", " ")  # teraz już podkreślenie niepotrzebne
                return title

            # w poprzednich wynikach może nie być źródeł dla innego odcinka
            if dont_request:
                for title1 in titles:
                    self.titles = [korekty_dla_wyszukiwarki_xt7(title1)] + self.titles
                self.titles = list(dict.fromkeys(self.titles))
                self.get_pages_content(None, year, "", episode, aliases)
                results = self.results
                if not results:
                    dont_request = False

            if dont_request:
                fflog(f"NIE wykonuje ponownego requestu, bo od ostatniego minęło {delta_t} sek. ( < 300 )")
            else:
                # oznaczenie, że proces jeszcze nie został skończony
                cache.cache_insert(
                    "xt7_results_finished",
                    repr({klucz: 0}),
                    control.sourcescacheFile
                )
                saved_to_cache = True

                aliases3 = [korekty_dla_wyszukiwarki_xt7(a) for a in aliases2]  # przygotowanie do wybrania lepszej frazy do wyszukiwarki

            self.login()

            # zapisanie podstron "notes" oraz "pliki" do cache
            # potrzebne do awaryjnego odzyskiwania źródeł
            biblio_cache, biblio_links = self.files_on_user_account(from_cache=False)[0:2]

            titles2 = episode_added = last_chance = originalname = None

            now0 = int(time.time())

            for title1 in titles:
                # fflog(f"titles: ({len(titles)}) \n" + "\n".join(titles))  # kontrola
                title = title1  # potrzeba zachowania niezmodyfikowanej nazwy

                title = korekty_dla_wyszukiwarki_xt7(title)

                # dodanie do późniejszego porównywania z nazwami plików
                if title not in self.titles:
                    self.titles = [title] + self.titles

                if dont_request:
                    continue

                # może uda się znaleźć lepszą frazę do wysłania do wyszukiwarki?
                requesty_for_title = [a for a in aliases3 if re.search(f"^{re.escape(a)}", title)] if len(titles) == len(titles0) else []
                # czy obie poniższe dadzą takie same rezultaty?
                # requesty_for_title.sort()
                requesty_for_title.sort(key=lambda e: len(e))
                # fflog(f"{requesty_for_title=}")
                title_r = requesty_for_title[0] if requesty_for_title else title

                if len(title_r) < 3:  # trzeba tak dla krótkich tytułów  "To" ("It"), "65"
                    title_r += f' {year!s}'

                # wg sugestii jednego z testerów ma pomóc na "blood_&_treasure"
                # if "&" in title_r:
                #     title_r = title_r.replace("&", "_and_")  # teraz już nie ("wplik" inaczej niż "wrzucaj" wyszukiwał)
                #     title_r = title_r.replace("__", "_")

                title_r = title_r.replace("_", " ")  # od 2024r podkreślenie w domyślnej wyszukiwarce xt7 jest złe
                title_r = title_r.replace("  ", " ")  # ewentualnie uprzątnięcie

                # dziwna przypadłość wyszukiwarki - nie wyszukuje "batman", ale "batman_" już tak (to samo dla "kruk", ale dla np. "dom" nie ma problemu)
                # wciąż szukam najlepszego znaku, bo różne serwery różnie je traktują
                # if " " not in title_r:
                if not re.search(r"\W", title_r.rstrip("%")):
                    if title_r[-1] != "%":
                        title_r += "%"

                # fflog(f'{title_r=} {self.titles_requested=}')
                if title_r not in self.titles_requested:

                    fflog(f"WYSŁANIE zapytania: {title_r!r}")

                    self.titles_requested.append(title_r)
                    # fflog(f"self.titles_requested: ({len(self.titles_requested)}) \n" + "\n".join(self.titles_requested))  # kontrola

                    now1 = int(time.time())  # do zmierzenia czasu obsługi zapytania przez serwer
                    # przygotwanie danych do wysyłki (zapytania)
                    post = {
                            "search": title_r,
                            "type": "1"
                        }
                    # wysłanie zapytania typu POST
                    pre_res = (
                        self.session.post(
                            self.base_link+self.search_link,
                            headers=self.headers,
                            data=post).text.replace("\r", "").replace("\n", "")
                            )
                    now2 = int(time.time())
                    fflog(f" Czas odpowiedzi z serwera: {now2 - now1} sek.")

                    # sprawdzenie co jest w odpowiedzi
                    page_block = re.search('class="page-list"(.+?)</div>', pre_res, re.IGNORECASE)
                    if page_block is not None:
                        pages = len(re.findall("href=", page_block.group()))
                        self.pages.append({title1: pages})
                        fflog(f" sprawdzanie otrzymanych wyników ({pages} podstr.)")
                        # for page in range(pages):
                        #     self.get_pages_content(page + 1, year, title, episode)
                        self.get_pages_content(range(pages), year, title, episode)

                        results = self.results

                        if not results:
                            fflog(' brak pasujących rekordów')

                        # dodanie do cache w razie jakby kolejna pętla nie zdążyła się wykonać a nadszedł Timeout
                        # fflog(f"Łącznie zapisano w cache rekordów: {len(results)}")
                        klucz = (
                            repr(titles0)
                            if len(titles) == len(titles0) or not episode
                            else repr(titles0)+episode
                        )
                        # dane przefiltrowane
                        cache.cache_insert(
                            "xt7_results",
                            repr({klucz: results}),
                            control.sourcescacheFile
                        )
                        # dane "surowe" (wykorzystywane, jak nie jest robiony ponowny request)
                        cache.cache_insert(
                            "xt7_raw_results",
                            repr({klucz: self.raw_results}),
                            control.sourcescacheFile
                        )
                        saved_to_cache = True
                    else:
                        fflog(" nie otrzymano wyników")
                else:
                    fflog(f"Pominięto wysłanie zapytanie {title_r!r} (bo już wystąpiło takie)")

                if not results and title1 == titles[-1]:  # ostatni

                    max_p = max((val for p in self.pages for val in p.values()), default=0)

                    # próba wykluczenia pewnych fraz z tytułów
                    if (
                        episode
                        and (
                            not self.pages  # brak wyników
                            or max_p == 1
                        )
                        and not titles2  # aby nie było nieskończoności
                    ):
                        title_phrases_exceptions = source_utils.antifalse_filter_exceptions
                        for ex in title_phrases_exceptions:
                            titles2 = [re.sub(rf"([ _\W]+{ex})", "", t, flags=re.I) for t in titles]
                            titles2 = [t for t in titles2 if t not in titles]
                            titles += titles2
                        if titles2:
                            continue

                    # wyszukiwarka xt7 zwraca maksymalnie tylko 4 podstrony (jakieś ograniczenie)
                    # i jak jest bardzo dużo odcinków dla danego serialu, to przy wyszukiwaniu tylko samego tytułu
                    # może okazać się, że odcinka, którego szukamy nie będzie w wynikach, dlatego
                    # dodanie numeru odcinka do tytułu
                    if (
                        episode
                        and self.pages
                        and not episode_added  # aby nie było nieskończoności
                    ):
                        if max_p >= 4 or " " not in "".join(titles0):
                            for t in titles:
                                for p in self.pages:
                                    # tylko dla tytułów, ktore miały najwięcej podstron
                                    if t in p and p[t] == max_p:
                                        if not re.search(r"e\d?\d{2}", t, flags=re.I):
                                            episode_added = True
                                            titles.append(f"{t} {episode}")
                            if episode_added:
                                continue

                    # niektóre seriale nie mają sezonów
                    if (
                        episode_added
                        and not last_chance
                        and re.search(r"s01(e.*)", episode, flags=re.I)
                    ):
                        for t in titles:
                            for p in self.pages:
                                if t in p and p[t] == max_p:
                                    if re.search(r"s01(e.*)", t, flags=re.I):
                                        last_chance = True
                                        ep_only = re.sub(r"s01(e.*)", r"\1", episode)
                                        t = re.sub(r" s01(e.*)", "", t)
                                        titles.append(f"{t} {ep_only}")
                        if last_chance:
                            continue

                    # wykorzystanie oryginalnego tytułu nieanglojęzycznego
                    if (
                        not episode  # dla filmów tylko
                        and not originalname
                    ):
                        originalname = [a for a in aliases if "originalname" in a]
                        originalname = originalname[0]["originalname"] if originalname else ""
                        if (
                            originalname
                            and originalname != title0
                            and originalname != localtitle
                            # and re.search(r"[a-z0-9]", originalname, flags=re.I)  # aby wykluczyć japońskie znaki
                            and not source_utils.czy_litery_krzaczki(originalname)  # aby wykluczyć japońskie znaki
                        ):
                            titles.append(originalname)
                            continue

            if control.settings.getBool("sources.title_validation_filter"):  # bo inaczej do każdego szukania będzie zawsze dowalać pozycje z bilioteki
                rows = []
                if biblio_cache:
                    for b in biblio_cache.values():
                        href = b.get("url")
                        host = b.get("source")
                        fnme = b.get("filename")
                        size = b.get("size")
                        rows.append(f'<tr>\
                                        <td><input value="{href}"></td>\
                                        <td>{host}</td>\
                                        <td><label>{fnme}</label></td>\
                                        <td>{size}</td>\
                                    </tr>')
                elif biblio_links:
                    for fn in biblio_links:
                        href = fn[0]
                        fnme = unescape(unquote(fn[0].rpartition("/")[-1]))
                        rows.append(f'<tr>\
                                        <td><input value="{href}"></td>\
                                        <td></td>\
                                        <td><label>{fnme}</label></td>\
                                        <td></td>\
                                    </tr>')
                if rows:
                    self.get_pages_content(None, year, "", episode, aliases, rows)
                    results = self.results

            if saved_to_cache:
                now3 = int(time.time())
                tt = now3 - now0
                fflog(f"Łączny czas operacji = {tt} sek.")
                # oznaczenie, że proces skończony
                cache.cache_insert(
                    "xt7_results_finished",
                    repr({klucz: max(1, tt)}),
                    control.sourcescacheFile
                )
                # zamieszczenie informacji o czasie całej operacji
                # może się przydać do analizy, jak długo czekać następnym razem
                cache.cache_insert("xt7_results-last_total_time", max(1, tt), control.sourcescacheFile)


            fflog(f' Zatwierdzonych rekordów: {len(results)} ')
        except Exception:
            fflog_exc()
            results = self.results
            # oznaczenie, że proces przerwany (ala skończony)
            cache.cache_insert("xt7_results_finished", "", control.sourcescacheFile)
            # if "check_if_finished" in locals() and "klucz" in locals() and klucz:
            #     if not check_if_finished():
            #         cache.cache_insert(
            #             "xt7_results_finished",
            #             repr({klucz: None}),
            #             control.sourcescacheFile
            #         )

        return results

    def prepare_pattern_for_titles(self, title, year="", episode=""):
        """tworzy wzorzec dla tytułów do porównywania z nazwami plików"""

        title_pat = title.lower()

        title_pat = re.escape(title_pat)
        # title_pat = re.sub(r"\\ ", " ", title_pat)  # spacje zostawiam
        title_pat = title_pat.replace(r"\ ", " ")  # spacje zostawiam

        # zastosowanie wyjątków na pewne frazy (stworzyłem dla serialu "Scream The TV series")
        # ale nie wiem, czy to dalej potrzebne
        # lepiej dopisywać zmiany na www.themoviedb.org (konto jest darmowe)
        # if episode:
        #     antifalse_filter_exceptions = source_utils.antifalse_filter_exceptions
        #     for ex in antifalse_filter_exceptions:
        #         # titles_pat = [re.sub(rf"([ \W]+{ex})", r"(\1)?", t, flags=re.I) for t in titles_pat]
        #         title_pat = re.sub(rf"([ \W]+{ex})", r"(\1)?", title_pat, flags=re.I)
        #         pass

        # znaki nieliterowe
        title_pat = re.sub(r'(?!\\?[&:,[\] .–-])(\\?)(\W)',  r'[\2 .–-]?', title_pat)
        title_pat = title_pat.replace("[^", r"[\^")  # korekta
        # poniższe dla np. "miraculous: biedronka i czarny kot. film" -> "miraculous - biedronka i czarny kot - film"
        # title_pat = title_pat.replace(r'\.', '[ .–-]+')
        # title_pat = re.sub(': ?', '[: .–-]+', title_pat)
        title_pat = re.sub(r' *(\\(\.|-)|–(?![^\[]*\])) *', '[ .–-]+', title_pat)
        title_pat = re.sub(r"(\[ \.–\-\])\+$", r"\1?" , title_pat)  # korekta dla dla "E.T.1982"
        title_pat = re.sub(' *([:,]) *', r'[\1 .–-]+', title_pat)
        # title_pat = re.sub(r"(\[[+=] \.–\-\])\?" ,r"\1+" , title_pat)  # matematyczne znaki (nie testowane jeszce)
        # a co z innymi znakami, jak "?", "!" - lepiej je chyba na samym początku przerobić
        # title_pat = re.sub(r'(((?!\\?[&:,[\]()^*+?/ ._–-])\W)+)(?![^\[]*\])', r"[\1 ._–-]?", title_pat)
        # title_pat = re.sub(r'(?!\\?[&:,[\]+ .–-])(\\?)(\W)',  r'[\2 .–-]?', title_pat)  # można tu, ale trzeba dodatkowo plusa obsłużyć

        # dla konkretnego zapisu ułamków jakie występują np. w "Naga broń 2 1⁄2"
        title_pat = re.sub(r'(\d )((\d) (\d( )?))', r'\1(i )?\3[ .,/-]\4', title_pat)  # "Naga broń 2 i 1-2"
        # poniższe związane jest z powyższym (może to "jednorazowa" akcja?)
        title_pat = re.sub(r'(\d)( )([a-zA-Z])', r'\1\2*\3', title_pat)  # np."2 The" -> "2The"

        # przekształcenie odstępów między wyrazami
        # title_pat = re.sub(r"[ ](?![^\[]*\])", "[ .–-]", title_pat)  # przekształcenie odstępów między słowami
        title_pat = re.sub(r"[ ](?![^\[]*\])", "[ .–-]+", title_pat)  # plus choć niby niepotrzebny przydaje się (łatwiej czyścić zdublowane)
        # ponieważ wyżej dodałem "+" na końcu, to mogą być konieczne następujące korekty:
        title_pat = title_pat.replace("+?", "?")  # bo inaczej zmieni się znaczenie
        title_pat = title_pat.replace("+*", "*")  # to bardzo ważne
        title_pat = title_pat.replace("++", "+")  # to raczej też
        # ewentualnie można jeszcze:
        # title_pat = re.sub(r"(\[ \.–\-\]\+?){2,}", "[ .–-]+", title_pat)  # eliminacja zdublowanych "odstępów", czyli spacji
        title_pat = re.sub(r"(\[(\W*?) \.–\-\]\?){2,}", lambda x: "["+re.sub(r"\[(\W*?) \.–\-\]\?", r"\1", x.group())+" .–-]*", title_pat)
        title_pat = re.sub(r"(\[(\W*?) \.–\-\]\+){2,}", lambda x: "["+re.sub(r"\[(\W*?) \.–\-\]\+", r"\1", x.group())+" .–-]+", title_pat)
        title_pat = re.sub(r"(\[(\W*?) \.–\-\][?+]?){2,}", lambda x: "["+re.sub(r"\[(\W*?) \.–\-\][?+]?", r"\1", x.group())+" .–-]+", title_pat)
        # nie wiem, czy trzeba jeszce  + z * ( = +)  lub/oraz  * z * ( = *)

        # ampersand
        # title_pat = title_pat.replace(r"\&", r"(\&|and)")  # "Dungeons & Dragons: Złodziejski honor"
        title_pat = title_pat.replace(r"\&", r"(\&|and|i)")  # "Dungeons & Dragons: Złodziejski honor"

        # # matematyczne - tylko trzeba dodać wyjątki na początku - nie testowałem jeszcze
        # title_pat = title_pat.replace(r"\+", r"(\+|plus)")
        # title_pat = title_pat.replace(r"\-", r"(\+|minus)")

        # cyfry na słowa lub słowa na cyfry (także rzymskie)
        # title_pat = source_utils.numbers_in_pattern(title_pat)

        # obsługa znaków diakrytycznych ("akcentów")
        # title_pat = source_utils.diacritics_in_pattern(title_pat, mode=1)  # ą -> [ąa]
        title_pat = source_utils.normalize_unicode_in_pattern(title_pat)  # metoda bardziej uniwersalniejsza

        # if control.settings.getBool("sources.detects_numbers_instead_of_letters_in_titles"):  # może dorobić takie coś?
        # na takie twory jak "Mira3ulum – Bied3onka i Cz3rny K3t"
        # czy zrobić to jako opcja?
        # title_pat = re.sub(r"(?<!\[)([^\W\d_])(?![?\]])", r"[\1\\d]", title_pat)
        # title_pat = title_pat.replace("?]", "?\d]")
        # title_pat = title_pat.replace("][", "]\d?[")  # do powyższego fix na "Noc7ne gr7affiti"

        return title_pat

    def prepare_pattern_for_titles_v2(self, title):
        """alternatywna wersja (ma być prostsza, choć to się jeszcze okaże)"""

        title = title.lower()  # opcjonalnie, bo wcześniej to jest robione

        # pattern = re.sub(r'(((?!\\?\&)\W)+)', r"[\1 .–-]+", title)  # znaki nieliterowe, oprócz "&" (obsłużony jest niżej)
        pattern = re.sub(r'([^\w&]+)', r"[\1 .–-]+", title)  # prostszy zapis, ale nie można wówczas stosować re.escape
        pattern = re.sub(r'(\[[^ \w]+ \.–\-\])\+', r'\1*', pattern)  # korekta dla pojedynczych znaków, gdy nie ma po nich spacji
        # pattern = re.sub(r'\[ *([^ \w]+ \.–-])\+', r'[\1*', pattern)  # dla niektórych przypadków trochę lepsze od powyższego
        # poniższe 3 mogą być niezbędne, jak nie był robiony escape znaków
        pattern = pattern.replace("[^", r"[\^")
        pattern = pattern.replace("[]", r"[\]")
        pattern = pattern.replace("[[", r"[\[")
        # sprzątanie
        # pattern = re.sub(r" *(\\?\W)\1+", r"\1", pattern)  # sprzątanie zdublowanych znaków
        # pattern = re.sub(r"(\[) *(\W*?)( *\\?[.–-])+(?= )", r"\1\2", pattern)  # aby nie powielać znaków ".–-"
        # pattern = re.sub(r"(\[) *(\W*?)( *(\\\.|–|\\\-))+(?= )", r"\1\2", pattern)  # alternatywa powyższego zapisu
        pattern = re.sub(r"(?<=\[)\W+?(?= \.–-])", lambda x: "".join(list(dict.fromkeys(re.sub("[ .–-]", "", x[0])))), pattern)

        # nie wiem czy warto
        # pattern = pattern.replace("[ .–-]+", "[ .–-]")  # reprezentacja spacji

        # ampersand
        pattern = pattern.replace(r"&", r"(\&|and|i)")  # "Dungeons & Dragons: Złodziejski honor"

        # dla konkretnego zapisu ułamków jakie występują np. w "Naga broń 2 1⁄2"
        sp = "[ .–-]+"  # uważać na plus na końcu
        spe = re.escape(sp)
        pattern = re.sub(rf'(\d{spe})((\d){spe}(\d({spe})?))', rf'\1(i{sp})?\3[ .,/-]\4', pattern)  # "Naga broń 2 i 1-2"
        # poniższe związane jest z powyższym (może to "jednorazowa" akcja?)
        pattern = re.sub(rf'(\d)({spe})([a-zA-Z])', r'\1\2*\3', pattern)  # np."2 The" -> "2The"
        pattern = pattern.replace("+*", "*")

        # i inne jak:
        title_pat = pattern  # dla kompatybilności

        # cyfry na słowa lub słowa na cyfry (także rzymskie)
        # title_pat = source_utils.numbers_in_pattern(title_pat)

        # obsługa znaków diakrytycznych ("akcentów")
        # title_pat = source_utils.diacritics_in_pattern(title_pat, mode=1)  # ą -> [ąa]
        title_pat = source_utils.normalize_unicode_in_pattern(title_pat)  # metoda bardziej uniwersalniejsza

        # if control.settings.getBool("sources.detects_numbers_instead_of_letters_in_titles"):  # może dorobić takie coś?
        # cyfry zamiast liter np. "Mira3ulum – Bied3onka i Cz3rny K3t"
        # title_pat = re.sub(r"(?<!\[)([^\W\d_])(?![?\]])", r"[\1\\d]", title_pat)
        # title_pat = title_pat.replace("?]", "?\d]")
        # do powyższego fix na np. "Noc7ne gr7affiti"
        # title_pat = title_pat.replace("][", "]\d?[")

        pattern = title_pat
        return pattern

    def get_pages_content(self, page, year, title="", episode="", aliases=None, rows=None):
        """Funkcja filtruje wstępnie wyniki otrzymane z serwera
        sprawdzając czy pasują któreś z elementów: tytuł, rok, numer odcinka
        """
        # fflog(f'{title=} {episode=} {page=}')
        if not rows:
            if page:
                # if type(page) is range:
                if isinstance(page, range):
                    pages = page
                else:
                    pages = [page-1]
                rows = []
                for page in pages:
                    page += 1
                    # pobranie podstrony wyników
                    # fflog(f' pobranie ({page}) strony wyników')
                    res = self.session.get(
                        self.base_link + self.support_search_link.format(str(page)),
                        headers=self.headers,
                    ).text
                    row = client.parseDOM(res, "tr")[1:]
                    fflog(f' [{page}] strona: {len(row)} wyników')
                    rows += row
                fflog(f' Do przeanalizowania: {len(rows)}') if isinstance(pages, range) and page > 1 else ""
                self.raw_results += rows  # rozszerzenie tablicy
            else:
                # pobranie wcześniej zapisanych danych
                results_cache = cache.cache_get("xt7_raw_results", control.sourcescacheFile)
                if results_cache and "value" in results_cache and results_cache["value"]:
                    results_cache = literal_eval(results_cache["value"])
                    # odczytanie danych nie znając klucza
                    rows = [results_cache[k] for k in results_cache][0]
                    fflog(f' Analizowanie wcześniejszych wyników [{len(rows)}]')
                else:
                    fflog(" Brak danych do analizy")
                    return
        else:
            # to przeważnie dla pozycji z biblioteki
            # fflog(f' Analizuje zadane rekordy [{len(rows)}] {rows=}')
            pass

        if episode:
            # mógłbyć dołożony numer odcinka do zapytania
            title = re.sub(r"(s\d{2})?e\d{2,3}$", "", title).rstrip("._ ")
        if year:  # raczej nie występuje taki przypadek (jeszcze)
            # mógłbyć dołożony rok do zapytania
            # title = title.replace(year, "", 1).rstrip("_ ")
            title = "".join(title.rsplit(year, 1)).rstrip("._ ")
            # ciekawe czy jest taki tytuł co ma rok taki sam jak data produkcji?
        # fflog(f'{title=}')

        # granice frazy (alternatywa dla \b)
        b1 = r"(?:^|(?<=[([ _.-]))"  # początkowa
        b2 = r"(?=[)\] _.-]|$)"  # końcowa

        # wzorzec roku
        # year_pat = r"([ ._]*[(\[]?(19\d[\dO]|[2-9][\dO]{3})[)\]]?)"
        yr_uni_pat = r"\b(19\d[\dOo]|2[Oo0][\dOo]{2})\b"  # (1900 - 2099)
        # yr_uni_pat = f"{b1}{yr_uni_pat}{b2}"
        # yr_uni_pat = f"[ ._([]*{yr_uni_pat}"
        if year:
            year_pat = f"{b1}{year}{b2}".replace("0", "[0Oo]")  # wzorzec dla konkretnej daty (roku)

        # wzorzec przydatny do sprawdzania, czy w ogóle jest taka sekwencja w nazwie pliku
        episode_pat = r"((S\d{1,2})?[.,-]?E\d{2,3}|\bcz\.|\bodc\.|\bep\.|episode|odcinek|[\(\[]\d{2,3}[\)\]]|\- \d{2,3} [([-]|\bs\d{2}\b|\b\dx\d{2}\b)"
        episode_pat = episode_pat.replace(r"\d", r"[\dO]").replace("0", "[0O]")  # czasami zamiast 0 wstawiane jest O

        dodatkowy_filtr = self.dodatkowy_filtr
        dodatkowy_filtr2 = self.dodatkowy_filtr2

        # jeszcze nie ma takiej opcji w ustawieniach
        allow_filename_without_year = True
        # allow_filename_without_year = control.settings.getBool("sources.allow_filename_without_year_within")

        if control.settings.getBool("sources.title_validation_filter") and not self.dodatkowy_filtr:

            titles = self.titles  # zaczytanie wcześniej wybranych (m.in. aliasów)

            titles = [t.lower() for t in titles]
            titles = list(dict.fromkeys(titles))  # usunięcie duplikatów

            # dodanie bieżącego tytułu do listy (jeśli go tam jeszce nie ma)
            if title and title not in titles:
                titles = [title] + titles

            # opcjonalnie (może pomóc)
            # "spirited away: w krainie bogów" -> "w krainie bogów - spirited away"
            tmp = []
            for t in titles:
                if ": " in t and "-" not in t:
                    temp1 = " - ".join(t.split(": ")[::-1])
                    if temp1 not in titles:
                        tmp += [temp1]
            if tmp:
                titles += tmp

            fflog(f"titles (z aliasami): ({len(titles)}) \n" + "\n".join(titles), 0)  # kontrola

            # titles_pat_list = [self.prepare_pattern_for_titles(t) for t in titles]
            titles_pat_list = [self.prepare_pattern_for_titles_v2(t) for t in titles]

            titles_pat_list = list(dict.fromkeys(titles_pat_list))  # usunięcie duplikatów

            fflog(f"titles_pat_list: ({len(titles_pat_list)}) \n" + "\n".join(titles_pat_list), 0)  # kontrola

            title_pat = f'({"|".join(titles_pat_list)})'  # połączenie w 1 string

            # czasami są jeszcze takie przed rokiem
            res_pat = r"[ ._]*[(\[]?(720|1080)[pi]?[)\]]?"

            if episode or allow_filename_without_year:
                # wzorzec dla rozdzielczości
                res_pat = r"\b(SD|HD|UHD|2k|4k|480p?|540p?|576p?|720p?|1080[pi]?|1440p?|2160p?)\b"

                # wzorzec czasami spotykanych fraz
                # custom_pat = '([ ._][a-z]{2,})'  # za duża tolerancja i trafić może na ostatnie słowo innego tytułu np. "Titans go" dla filmu "Titans"
                custom_pat = r"\b(lektor|subbed|napisy|dubbing|polish|po?l(dub|sub)?|us|fr|de|dual|multi|p2p|web[.-]?(dl)?|remux|3d|imax)\b"  # trudnosć polega na przewidzeniu wszystkich możliwości

            # nazwa jakiejś grupy ludzi (powinna być na samym początku)
            # tylko nie wiem jakie mogą być dozwolone kombinacje
            # group_pat = r"\[[ .\-a-z]{3,}\]"
            # group_pat = r"\[[ .\-\w]{3,}\]"
            group_pat = r"\[[^[\]]{3,}\]"

            # rozszerzenia plików
            ext_pat = f'({"|".join(self.VIDEO_EXTENSIONS)})'.replace(".", "")

            if year:  # czyli dla filmów

                if allow_filename_without_year:
                    after_pat = fr"(\[\w*?\]|{res_pat}|{custom_pat}|{ext_pat}$)"
                else:
                    after_pat = yr_uni_pat

                # końcowy wzorzec do porównywania z nazwą pliku
                # if not self.tit_val_filt_for_one_title:  # to chyba już niepotrzebne
                if True:  # na razie tak
                    dodatkowy_filtr = re.compile(
                        # fr'(^|[/-]|  |\d{{1,2}})\W?(\b|_|\d{{1,2}}|^){title_pat}\d?(?=\b|[ ._]){year_pat}',
                        # rf"(^|[/-]|  |\d{{1,2}})\W?(\b|_|\d{{1,2}}|^){title_pat}([ ._-]{title_pat})?\d?(?=\b|[ ._]){year_pat}",
                        # rf"(^|[/-]|  |\d{{1,2}})\W?([ ._-]?{title_pat})+[ ._-]?\d?{year_pat}",
                        # rf"^\d{{0,2}}\.?\W?({title_pat}\d?[ ._/()-]{{1,4}})+[ ._-]?\d?{year_pat}?",
                        # rf"^(\d{{1,2}}|{yr_uni_pat}|{group_pat})?[ .-]*(\W?{title_pat}[ .-]?((?<!\d)\d)?[ ./()-]{{1,4}})+\d?[ .)-]?[(\[]?({yr_uni_pat}|{after_pat})",
                        rf"^(\d{{1,2}}|{yr_uni_pat}|{group_pat})?[ .-]*(\W?{title_pat}((?<!\d)\d|[ .-]1)?[ ./()-]{{1,4}})+((?<=[(])\d[)])?[ .-]?[(\[]?({yr_uni_pat}|{after_pat})",
                        flags=re.I)
                """
                else:  # chyba to nie będzie już potrzebne
                    fflog('używana będzie wersja filtru dopasowującego dla pojedyńczego tytułu')
                    dodatkowy_filtr = re.compile(
                        # fr'(^|[/-]|  |\d{{1,2}})\W?(\b|_|\d{{1,2}}|^){title_pat}\d?(?=\b|[ ._]){year_pat}',
                        # rf"(^|[/-]|  |\d{{1,2}})\W?(\b|_|\d{{1,2}}|^){title_pat}([ ._-]{title_pat})?\d?(?=\b|[ ._]){year_pat}",
                        # rf"(^|[/-]|  |\d{{1,2}})\W?([ ._-]?{title_pat})+[ ._-]?\d?{year_pat}?",
                        rf"^(\d{{1,2}}|{yr_uni_pat}|{group_pat})?([ .-]?\W?{title_pat})+[ .(-]*((?<!\d)\d)?[ .)(\]-]*({yr_uni_pat}|{after_pat})",
                        flags=re.I)
                """
                # zapamiętanie na kolejne wywołaniu tej funkcji, która dotyczyć będzie i tak tego samego filmu
                # (tylko inna fraza idzie do wyszukiwarki), a wszystkie tytuły zostały na początku ustalone w self.titles
                self.dodatkowy_filtr = dodatkowy_filtr

            if episode:

                # wzorzec dla roku
                # yr_uni_pat = r"[(]?(720|1080|19\d[\dO]|[2-9][\dO]{3})[)]?"  # zamiast 0 ktoś wpisał O

                # do DEBUGOWANIA, jak się nie mieści pattern w logu
                # res_pat = custom_pat = yr_uni_pat = '()'
                # title_pat = '()'

                # końcowe wzorce do porównywania z nazwą pliku
                # ep_uni_pat = r"[se]?[\dO]{2,3}"  # niektóre anime mają tylko sam numer
                ep_uni_pat = episode_pat  # definiowałem wcześniej do odróżniania filmów od seriali
                ep_uni_pat = ep_uni_pat[:-1] + r"|\b\d{2,3}\b)"  # bo wcześniej nie chcę tego
                ep_uni_pat2 = r"(S\d{2})?[.,-]?(E(\d{2,3}))"
                dodatkowy_filtr = re.compile(
                    # rf"(^|[/-]|\d{{1,2}})\W?(\b|[ _]|^){title_pat}\d?(?=\b|_)({res_pat}|{yr_uni_pat}|{custom_pat})*[ ._-]*[([]?{ep_uni_pat}",
                    # rf"(^({group_pat})?|[/-]|\d{{1,2}})[ .]?\W?{title_pat}\d?[ .-]+[([]?([ .-]*({res_pat}|{yr_uni_pat}|{custom_pat}))*[)\]]?[ .-]*[([]?{ep_uni_pat}",
                    # rf"(^({group_pat})?|[/-]|\d{{1,2}})[ .]?(\W?{title_pat}[ .-]?((?<!\d)\d)?[ ./()-]{{1,4}})+\d?[ .)-]?[([]?([ .-]*({res_pat}|{yr_uni_pat}|{custom_pat}))*[)\]]?[ .-]*[([]?{ep_uni_pat}",
                    rf"(^({group_pat})?|[/-]|\d{{1,2}})[ .]?(\W?{title_pat}((?<!\d)\d|[ .-]1)?[ ./()-]{{1,4}})+((?<=[(])\d[)])?[ .-]?[([]?([ .-]*({res_pat}|{yr_uni_pat}|{custom_pat}))*[)\]]?[ .-]*[([]?{ep_uni_pat}",
                    flags=re.I,
                )
                # dodatkowy_filtr2 = re.compile(rf"(^\d{{0,2}}\.?\W?|[([]?{episode_pat}\W*)(\b|_){title_pat}(?=\b|_)([ ._]*[/-]|[ ._]{{2,}})", flags=re.I)
                dodatkowy_filtr2 = re.compile(rf"(^\d{{1,2}}\.?\W?|[([]?{ep_uni_pat2}\W*){title_pat}([ .]*[/-]|[ .]{{2,}})", flags=re.I)
                # zmienna 'dodatkowy_filtr2' jest na przypadek, gdy na początku jest numer odcinka a potem tytuł
                # ale problemem jest ograniczenie wyszukiwania, aby nie było jak z filmem "Titans" bez "go" na końcu

                # zapamiętanie na kolejne wywołaniu tej funkcji, która dotyczyć będzie i tak tego samego serialu
                # (tylko inna fraza idzie do wyszukiwarki), a wszystkie tytuły zostały na początku ustalone w self.titles
                self.dodatkowy_filtr = dodatkowy_filtr
                self.dodatkowy_filtr2 = dodatkowy_filtr2

        # poniższe zawsze musi być (niezależnie czy używany będzie filtr dopasowujący tytuły)
        # jeśli episode się nie zmienia, to może można to zapamiętać
        # jest po to, aby wybrać właściwy odcinek (którego szukamy)
        if episode:
            # wzorzec numerów odcinków
            # if re.search(r"e\d{3}", episode):
            #     episode_pat = re.sub(r"(S\d{2})(E(\d{3}))", r"\1[.-]?\2(?!\\d)", episode, flags=re.I)
            # else:
            #     # episode_pat = re.sub(r"(S\d\d)(E(\d\d))", r"\1[.-]?e0?\3(?!\\d)", episode, flags=re.I)
            #     episode_pat = re.sub(r"(S\d{2})(E(\d{2}))", r"\1[.-]?e(\\d{2,3}-?)?e?0?\3(?!\\d)", episode, flags=re.I)
            episode_pat = re.sub(r"(S\d{2})(E(\d{2,3}))", r"\1[.,-]?e(\\d{2,3}-?)?e?0?\3(?!\\d)", episode, flags=re.I)
            # na przypadek gdy nie ma innego sezonu
            episode_pat = re.sub(
                r"(S01.*?)(E.*)",
                r"(\1\2|(?<![se]\\d{2}[.,-])(?<![se]\\d{2})(?<!e\\d{3}[.,-])(?<!e\\d{3})\2)",
                episode_pat,
                flags=re.I,
            )
            # zauważyłem, że czasami zamiast 0 jest O
            episode_pat = episode_pat.replace(r"\d", r"[\dO]").replace("0", "[0O]")

            # dla łączonych odcinków
            eps = (re.search(r"e(\d{2,3})", episode).group(1))  # string
            epn = int(eps)  # liczba (numer)
            sn = int(re.search(r"s(\d{2})", episode).group(1))
            rang_re = re.compile(r"(?:s([\dO]{2})-?)?e(\d{2,3})-e?(\d{2,3})", flags=re.I)
            def ep_is_in_range(filename):
                rang = rang_re.search(filename)
                if rang:
                    if not rang.group(1) and sn==1 or rang.group(1) and int(rang.group(1).replace('O','0'))==sn:
                        return epn in range(int(rang.group(2)), int(rang.group(3)))
                return None

            if re.search(r"[sS]01", episode):
                episode2_pat = fr"(?<!\d[2-9])[ .](cz\.|odc\.|ep\.|episode|odcinek)[ .-]{{,3}}0{{,2}}{epn}\b|[([]0{{,2}}{epn}[)\]](?!\.[a-z]{{2,3}}$)|\- 0{{,2}}{epn} [([-]|\b0?{sn}x0{{,2}}{epn}\b|\b0{{,2}}{epn}\.[a-z]{{2,3}}$|[a-z][ .]0{{,2}}{epn}[ .][a-z]"
            else:
                episode2_pat = "niemozenicznalezc"

        allow_year_less_than_base = True
        # allow_year_less_than_base = control.settings.getBool("sources.allow_year_less_than_base")

        # with self.lock:  # to jakaś pozostałość po starym kodzie
        def _checkYearOrEpisode(year):
            # fflog(f'ilość rekordów: {len(rows)}')
            yr_uni_re = re.compile(yr_uni_pat)
            year_re = re.compile(year_pat) if year else None
            episode_re = re.compile(episode_pat, flags=re.I)
            episode2_re = re.compile(episode2_pat, flags=re.I) if episode else ""
            for row in rows:
                if row in self.results:  # pozbycie się takich samych pozycji
                    continue
                # rozmiar pliku (informacyjnie)
                size = client.parseDOM(row, "td")[3]
                # nazwa pliku
                filename0 = "".join(client.parseDOM(row, "a") or client.parseDOM(row, "label"))
                # odrzucenie rozszerzeń niebędących plikami video
                if filename0[-3:] not in self.VIDEO_EXTENSIONS:
                    # fflog(f"  - niepasujące rozszerzenie {filename0[-3:]!r} w {unescape(unquote(filename0))!r}")
                    continue
                # funkcji unquote() oraz unescape() najlepiej używać tylko do koncowego wyświetlenia
                # !nie uzywać do porównań z oryginałem,
                # ponieważ raczej nie da się odtworzyć w 100% stringu pierwotnego
                filename = filename0  # potrzeba zachowania nazwy pliku pobranej ze strony internetowej
                filename = unquote(filename)
                filename = unescape(filename)
                filename = filename.replace("_", " ")  # dla uproszczenia, ale sprawdzić patterny, bo mogłobyć wcześniej założenie, że nie ma spacji tylko _
                filename = re.sub(r"\b[0-9a-f]{8}\b", "", filename, flags=re.I)  # wyrzucenie CRC32 z nazwy pliku
                # fflog(f"{filename=}")
                if (
                    # (year and year in filename)
                    (year and year_re.search(filename))
                    or (year and allow_year_less_than_base and str(int(year) - 1) in filename)  # przepuszcza filmy z rokiem o 1 mniejszym od bazowego
                    or (year and allow_filename_without_year and not yr_uni_re.search(filename) and not episode_re.search(filename))  # gdy brak roku w tytule
                    or (episode and episode_re.search(filename))
                    or (episode and ep_is_in_range(filename))
                    or (episode and episode2_re.search(filename))  # inne warianty zapisu odcinków (m.in. dla niektórych anime)
                    or (not year and not episode)
                ):
                    # sprawdzenie zgodności nazwy pliku z szukanym tytułem
                    # (jeśli taki filtr nie jest wyłączony przez użytkownika w ustawieniach)
                    if (
                        not dodatkowy_filtr
                        or dodatkowy_filtr.search(filename)
                        or (dodatkowy_filtr2 and dodatkowy_filtr2.search(filename))
                    ):
                        self.results.append(row)
                        # fflog(f'  + przepuszczono {unescape(unquote(filename0))!r} {size}')
                        # fflog(f' bo {title=} {dodatkowy_filtr=} {year=} {episode=}\n')
                        if filename0 in self.trash:
                            fflog(f" + Przywrócono {unescape(unquote(filename0))!r} {size}", 0)
                            self.trash.remove(filename0)
                    else:
                        # może trochę zaciemniać, jak developersko analizujemy co jest kiedy odrzucane,
                        # ale w logach dla usera ładniej wygląda.
                        if not any(filename0 in r for r in self.results):
                            if filename0 not in self.trash:
                                fflog(f"  - odrzucono  {unescape(unquote(filename0))!r} {size}", 0)
                                self.trash.append(filename0)
                                # fflog(f' bo {title=} {dodatkowy_filtr=} {year=} {episode=}\n')
                        else:
                            # TYLKO do developerskiej analizy działania filtra
                            # fflog(f'*(byłoby odrzucone {filename!r} {size}, choć potem zostałoby przywrócone)\n')
                            pass  # po to, aby bezpiecznie móc zakomentować powyższą linijkę
                # fflog(f' nie dodano, bo {filename=} {year=} {episode=} {size=}\n')

        _checkYearOrEpisode(year)

        # kolejna próba, gdy nie było rezultatów, to wykorzystać oryginalny tytuł nieanglojęzyczny
        # ale to już chyba niepotrzebne, bo ten oryginalny tytuł jest w aliasach, a one są uwzględniane od razu
        # if not self.results and year and not page and aliases:
        #     # fflog('Próba wykorzystania oryginalnego tytułu nieanglojęzycznego')
        #     ot = [a for a in aliases if "originalname" in a]
        #     if ot:
        #         ot = ot[0]["originalname"]
        #         # fflog(f'  {ot=}')
        #         self.get_pages_content(page, year, ot, episode, aliases=None)

        # kolejna próba, gdy nie było rezultatów
        # bo zdarzają się rozbieżnościa pomiędzy datą produkcj czy premiery w Polsce i na świecie -
        # np. film Nocne Graffiti (w bazie TMDB czy IMDb jest rok 1997 (data premiery)
        # a w bazie FilmWeb rok to 1996) więc próbuje szukać rekordów,
        # w których zawarty rok jest o 1 mniejszy niż bazowy
        # też już chyba niepotrzebne, chyba, że jako fallback
        # if (
        #     not self.results
        #     and year
        #     and not allow_year_less_than_base  # Czy zignorowanie tu Ustawień to na pewno dobrze?
        # ):
        #     fflog(
        #         " Z powodu braku dopasowań, podjęcie ponownej próby,"
        #         f" tym razem dla roku {int(year)-1} (choć wyniki mogą być błędne):"
        #     )
        #     _checkYearOrEpisode(str(int(year) - 1))

        # sprawdzenie, czy coś co było wcześniej odrzucone, może zostało jednak dodane do źródeł
        if self.trash:
            self.trash = list(dict.fromkeys(self.trash))
            for item in self.trash[:]:  # kopia, bo będzie usuwanie elementów
                if any(item in r for r in self.results):
                    # główny cel tego fragmentu kodu
                    fflog(f"+ Przywrócono {unescape(unquote(item))!r}")
                    self.trash.remove(item)

    def sources(self, rows, hostDict, hostprDict, from_cache=None):
        """Funkcja sprawdza przefiltrowane wstępnie wyniki
        i dodaje je do listy wyświetlanej użytkownikowi
        """
        if not rows:
            fflog('Brak rekordów do przekazania')
            return []

        self.login()

        # fflog(f"sprawdzenie co jest na koncie (i notesie)")
        biblio_cache, biblio_links = self.files_on_user_account(from_cache=from_cache)[0:2]

        # fflog(f"parsing źródeł ({len(rows)})")
        sources = []
        try:
            for row in rows:
                try:
                    filename = client.parseDOM(row, "label")[0]
                    if "<a " in filename.lower():  # moze byc jeszcze tag a
                        filename = client.parseDOM(filename, "a")[0]

                    link = client.parseDOM(row, "input", ret="value")[0]

                    # sprawdzenie, czy wybrana pozycja może jest już na Koncie
                    on_account, on_account_link, case, on_account_expires = self.check_if_file_is_on_user_account(biblio_links, link, filename, biblio_cache)
                    #on_account = False  # test tylko

                    hosting = client.parseDOM(row, "td")[1]  # hosting
                    size = client.parseDOM(row, "td")[3]  # rozmiar

                    # uniknięcie zdublowań dla dołączonych z biblioteki
                    if on_account_link and any(on_account_link in s["on_account_link"] for s in sources):
                    # if not size or "xt7.pl/pobieramy/" in link:  # to niweluje cały zamysł
                        continue

                    alt_links = []
                    alt_filenames = []  # (aby lepiej wykrywać, że jest na koncie)

                    # unikanie zdublowań lub wymiana na lepiej opisane
                    #if not on_account or case:
                    if True:  # trzeba zawsze
                        reject = False
                        # digit_pat = r"[ ._-]\(\d\)"
                        # digit_pat = r"[ ._-]\(\d\)|(?<=((?![\d_])\w){2})\d(?=[\W_]\d{4})"  # numerki na końcu tytułów
                        digit_pat = r"[ ._-]\(\d\)|(?<=[^\W\d_]{2})\d(?=[\W_]\d{4})"  # to samo co linijka wyżej
                        len_filename1 = unescape(unquote(filename))
                        d_in_filename1 = re.search(digit_pat, len_filename1)
                        len_filename1 = re.sub(digit_pat, "", len_filename1)
                        len_filename1 = len(len_filename1)
                        for i in reversed(range(len(sources))):
                            s = sources[i]
                            if size in s["info"] and hosting in s["source"]:
                                # porównuje długość nazw zakładając, że im dłuższa,
                                # tym więcej będzie zawierała informacji
                                len_filename2 = unescape(unquote(s["filename"]))
                                d_in_filename2 = re.search(digit_pat, len_filename2)
                                len_filename2 = re.sub(digit_pat, "", len_filename2)
                                len_filename2 = len(len_filename2)
                                if len_filename2 < len_filename1 or on_account and not s["on_account"]:
                                    # fflog(f'1 wymiana {s["url"]=} na {link=}')
                                    alt_links = [s["url"]] + s["alt_links"]
                                    alt_filenames = [s["filename"]] + s["alt_filenames"]
                                    if s["on_account"] and not on_account:
                                        on_account = s["on_account"]
                                        on_account_link = s["on_account_link"]
                                        on_account_expires = s["on_account_expires"]
                                        hosting = s["source"]
                                        case = "~"
                                    del sources[i]
                                elif len_filename2 == len_filename1:
                                    if d_in_filename2 and not d_in_filename1:
                                        # fflog(f'2 wymiana {s["url"]=} na {link=}')
                                        alt_links = [s["url"]] + s["alt_links"]
                                        alt_filenames = [s["filename"]] + s["alt_filenames"]
                                        if s["on_account"] and not on_account:
                                            on_account = s["on_account"]
                                            on_account_link = s["on_account_link"]
                                            on_account_expires = s["on_account_expires"]
                                            hosting = s["source"]
                                            case = "~"
                                        del sources[i]
                                    else:
                                        # fflog(f'3 odrzucenie {link=}')
                                        if link not in s["alt_links"]:
                                            s["alt_links"].append(link)
                                        if filename not in s["alt_filenames"]:
                                            s["alt_filenames"].append(filename)
                                        reject = True
                                else:
                                    # fflog(f'4 odrzucenie {link=}')
                                    if link not in s["alt_links"]:
                                        s["alt_links"].append(link)
                                    if filename not in s["alt_filenames"]:
                                        s["alt_filenames"].append(filename)
                                    reject = True

                                break

                        if reject:
                            continue

                    hosting += case  # dodanie ewentualnie gwiazdki

                    info = source_utils.get_lang_by_type(filename)
                    if not info[1]:
                        info1 = ""
                    else:
                        info1 = f" | {info[1]}"

                    quality = source_utils.check_sd_url(filename)

                    sources.append(
                        {
                            "source": hosting,
                            "quality": quality,
                            "language": info[0],
                            "url": link,
                            "info": f"{info1} | {size}",
                            "size": size,
                            "direct": True,
                            "debridonly": False,
                            "filename": filename,
                            "on_account": on_account,
                            "on_account_expires": on_account_expires,
                            "on_account_link": on_account_link,
                            "alt_links": alt_links,
                            "alt_filenames": alt_filenames,
                        }
                    )
                except Exception:
                    fflog_exc()
                    continue

            # zapisanie informacji w cache, aby potem wykorzystać w następnej funkcji,
            # gdyż instancja Klasy zostanie zniszczona (wada Kodi?)
            # src = {i['url']: i for i in sources}  # zrobienie z listy słownika, gdzie kluczem dla każdego źródła będzie jego link
            src = sources  # zostawiam jako listę
            cache.cache_insert("xt7_src", repr(src), control.sourcescacheFile)
            # w bazie cache będzie key(xt7_src), value(słownik w formie stringa)
            fflog(f'Przekazano źródeł: {len(sources)}')
            return sources
        except Exception:
            fflog_exc()
            return sources

    def resolve(self, url, buy_anyway=False, specific_source_data=None):
        """Funkcja odsyła link do playera"""
        # przechowanie wartości zmiennej
        # fflog(f'{url=} {specific_source_data=}')
        original_url = url
        if not specific_source_data:
            specific_source_data = {}

            # Pobranie informacji z cache, aby odczytać nazwę pliku powiązanego z url-em
            sources_data = cache.cache_get("xt7_src", control.sourcescacheFile)
            if sources_data:
                sources_data = sources_data["value"]
                sources_data = literal_eval(sources_data)
                try:
                    # specific_source_data = sources_data[url]  # gdy sources_data to słownik
                    # specific_source_data = [i for i in sources_data if i['url'] == url][0]  # gdy sources_data to lista
                    specific_source_data = next(i for i in sources_data if i["url"] == url)
                    # fflog(f' {specific_source_data=}')
                except Exception:
                    pass
            #else:
                #specific_source_data = {}
                #fflog("[resolve] UWAGA! - brak danych w BAZIE, które powinna zapisać poprzednia metoda 'sources()'")

        # sprawdzenie, czy wybrane źródło jest już może na koncie użytkownika
        if not buy_anyway and specific_source_data:
            on_account = specific_source_data.get("on_account", False)
            if on_account:
                on_account_link = specific_source_data.get("on_account_link", "")
                if on_account_link:
                    on_account_link = on_account_link.replace("%2F", "-")  # fix dla plików z "/" w nazwie
                    link = on_account_link
                    if '/pobieramy/' in link:
                        response = self.session.get(link, headers=self.headers, verify=False, allow_redirects=False)
                        if response.status_code == 200:
                            control.execute('Dialog.Close(notification,true)')
                            if 'dla podanego linka Premium' in response.text:
                                control.dialog().ok('xt7', 'Wykorzystano limit połączeń dla tego źródła.')
                            else:
                                control.dialog().ok('xt7', 'Ważność linku wygasła.')
                                control.window().clearProperty('imdb_id')  # aby odświeżyć listę źródeł
                                control.window().setProperty('clear_SourceCache_for', control.window().getProperty('clear_SourceCache_for') + ',xt7')  # jak ktoś używa cache źródeł
                            # control.execute('Dialog.Close(notification,true)')
                            return None
                        if response.status_code == 302:
                            link = response.headers['Location']
                            response = self.session.head(link, headers=self.headers, verify=False, allow_redirects=False)
                            if 'text' in response.headers['Content-Type']:
                                if 'download_token=' in link and '.wrzucaj.pl/' in link:  # tylko dla wrzucaj.pl
                                    link = re.sub(r'(?<=//)\w+?\.(wrzucaj\.pl/)', r'\1file/', link)
                                    link = re.sub(r'\&?download_token=[^&]*', '', link).rstrip('?')
                                    try:
                                        link = link.encode('latin1').decode('utf8')  # aby było czytelniej w logach
                                    except Exception:
                                        pass
                                    on_account_link = link
                                    response = self.session.head(link, headers=self.headers, verify=False, allow_redirects=False)
                                if response.status_code == 302:
                                    link = response.headers['Location']
                                    response = self.session.head(link, headers=self.headers, verify=False, allow_redirects=False)
                        if response.status_code == 403:
                            control.execute('Dialog.Close(notification,true)')
                            control.dialog().ok('xt7', 'Dostęp został ograniczony [CR] - sprawdź przyczynę na stronie internetowej')
                            return None  # VLC może odtworzyć, bo błąd 403 może w nim nie wystąpić
                            # można dołożyć opcję w menu czy kontynuować w przypadku takiego błędu albo zrobić dialog.yesno z pytaniem, czy kontynuować dalej ?
                            """
                            user_accepts = control.dialog().yesno(
                                'xt7', (
                                    'Dostęp został ograniczony [CR] - sprawdź przyczynę na stronie internetowej\n'
                                    'Czy chcesz spróbować konynuować próbę odwtorzenia mimo to?\n'
                                    'Ma to sens tylko w przypadku używania zewnętrznego odtwarzacza, np. VLC'
                                    ),
                            )
                            if not user_accepts:
                                return False
                            """
                        elif response.status_code >= 400:
                            control.dialog().notification('xt7', (f'Serwer zwrócił błąd nr {response.status_code}'), 'error', 4000)
                            control.sleep(4000)
                            return None  # choć np. VLC może czasami odtworzyć, bo błąd 403 może w nim nie wystąpić
                        fflog(f"1 {response.status_code=}", 0)
                    fflog(f"1 {on_account_link=}", 0)
                    return on_account_link

        # odczytanie nazwy pliku związanego z wybranym url-em
        filename = specific_source_data.get("filename", "")

        self.login()

        # pobranie informacji o plikach na koncie ("notes_list" może być dalej potrzebny)
        biblio_cache, biblio_links, notes_list = self.files_on_user_account(mode=2, from_cache=False)

        if not buy_anyway:
            # Sprawdzenie czy wybrana pozycja jest już na koncie
            links = [original_url] + specific_source_data.get("alt_links", [])
            links = list(dict.fromkeys(links))  # ewentualne pozbycie się duplikatów
            filenames = ([filename] if filename else []) + specific_source_data.get("alt_filenames", [])  # jeszcze nie wdrożono
            filenames = list(dict.fromkeys(filenames))  # ewentualne pozbycie się duplikatów
            on_account, on_account_link, case = self.check_if_file_is_on_user_account(biblio_links, links, filenames, biblio_cache)[0:3]
            # jeśli tak, to zwróć link do niej
            if on_account:
                # fflog(f'{case=} {on_account=} {on_account_link=}')
                on_account_link = on_account_link.replace("%2F", "-")  # fix dla plików z "/" w nazwie
                # test i ewentualna próba naprawy nieaktywnego linku
                link = on_account_link
                if '/pobieramy/' in link:
                    response = self.session.get(link, headers=self.headers, verify=False, allow_redirects=False)
                    if response.status_code == 200:
                        control.execute('Dialog.Close(notification,true)')
                        if 'dla podanego linka Premium' in response.text:
                            control.dialog().ok('xt7', 'Wykorzystano limit połączeń dla tego źródła.')
                        else:
                            control.dialog().ok('xt7', 'Ważność linku wygasła.')
                            control.window().clearProperty('imdb_id')  # aby odświeżyć listę źródeł
                            control.window().setProperty('clear_SourceCache_for', control.window().getProperty('clear_SourceCache_for') + ',xt7')  # jak ktoś używa cache źródeł
                        # control.execute('Dialog.Close(notification,true)')
                        return None
                    if response.status_code == 302:
                        link = response.headers['Location']
                        response = self.session.head(link, headers=self.headers, verify=False, allow_redirects=False)
                        if 'text' in response.headers['Content-Type']:
                            if 'download_token=' in link and '.wrzucaj.pl/' in link:  # tylko dla wrzucaj.pl
                                link = re.sub(r'(?<=//)\w+?\.(wrzucaj\.pl/)', r'\1file/', link)
                                link = re.sub(r'\&?download_token=[^&]*', '', link).rstrip('?')
                                try:
                                    link = link.encode('latin1').decode('utf8')  # aby było czytelniej w logach
                                except Exception:
                                    pass
                                on_account_link = link
                                response = self.session.head(link, headers=self.headers, verify=False, allow_redirects=False)
                            if response.status_code == 302:
                                link = response.headers['Location']
                                response = self.session.head(link, headers=self.headers, verify=False, allow_redirects=False)
                    if response.status_code == 403:
                        control.execute('Dialog.Close(notification,true)')
                        control.dialog().ok('xt7', 'Dostęp został ograniczony [CR] - sprawdź przyczynę na stronie internetowej')
                        return None  # VLC może odtworzyć, bo błąd 403 może w nim nie wystąpić
                        # patrz co napisałem kilka linijek wyżej
                    elif response.status_code >= 400:
                        control.dialog().notification('xt7', (f'Serwer zwrócił błąd nr {response.status_code}'), 'error', 4000)
                        control.sleep(4000)
                        return None  # choć np. VLC może czasami odtworzyć, bo błąd 403 może w nim nie wystąpić
                    fflog(f"2 {response.status_code=}", 0)
                fflog(f"2 {on_account_link=}", 0)
                return on_account_link
                # return str(on_account_link + "|User-Agent=vlc/3.0.0-git libvlc/3.0.0-git&verifypeer=false")  # VLC nie odtwarza tego

        auto_purchase = control.settings.getBool("autoxt7")
        if not auto_purchase:
            limit_info = self.session.get(self.base_link, headers=self.headers).text
            limit_info = client.parseDOM(limit_info, "div", attrs={"class": "textPremium"})
            remaining_limit = str(client.parseDOM(limit_info, "b")[-1])
            remaining_limit = re.sub(r"\s*\w+\s*=\s*([\"']?).*?\1(?=[\s>]|$)\s*", "", remaining_limit)
            remaining_limit = re.sub("<[^>]+>", "", remaining_limit)

            # przygotowanie nazwy pliku do wyświetlenia w okienku pytającym
            if control.settings.getBool("sources.extrainfo"):
                if not filename:
                    filename = url
                filename = unquote(filename)
                filename = unescape(filename)
                filename = self.prepare_filename_to_display(filename)

                try:
                    cp = source_utils.getPremColor()
                except Exception:
                    try:
                        cp = control.settings.getString("xt7.color.identify2")
                        # cp = cp if cp else control.settings.getString("prem.color.identify2")
                    except Exception:
                        cp = None
                if cp and cp != "nocolor":
                    filename = f"[COLOR {cp}]{filename}[/COLOR]"
                filename = f"[LIGHT]{filename}[/LIGHT]"
            else:
                filename = ""

            if "size" in specific_source_data:
                size_info = specific_source_data["size"]
            else:
                size_info = self.extract_size_from_source_info(specific_source_data.get("info", ""))

            size_info = size_info.replace(" ", "\u00A0")
            hosting = specific_source_data.get("source", "")

            if control.condVisibility('Window.IsActive(notification)'):
                control.execute('Dialog.Close(notification,true)')

            user_accepts = control.dialog().yesno(
                "xt7",
                (
                    f"Czy chcesz odtworzyć tę pozycję" + (f", za [B]{size_info}[/B]" if size_info else "") + "?\n"
                    f"[I]{filename}[/I]\n"
                    f"Aktualnie posiadasz: [B]{remaining_limit}[/B]" + (f"\n[LIGHT](serwer: [I]{hosting}[/I] )[/LIGHT]" if hosting else "")
                ),
            )
            if not user_accepts:  # rezygnacja
                return False

        # Ustalenie linku do filmu dla odtwarzacza

        links = [original_url] + specific_source_data.get("alt_links", [])
        # fflog(f'{links=}')
        links = list(dict.fromkeys(links))  # ewentualne pozbycie się duplikatów

        for link in links:
            # krok 1 - przesłanie adresu do sprawdzenia, czy aktywny
            data_step1 = {"step": "1", "content": link}
            response = self.session.post("https://xt7.pl/mojekonto/sciagaj", data=data_step1, headers=self.headers).text

            # srawdzenie, czy aktywny
            if ' value="Wgraj linki"' not in response:
                # control.window().clearProperty('imdb_id')  # aby odświeżyć listę źródeł
                fflog(f'nieaktywny {link=}')
                time.sleep(0.1)
                continue
            else:
                break

        if "ymagane dodatkowe" in response:
            control.dialog().ok('Brak środków', f'Brak wystarczającego transferu. \n[COLOR gray](aktualnie posiadasz [B]{remaining_limit}[/B])[/COLOR]')
            fflog(f'Brak wymaganego transferu')
            return None

        if ' value="Wgraj linki"' not in response:
            mnoga = len(links) > 1
            control.dialog().notification("xt7", (f"Wystąpił błąd. \nTa pozycja ma nieaktywn{'e' if mnoga else 'y'} link{'i' if mnoga else ''}."), 'error')
            fflog(f'żaden link dla tej pozycji nie działa')
            return None

        active_url = link
        fflog(f'   aktywny {link=}')
        # if not buy_anyway:  # nie wiem, czy tak lepiej ?
            # control.window().clearProperty('imdb_id')  # aby odświeżyć listę źródeł - nie trzeba tego tu
        control.window().setProperty('clear_SourceCache_for', control.window().getProperty('clear_SourceCache_for') + ',xt7')  # jak ktoś używa cache źródeł

        # do testów
        # return (False if not control.dialog().yesno("xt7", (f"Aktywny link to \n[LIGHT][B][I]{self.prepare_filename_to_display(active_url)}[/I][/B][/LIGHT]\nCzy kontynuować?") ) else True)

        # krok 2 - próba dodania źródła do biblioteki
        data_step2 = {"0": "on", "step": "2"}
        response = self.session.post("https://xt7.pl/mojekonto/sciagaj", data=data_step2, headers=self.headers).text

        # wydzielenie konkretnego fragmentu z odpowiedzi serwera
        div = client.parseDOM(response, "div", attrs={"class": "download"})
        try:
            link = client.parseDOM(div, "a", ret="href")[1]
            size = div[1].split("|")[-1].strip()
        except Exception:
            if "Nieaktywne linki" in response:
                control.dialog().notification("xt7", ("Link okazał się niaktywny"))
                fflog(f'jednak zły {link=}')
            else:
                control.dialog().notification("xt7", ("Wystąpił jakiś błąd. \nMoże brak wymaganego transferu?"))
            # control.dialog().ok('Brak środków', f'Brak wystarczającego transferu. \n[COLOR gray](aktualnie posiadasz [B]{remaining_limit}[/B])[/COLOR]')
            fflog_exc()
            return None

        # ewnentualne zapisanie informacji, aby następnym razem wiedzieć z jakim linkiem powiązać plik na koncie
        if control.settings.getBool("xt7.use_web_notebook_for_history") and specific_source_data:
            # nazwa pliku
            filename = unescape(unquote(specific_source_data["filename"]))
            # link
            link1 = link.rpartition("/")[0] if "/pobieramy/" in link else link
            # data ważności
            short_day = re.compile(r"([a-z]{2,3})[a-z]*|0(\d)(?=:)", flags=re.I)
            from datetime import datetime, timedelta
            after = timedelta(1)  # 1 dzień
            if "wplik" in specific_source_data["source"].lower():
                after = timedelta(hours=8)  # z przeprowadzonego doświadczenia
            expires = str((datetime.now() + after).strftime("%A %H:%M"))
            short_date = short_day.sub(r"\1\2", expires)

            # notes_dict = {k: [v['on_account_link'], v['filename'], v['size'], v['on_account_expires']] for k,v in biblio_cache.items()}
            # notes_dict = {k: v for k, v in sorted(notes_dict.items(), key=lambda item: item[1][-1], reverse=True)}  # sortowanie wg ostatniego, czyli daty wygaśnięcia
            # notes_list = [{k: v} for k, v in notes_dict.items()]
            # notes_list = [{original_url: [link1, filename, size, short_date]}] + notes_list  # najnowszy na początek
            notes_list = [{active_url: [link1, filename, size, short_date]}] + notes_list  # najnowszy na początek

            # zapisanie w Notesie na koncie
            while len(repr(notes_list)) >= 5000:  # limit narzucony przez serwis xt7.pl
                del notes_list[-1]
            now0 = int(time.time())
            self.session.post(
                self.base_link + self.mynotepad_link,
                data={"content": repr(notes_list)},
                headers=self.headers,
            )
            now1 = int(time.time())
            if (now1 - now0) > 5:
                fflog(f'!wysłanie historii plików do "xt7.pl/mojekonto/notes" zajęło {(now1 - now0)} sek.')

        # zwrócenie adresu do odtwarzacza
        # fflog(f"link: {link!r}")
        link = link.replace("%2F", "-")  # fix dla plików z "/" w nazwie
        return str(link)
        # return str(link + "|User-Agent=vlc/3.0.0-git libvlc/3.0.0-git&verifypeer=false")  # VLC nie odtwarza tego

    def prepare_filename_to_display(self, filename):
        # Pozwoli zawijać tekst (aby mieścił się w okienku)
        filename = filename[:-4].replace(".", " ").replace("_", " ") + filename[-4:]
        # Wywalenie ostatniego myślnika - zazwyczaj jest po nim nazwa "autora" pliku
        filename = re.sub(r"-(?=\w+( \(\d\))?\.\w{2,4}$)", " ", filename, flags=re.I)
        # przywrócenie niezbędnych kropek i kresek dla niektórych fraz
        filename = self.replace_audio_format_in_filename(filename)
        return filename

    def replace_audio_format_in_filename(self, filename):
        replacements = [
            (r"(?<!\d)([57261]) ([10])\b", r"\1.\2"),  # ilość kanałów, np. 5.1 czy 2.0
            (r"\b([hx]) (26[45])\b", r"\1.\2", re.I),  # h264 x264 x265 h265
            (r"\b(DDP?) (EX)\b", r"\1-\2", re.I),  # np. DD-EX
            (r"\b(DTS) (HD(?!-?(?:TS|cam|TV))|ES|EX|X(?![ .]26))\b", r"\1-\2", re.I),  # DTS
            (r"\b(AAC) (LC)\b", r"\1-\2", re.I),  # AAC-LC
            (r"\b(AC) (3)\b", r"\1-\2", re.I),  # AC-3
            (r"\b(HE) (AAC)\b", r"\1-\2", re.I),  # HE-AAC
            (r"\b(WEB|Blu|DVD|DCP|B[DR]|HD) (DL|Ray|RIP|Rip|Rip|TS)\b", r"\1-\2", re.I),
        ]
        for pattern in replacements:
            if len(pattern) == 3:
                old, new, flags = pattern
                filename = re.sub(old, new, filename, flags=flags)
            else:
                old, new = pattern
                filename = re.sub(old, new, filename)
        return filename

    def extract_size_from_source_info(self, source_info):
        size_match = re.search(
            r"(?:^|\|)\s*(\d+(?:[.,]\d+)?)\s*([GMK]B)\b\s*(?:\||$)",
            source_info,
            flags=re.I,
        )
        size = f"{size_match[1]} {size_match[2]}" if size_match else ""
        return size

    def files_on_user_account(self, mode=1, from_cache=None):
        """funkcja pobiera informacja z zakładki Notes oraz Historia,
        zwraca linki z Historii,
        dane z Notesu przerabia na tablicę,
        tworzy słownik o nazwie biblio_cache
        """
        notes_list = []
        # Pobranie informacji o plikach na koncie zapisanych w notesie
        if control.settings.getBool("xt7.use_web_notebook_for_history"):  # a może zawsze sprawdzać?
            result = cache.cache_get(f"xt7.pl_{self.mynotepad_link}", control.sourcescacheFile)
            if result:
                if (
                    from_cache
                    or from_cache is not False
                    and ((int(time.time()) - int(result["date"])) < (5 * 60))
                ):
                    result = result["value"]
                    # fflog(f"wzięto z cache (notes)")
                else:
                    result = ""
            # fflog(f"{result=}")
            notes_page_content = result
            if not result:
                # fflog(f"sprawdzam adres {self.base_link+self.mynotepad_link}")
                now0 = int(time.time())
                notes_page_content = self.session.get(self.base_link + self.mynotepad_link, headers=self.headers).text
                now1 = int(time.time())
                if (now1 - now0) > 5:
                    fflog(f"!sprawdzanie {self.base_link+self.mynotepad_link} zajęło {(now1 - now0)} sek.")
                cache.cache_insert(
                    f"xt7.pl_{self.mynotepad_link}",
                    notes_page_content,
                    control.sourcescacheFile
                )
            notes_value = client.parseDOM(notes_page_content, "textarea", attrs={"class": "notepad"})[0]

            if (notes_value
                and notes_value[0] == "["
                and notes_value[-1] == "]"
            ):
                try:
                    notes_list = literal_eval(notes_value)
                except Exception:
                    # notes_list = []
                    fflog("Uszkodzona struktura w Notesie !")
                    # fflog_exc()
            else:
                if notes_value:
                    fflog("Uszkodzona struktura Notesu")
                # notes_list = []

        # rozpisanie danych pobranych z notesu
        biblio_cache = {}
        for file_item in notes_list[::-1]:
            for url in file_item:
                if url in biblio_cache:
                    if mode == 2:
                        # fflog(f"!Istnieje więcej pozycji na koncie skojarzonych z adresem {url!r} (plik: {biblio_cache[url]['filename']!r} ({biblio_cache[url]['size']!s}) - zostanie wybrana najnowsza")
                        pass
                    # continue  # ale nie może być reverse na notes_list
                else:
                    biblio_cache[url] = {}  # ważne
                try:
                    biblio_cache[url]["filename"] = file_item[url][1]
                    biblio_cache[url]["size"] = file_item[url][2]
                    biblio_cache[url]["url"] = url
                    biblio_cache[url]["on_account_link"] = file_item[url][0]
                    biblio_cache[url]["on_account_expires"] = file_item[url][3]
                    biblio_cache[url]["source"] = re.sub(r"https?://(?:www\.)?([^.]+)\..+", r"\1", url, flags=re.I).upper()
                except Exception:
                    biblio_cache[url] = {}
                    fflog(f"nie udało się pobrać wszystkich danych z notesu dla {url!r}")
                    fflog_exc()

        # pobranie zawartości strony internetowej "historia zakupionych linków"
        result = cache.cache_get(f"xt7.pl_{self.mylibrary_link}", control.sourcescacheFile)
        if result:
            if (
                from_cache
                or from_cache is not False
                and ((int(time.time()) - int(result["date"])) < (5 * 60))
            ):
                result = result["value"]
                # fflog(f"wzięto z cache (pliki)")
            else:
                result = ""
        if not result:
            # fflog(f"sprawdzam adres {self.base_link+self.mylibrary_link}")
            now0 = int(time.time())
            result = self.session.get(self.base_link + self.mylibrary_link, headers=self.headers).text
            now1 = int(time.time())
            if (now1 - now0) > 5:
                fflog(f"!sprawdzanie {self.base_link+self.mylibrary_link} zajęło {(now1 - now0)} sek.")
            cache.cache_insert(f"xt7.pl_{self.mylibrary_link}", result, control.sourcescacheFile)
        # sprawdzenie, czy w odpowiedzi jest tabela
        table = client.parseDOM(result, "table", attrs={"class": "list"})
        try:
            biblio_links = client.parseDOM(table, "input", ret="value")
            if biblio_links:
                rows = client.parseDOM(table, "tr")[1:]
                biblio_links_exp = []
                for row in rows:
                    exp = client.parseDOM(row, "td")[3]
                    biblio_links_exp.append(exp)
                biblio_links2 = list(zip(biblio_links, biblio_links_exp))
            else:
                biblio_links2 = []
        except Exception:
            biblio_links = []
            # biblio_links_exp = []
            biblio_links2 = []
            fflog_exc()

        if control.settings.getBool("xt7.use_web_notebook_for_history"):
            # skrócenie linków
            # biblio_links1 = [x.rpartition("/")[0] for x in biblio_links if "/pobieramy/" in x]
            biblio_links1 = [(x.rpartition("/")[0] if "/pobieramy/" in x else x) for x in biblio_links]
            # "synchronizacja" z bilbioteką na stronie
            biblio_cache = {
                k: v
                for k, v in biblio_cache.items()
                # if any(l in v.values() for l in biblio_links1)  # szuka w tablicy
                if any(l in s for s in v.values() for l in biblio_links1)  # szuka w stringu
            }
            # odświeżenie Notesu
            notes_list = [
                n
                for n in notes_list
                for v in n.values()
                # if any(l in v for l in biblio_links1)
                if any(l in s for s in v for l in biblio_links1)  # szuka w stringu
            ]
            # wywalenie linków, które są w Notesie, aby nie wykrywać prawdopodobieństw, gdy może być pewność
            # biblio_links = [l for l in biblio_links if l.rpartition("/")[0] not in [i[0] for i in [v for n in notes_list for v in n.values()]]]
            # biblio_links2 = [l for l in biblio_links2 if l[0].rpartition("/")[0] not in [i[0] for i in [v for n in notes_list for v in n.values()]]]
            biblio_links2 = [l for l in biblio_links2 for s in [i[0] for i in [v for n in notes_list for v in n.values()]] if l[0].rpartition("/")[0] not in s] if notes_list else biblio_links2

        # fflog(f'\n{biblio_cache=} \n{biblio_links2=} \n{notes_list=}')
        return biblio_cache, biblio_links2, notes_list

    def check_if_file_is_on_user_account(self, biblio_links, links, filenames, biblio_cache=None):
        case = ""
        on_account = False
        on_account_expires = ""
        on_account_link = ""

        filename = filenames
        ext_pat = f'({"|".join(self.VIDEO_EXTENSIONS)})'.replace(".", "")
        if isinstance(links, str):
            links = [links]
        # fflog(f'{len(links)=} {len(filenames)=} {filenames=}')
        for link in links:
            #fflog(f'{link=}')
            if biblio_cache:
                # na podstawie danych z notesu
                specific_biblio_cache = biblio_cache[link] if link in biblio_cache else None
                if not specific_biblio_cache:
                    if link.rpartition("/")[0] in biblio_cache:  # dla skracanych linków
                        specific_biblio_cache = biblio_cache[link.rpartition("/")[0]]
                if specific_biblio_cache:
                    on_account = True
                    on_account_link = specific_biblio_cache.get("on_account_link")
                    on_account_expires = specific_biblio_cache["on_account_expires"]
                    break

            if not on_account:
                # sprawdzenie starszą metodą
                # potrzebne, jak nie ma danych z cache lub są niekompletne (brak całej historii)
                # lub mimo wybrania opcj Notesu user "kupił" ze strony
                for item in biblio_links:  # element z "Historii linków"
                    item_org = item
                    item = item[0]
                    item = unescape(unquote(item.rstrip("/").split("/")[-1]))
                    item = item.replace('_', ' ')  # uproszczenie
                    # item = "".join(character for character in item if character.isalnum())
                    if "/twojplik.pl/" in link.lower():
                        item = re.sub(rf"\.[0-9A-F]{{3}}(\.{ext_pat})$", r"\1", item)

                    url = unescape(unquote(link))  # badany oryginalny link
                    url = url.replace('_', ' ')  # uproszczenie
                    # url = "".join(character for character in url if character.isalnum())
                    if "/twojplik.pl/" in link.lower():
                        url = re.sub(rf"\.[0-9A-F]{{3}}(\.{ext_pat})$", r"\1", url)

                    # fflog(f'{item=} {url=}')
                    if item in url:
                        on_account_link = item_org[0]
                        on_account_expires = item_org[1]
                        on_account = True
                        if on_account_link != link:
                            case += "*"  # bo można znaleźć nazwę z biblioteki w innym linku niż pierwotny, więc serwer też może być inny
                        break

            if on_account:
                break

        if not on_account:  # teraz test z nazwami plików

            if not on_account and filenames:  # porównanie z nazwą pliku widniejącą na liście
                for item in biblio_links:  # element z "Historii linków"
                    item_org = item
                    item = item[0]
                    if "/twojplik.pl/" in link.lower():
                        item = re.sub(rf"\.[0-9A-F]{{3}}(\.{ext_pat})$", r"\1", item)
                    filenames = [filenames] if isinstance(filenames, str) else filenames
                    for filename in filenames:
                        if not filename:
                            continue
                        if "/twojplik.pl/" in link.lower():
                            filename = re.sub(rf"\.[0-9A-F]{{3}}(\.{ext_pat})$", r"\1", filename)
                        if unescape(unquote(filename)) in unescape(unquote(item)):
                            # dodatkowy warunek mogący pomóc, bo nie zawsze da się stwierdzić po url-u,
                            # gdyż np. linki do serwera "wplik" są zakodowane
                            # choć drobne ryzyko pomyłki istnieje, bo nie jest sprawdzany rozmiar czy serwer
                            # (strona xt7 nie podaje w tej zakładce ani serwera ani rozmiaru)
                            on_account_link = item_org[0]
                            on_account_expires = item_org[1]
                            on_account = True
                            case += "**"  # to co wyżej, tylko inny sposób porównywania
                            break
                    if on_account:
                        break

            if not on_account and filenames:
                for item in biblio_links:  # element z "Historii linków"
                    item_org = item
                    item = item[0]
                    if item[-3:] not in self.VIDEO_EXTENSIONS:  # gdy przez xt7 ucięty, jak dla "Flip i Flap Utopia"
                        if "/twojplik.pl/" in link.lower():
                            item = re.sub(rf"\.[0-9A-F]{{3}}(\.{ext_pat})$", r"\1", item)
                        for filename in filenames:
                            if not filename:
                                continue
                            if unquote(item.rpartition("/")[-1]) in filename:
                                on_account_link = item_org[0]
                                on_account_expires = item_org[1]
                                on_account = True
                                case += "***"  # ze względu na to, że to nie musi być ten serwer i ten link
                                break
                        if on_account:
                            break

        if on_account_expires:
            if case:
                try:
                    from datetime import datetime
                    on_account_expires = datetime.strptime(on_account_expires, "%H:%M %d.%m.%Y").strftime("%A %H:%M")
                except Exception:
                    pass
            on_account_expires = source_utils.months_to_miesiace(on_account_expires, short=1)
            on_account_expires = re.sub(r"0(\d)(?=:\d\d)", r"\1", on_account_expires)

        # fflog(f'koniec {on_account=} {on_account_link=} {case=} {link=} {filename=}')
        return on_account, on_account_link, case, on_account_expires

    def login(self):
        fflog('sprawdzenie czy zalogowany', 0)
        try:
            cookies = cache.cache_get("xt7_cookie", control.sourcescacheFile)["value"]
        except Exception:
            cookies = ""
        self.headers.update({"Cookie": cookies})

        result = cache.cache_get("xt7.pl_glowna", control.sourcescacheFile)
        if result:
            if (int(time.time()) - int(result["date"])) < (5 * 60):
                result = result["value"]
                fflog(f"zawartość strony wzięto z cache (główna)", 0)
            else:
                result = ""
        if not result:
            fflog(f"sprawdzam zalogowanie na stronie głównej", 0)
            now0 = int(time.time())
            result = self.session.get(self.base_link, headers=self.headers).text
            now1 = int(time.time())
            if (now1 - now0) > 5:
                fflog(f"!sprawdzanie, czy użytkownik jest zalogowany zajęło {(now1 - now0)} sek.")
            cache.cache_insert("xt7.pl_glowna", result, control.sourcescacheFile)
        if self.user_name in result:
            fflog('użytkownik jest już zalogowany', 0)
            return
        else:
            if self.user_name and self.user_pass:
                fflog("potrzeba zalogowania na konto", 0)
                self.session.post(
                    self.base_link + self.login_link,
                    verify=False,
                    allow_redirects=False,
                    data={"login": self.user_name, "password": self.user_pass},
                )
                result = self.session.get(self.base_link).text
                if self.user_name in result:
                    fflog('zalogowano poprawnie', 0)
                    cookies = self.session.cookies
                    cookies = "; ".join([str(x) + "=" + str(y) for x, y in cookies.items()])
                    cache.cache_insert("xt7_cookie", cookies, control.sourcescacheFile)
                    self.headers.update({"Cookie": cookies})
                    cache.cache_insert("xt7.pl_glowna", result, control.sourcescacheFile)
                else:
                    fflog("logowanie nieudane!")
                    control.infoDialog('logowanie nieudane', 'xt7', 'ERROR')
            else:
                fflog("BRAK danych do zalogowania! - sprawdź ustawienia")
                control.infoDialog('BRAK danych do zalogowania! - sprawdź ustawienia', 'xt7', 'ERROR')
