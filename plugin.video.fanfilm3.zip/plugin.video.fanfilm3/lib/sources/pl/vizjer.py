"""
    FanFilm Add-on
    Copyright (C) 2017 homik

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import urllib.parse as urlparse
import re
from lib.ff import cleantitle, source_utils
from lib.ff import client

class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["vizjer.pl"]
        self.base_link = "https://vizjer.pl/"
        self.search_link = "/wyszukiwanie?phrase=%s"
        self.useragent = "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0"
        self.headers = {
            "Referer": self.base_link,
            "User-Agent": self.useragent,
            "Accept": 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            "Accept-Language": 'pl,en-US;q=0.7,en;q=0.3',
            "DNT": "1", "Alt-Used": "vizjer.pl", "Connection": "keep-alive", "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document", "Sec-Fetch-Mode": "navigate", "Sec-Fetch-Site": "same-origin",
            "Sec-Fetch-User": "?1", "Pragma": "no-cache", "Cache-Control": "no-cache", }

    def movie(self, imdb, title, localtitle, aliases, year):
        return self.search(title, localtitle, year, 'movie')

    def tvshow(self, imdb, tmdb, tvshowtitle, localtvshowtitle, aliases, year):
        return self.search(tvshowtitle, localtvshowtitle, year, 'tvshow')

    def search(self, title, localtitle, year, type_):
        try:
            url = self.do_search(title, localtitle, year, type_)
            # Fix a title
            if not url:
                title = title[:-1]
                localtitle = localtitle[:-1]
                url = self.do_search(title, localtitle, year, type_)
            return url
        except Exception:
            return

    def do_search(self, title, local_title, year, type_):
        try:
            titles = [cleantitle.normalize(title),
                cleantitle.normalize(local_title), ]

            for title in titles:
                try:
                    url = urlparse.urljoin(self.base_link, self.search_link)
                    url = url % urlparse.quote_plus(cleantitle.query(title))
                    result = client.request(url, headers=self.headers)
                    fout = []
                    sout = []
                    results = []
                    out_url = ''
                    links = client.parseDOM(result, 'div', attrs={'id': 'advanced-search'})[0]
                    links = client.parseDOM(links, 'div', attrs={'class': r'col-sm-\d+'})
                    for link in links:
                        if 'href' in link:
                            href = client.parseDOM(link, 'a', ret='href')[0]
                            tytul = client.parseDOM(link, 'div', attrs={'class': 'title'})[0]
                            words = cleantitle.normalize(cleantitle.get_title(title)).split(" ")
                            if self.contains_all_words(cleantitle.normalize(cleantitle.get_title(tytul)), words):
                                if f'{self.base_link}serial-online' in href:
                                    sout.append({'title': tytul, 'url': href})
                                if f'{self.base_link}film' in href:
                                    fout.append({'title': tytul, 'url': href})
                    if type_ == 'movie':
                        results = fout
                    if type_ == 'tvshow':
                        results = sout
                    results.sort(key=lambda k: len(k['title']), reverse=True)
                    for url in results:
                        date = ''
                        if type_ == 'movie':
                            date = str(url['url'])[-4:]
                        if type_ == 'tvshow':
                            html = client.request(url['url'], headers=self.headers)
                            date = client.parseDOM(html, 'div', attrs={'class': 'info'})
                            date = (client.parseDOM(date, 'li')[-1:])[0]
                        if year and date.isnumeric():
                            if int(date) == int(year):
                                out_url = url['url']
                    return out_url
                except Exception as e:
                    continue
        except Exception:
            return

    def episode(self, url, imdb, tmdb, title, premiered, season, episode):
        return self.search_ep(url, season, episode)

    def search_ep(self, url, season, episode):
        html = client.request(url, headers=self.headers)
        sesres = client.parseDOM(html, 'ul', attrs={'id': "episode\-list"})[0]
        sezony = re.findall('(<span>.*?<\/ul>)', sesres, re.DOTALL)
        episode_url = ''
        for sezon in sezony:
            sesx = client.parseDOM(sezon, 'span')
            ses = ''
            if sesx:
                ses = re.findall('(\d+)', sesx[0], re.DOTALL)  # [0]
                ses = ses[0] if ses else '0'
            eps = client.parseDOM(sezon, 'li')
            for ep in eps:
                href = client.parseDOM(ep, 'a', ret='href')[0]
                tyt2 = client.parseDOM(ep, 'a')[0]
                epis = re.findall('s\d+e(\d+)', tyt2)[0]
                if int(ses) == int(season) and int(epis) == int(episode):
                    episode_url = href
        return episode_url

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None:
                return sources
            sources = []

            result = client.request(url, headers=self.headers)
            result = client.parseDOM(result, "table", attrs={"class": "table table-bordered"})
            result = client.parseDOM(result, "tbody")[0]
            result = client.parseDOM(result, "tr")
            for item in result:
                try:
                    item2 = client.parseDOM(item, "td")
                    jezyk = item2[2]
                    jezyk, info = self.get_lang_by_type(jezyk)
                    quality = item2[3]
                    url = client.parseDOM(item, "a", ret="href")[0]
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if "wysoka" in quality.lower():
                        sources.append({"source": host, "quality": "HD", "language": jezyk, "url": url, "info": info,
                            "direct": False, "debridonly": False, })
                    elif "rednia" in quality.lower():
                        sources.append({"source": host, "quality": "SD", "language": jezyk, "url": url, "info": info,
                            "direct": False, "debridonly": False, })
                    elif "niska" in quality.lower():
                        sources.append({"source": host, "quality": "SD", "language": jezyk, "url": url, "info": info,
                            "direct": False, "debridonly": False, })
                    else:
                        sources.append({"source": host, "quality": "SD", "language": jezyk, "url": url, "info": info,
                            "direct": False, "debridonly": False, })
                except Exception:
                    continue
            return sources
        except Exception:
            return sources

    def contains_word(self, str_to_check, word):
        if str(word).lower() in str(str_to_check).lower():
            return True
        return False

    def contains_all_words(self, str_to_check, words):
        for word in words:
            if not self.contains_word(str_to_check, word):
                return False
        return True

    def get_lang_by_type(self, lang_type):
        if "dubbing" in lang_type.lower():
            return "pl", lang_type
        elif "kino" in lang_type.lower():
            return "pl", lang_type
        elif "lektor" in lang_type.lower():
            return "pl", lang_type
        elif "napisy" in lang_type.lower():
            return "pl", lang_type
        elif "polski" in lang_type.lower():
            return "pl", lang_type
        elif "pl" in lang_type.lower():
            return "pl", lang_type
        return "en", lang_type

    def resolve(self, url):
        return url
