# -*- coding: utf-8 -*-
"""
    FanFilm Add-on
    Copyright (C) 2018 :)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from lib.ff import source_utils, cleantitle, control, cache
from lib.ff.debug import log_exception
from urllib.parse import urlencode
from ast import literal_eval
import requests
import hashlib
import hmac
import base64

from difflib import SequenceMatcher


class source:

    # This class has support for *.sort.order setting
    has_sort_order: bool = True
    # This class has support for *.color.identify2 setting
    has_color_identify2: bool = True

    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["cda.pl"]
        self.email = control.settings.getString("cda.username")
        self.passwd_ctrl = control.settings.getString("cda.password")
        self.passwd = self.hash_password(self.passwd_ctrl)
        self.session = requests.Session()
        self.useragent = "pl.cda 1.0 (version 1.2.176 build 18512; Android 11; Google sdk_gphone_x86)"
        self.headers = {'User-Agent': self.useragent,
                        'Accept': 'application/vnd.cda.public+json',
                        }
        self.headers_basic = {'Authorization': 'Basic YzU3YzBlZDUtYTIzOC00MWQwLWI2NjQtNmZmMWMxY2Y2YzVlOklBTm95QlhRRVR6'
                                               'U09MV1hnV3MwMW0xT2VyNWJNZzV4clRNTXhpNGZJUGVGZ0lWUlo5UGVYTDhtUGZaR1U1U3Q'}

        self.base_link = "https://api.cda.pl"
        self.search_link = f"{self.base_link}/video/search"
        self.anime = False
        self.year = 0
        self.duration = 20 * 60

    def hash_password(self, passwd):
        passw = passwd.encode('utf-8')
        md5 = hashlib.md5(passw).hexdigest()
        salt = "s01m1Oer5IANoyBXQETzSOLWXgWs01m1Oer5bMg5xrTMMxRZ9Pi4fIPeFgIVRZ9PeXL8mPfXQETZGUAN5StRZ9P"
        salt = salt.encode('utf-8')
        md5 = md5.encode('utf-8')
        hash = base64.b64encode(hmac.new(salt, md5, digestmod=hashlib.sha256).digest())
        hash = hash.decode('utf-8')
        return hash.replace("/", "_").replace("+", "-").replace("=", "")

    def check_email(self, email):
        data = {
            'email': email
        }
        self.headers.update(self.headers_basic)
        exist = self.session.post(f'{self.base_link}/register/check-email', data=data, headers=self.headers).json()

        if exist:
            return True
        else:
            return False

    def oauth(self, email, passwd):
        payload = {
            'grant_type': 'password',
            'login': email,
            'password': passwd
        }
        self.headers.update(self.headers_basic)
        if self.check_email(email):
            user = self.session.post(f'{self.base_link}/oauth/token', data=payload, headers=self.headers).json()
            if user.get('access_token') and user.get('refresh_token'):
                a_token = user['access_token']
                r_token = user['refresh_token']
                cache.cache_insert("cda_token", a_token)
                cache.cache_insert("cda_ref_token", r_token)
            else:
                return False

    def movie(self, imdb, title, localtitle, aliases, year):
        return self.search(title, localtitle, year, True)

    def tvshow(self, imdb, tmdb, tvshowtitle, localtvshowtitle, aliases, year):
        return (tvshowtitle, localtvshowtitle), year

    def episode(self, url, imdb, tmdb, title, premiered, season, episode):
        self.year = int(url[1])
        epNo = "s" + season.zfill(2) + "e" + episode.zfill(2)
        return self.search_ep(url[0][0], url[0][1], self.year, epNo)

    def contains_word(self, str_to_check, word):
        if str(word).lower() in str(str_to_check).lower():
            return True
        return False

    def contains_all_words(self, str_to_check, words):
        for word in words:
            if not self.contains_word(str_to_check, word):
                return False
        return True

    def similar(self, a, b):
        return SequenceMatcher(None, a, b).ratio()

    def levenshtein(self, s, t):
        ''' From Wikipedia article; Iterative with two matrix rows. '''
        if s == t: return 0
        elif len(s) == 0: return len(t)
        elif len(t) == 0: return len(s)
        v0 = [None] * (len(t) + 1)
        v1 = [None] * (len(t) + 1)
        for i in range(len(v0)):
            v0[i] = i
        for i in range(len(s)):
            v1[0] = i + 1
            for j in range(len(t)):
                cost = 0 if s[i] == t[j] else 1
                v1[j + 1] = min(v1[j] + 1, v0[j + 1] + 1, v0[j] + cost)
            for j in range(len(v0)):
                v0[j] = v1[j]

        return v1[len(t)]

    def search(self, title, localtitle, year, is_movie_search):

        q_title = localtitle.replace("'", "").replace(":", "").replace("-", " ").lower()
        data = {
            'query': q_title,
            'duration': 'medium',
            'page':  1,
            'limit': 100,
            'sort':  'best',
        }
        if self.email:
            self.oauth(self.email, self.passwd)
            self.headers.update({
                'Authorization': f'Bearer {cache.cache_get("cda_token")["value"]}'
            })

        search = self.session.get(self.search_link, params=data, headers=self.headers).json()

        if search:
            for item in search.get('data'):
                name = cleantitle.normalize(title).lower()
                local_name = cleantitle.normalize(q_title).lower()
                words = cleantitle.normalize(item['title']).lower()
                ratio = self.similar(name, words)
                local_ratio = self.similar(local_name, words)
                if 'zwiastun' not in words and 'trailer' not in words and 'recenzja' not in words:
                    if self.levenshtein(name, words) <= 20 or self.levenshtein(local_name, words) <= 20 and\
                            min(ratio, 0.40) < ratio < max(ratio, 1.0) or min(local_ratio, 0.40) < local_ratio < max(local_ratio, 1.0):
                            return item['id']

    def search_ep(self, title, localtitle, year, epNo):

        epNo = epNo.lower()
        data = {
            'query': localtitle.lower() + ' ' + epNo,
            'duration': 'medium',
            'page':  1,
            'limit': 100,
            'sort':  'best',
        }
        if self.email:
            self.oauth(self.email, self.passwd)
            self.headers.update({
                'Authorization': f'Bearer {cache.cache_get("cda_token")["value"]}'
            })

        search = self.session.get(self.search_link, params=data, headers=self.headers).json()

        if search:
            for item in search.get('data'):
                name = cleantitle.normalize(title).lower()
                local_name = cleantitle.normalize(localtitle).lower()
                words = cleantitle.normalize(item['title']).lower()
                ep_name = f'{name} {epNo}'
                local_ep_name = f'{local_name} {epNo}'
                ratio = self.similar(name, words)
                local_ratio = self.similar(local_name, words)
                exclude = ['zwiastun', 'trailer', 'recenzja']
                if epNo in words:
                    if any(ex not in words for ex in exclude):
                        if self.levenshtein(ep_name, words) <= 20 or self.levenshtein(local_ep_name, words) <= 20 and \
                            min(ratio, 0.40) < ratio < max(ratio, 1.0) or min(local_ratio, 0.40) < local_ratio < max(local_ratio, 1.0):
                            return item['id']
# Redukcja linii
#                    if 'zwiastun' not in words and 'trailer' not in words and 'recenzja' not in words:
#                        if self.levenshtein(ep_name, words) <= 20 or self.levenshtein(local_ep_name, words) <= 20 and\
#                            min(ratio, 0.40) < ratio < max(ratio, 1.0) or min(local_ratio, 0.40) < local_ratio < max(local_ratio, 1.0):
#                            return item['id']

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url is None:
                return sources
            else:
                if self.email:
                    self.headers.update({
                        'Authorization': f'Bearer {cache.cache_get("cda_token")["value"]}'
                    })

                query = self.session.get(f'{self.base_link}/video/{url}', headers=self.headers).json()
                video = query.get('video')
                #check adaptive stream
                # add if exist
                # further process in resolve method
                adaptive_data = video.get('quality_adaptive')
                if adaptive_data:
                    adaptive_quality = source_utils.get_quality(video.get('quality'))
                    cache.cache_insert('DRMCDA', repr(adaptive_data))
                    sources.append(
                        {
                            "source": "CDA",
                            "quality": f"{adaptive_quality}",
                            "language": 'pl',
                            "url": f'DRMCDA|{url}',
                            "info": "DRM Adaptive",
                            "direct": True,
                            "debridonly": False,
                        }
                    )

                for quality in video['qualities']:
                    if not quality.get('file', None):
                        print('Brak linku Direct - Niezalogowany lub content Premium')
                        continue
                    if "1080" in quality['name']:
                        sources.append(
                            {
                                "source": "CDA",
                                "quality": "1080p",
                                "language": 'pl',
                                "url": quality['file'],
                                "direct": True,
                                "debridonly": False,
                            }
                        )
                    if "720" in quality['name']:
                        sources.append(
                            {
                                "source": "CDA",
                                "quality": "720p",
                                "language": 'pl',
                                "url": quality['file'],
                                "direct": True,
                                "debridonly": False,
                            }
                        )
                    elif "480" in quality['name']:
                        sources.append(
                            {
                                "source": "CDA",
                                "quality": "SD",
                                "language": 'pl',
                                "url": quality['file'],
                                "direct": True,
                                "debridonly": False,
                            }
                        )
                    elif "360" in quality['name']:
                        sources.append(
                            {
                                "source": "CDA",
                                "quality": "SD",
                                "language": 'pl',
                                "url": quality['file'],
                                "direct": True,
                                "debridonly": False,
                            }
                        )
                    else:
                        sources.append(
                            {
                                "source": "CDA",
                                "quality": "SD",
                                "language": 'pl',
                                "url": quality['file'],
                                "direct": True,
                                "debridonly": False,
                            }
                        )
            return sources
        except Exception as e:
            log_exception()
            return sources


    def resolve(self, url):

        if 'DRMCDA' in url:
            adaptive = literal_eval(cache.cache_get('DRMCDA')["value"])
            PROTOCOL = 'mpd'
            DRM = 'com.widevine.alpha'
            manifest_url = adaptive.get('manifest')
            lic_url = adaptive.get('widevine_license')
            drm_header = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.62',
                'X-Dt-Custom-Data': adaptive.get('drm_header_value')
            }
            drm_header = urlencode(drm_header)
            # setting proxy
            proxy_path = control.settings.getString("_proxy_path")
            #tunneling licence url
            lic_url = f'{proxy_path}drmcda={lic_url}'
            adaptive_data = {
                'protocol': PROTOCOL,
                'licence_type': DRM,
                'mimetype': 'application/xml+dash',
                'manifest': manifest_url,
                'licence_url': lic_url,
                'licence_header': drm_header,
                'post_data': 'R{SSM}',
                'response_data': ''
            }
            link = f'DRMCDA|{repr(adaptive_data)}'
            test = literal_eval(link.split('|')[-1])
            print(test)
            return link
        else:
            link = str(url).replace('\\', '/')
        return str(link)
