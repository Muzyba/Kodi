from lib.windows.base_window import BaseDialog
from lib.ff.control import execute
from xbmcgui import ListItem


class ContextMenu(BaseDialog):
    def __init__(self, *args):
        BaseDialog.__init__(self, *args)
        self.items = []
        self.actions = []
        self.menu = []

    def onInit(self):
        self.add_items(9000, self.context_menu_items(self.items)[0])
        self.setFocus(self.getControl(9000))

    def onClick(self, controlId):
        if controlId == 9000:
            position = self.getControl(9000).getSelectedPosition()
            action = self.actions[position]

            if isinstance(action, str):
                execute(action)
            else:
                action()

            self.close()

    def context_menu_items(self, items):
        for item in items:
            li = ListItem(item[0])
            self.menu.append(li)
            self.actions.append(item[1])

        return self.menu, self.actions

    def open(self, items):
        self.items = items

        menu = self.doModal()
        del menu
