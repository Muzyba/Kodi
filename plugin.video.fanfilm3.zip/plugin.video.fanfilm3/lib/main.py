"""Main module."""

if __name__ == '__main__':

    def parse_args():
        from argparse import ArgumentParser
        from . import cmdline_argv

        p = ArgumentParser()
        p.add_argument('url', nargs='?', default='/', help='plugin url (or just path) [plugin://host]/path[?query]')
        p.add_argument('handle', nargs='?', default='1', help='plugin handle')
        p.add_argument('query', nargs='?', default='', help='plugin query, if not in url')
        p.add_argument('resume', nargs='?', default='resume:false', help='plugin resume?')
        p.add_argument('--lang', help='language (default: pl_PL)')
        p.add_argument('--api-lang', help='override override media API language (default from settings)')
        p.add_argument('-r', '--run', action='store_true', help='run in loop')
        p.add_argument('-i', '--info', metavar='INDEX', type=int, help='show info at given index')
        p.add_argument('-m', '--menu', metavar='INDEX', type=int, help='show context menu at given index')
        p.add_argument('-x', '--extra-info', metavar='INDEX', type=int, help='show extra debug info at given index')
        p.add_argument('-o', '--old', action='store_true', help='call old navigation')
        p.add_argument('--no-service', action='store_false', dest='service', help='skip service')
        return p.parse_args(cmdline_argv[1:])

    args = parse_args()

    if args.lang:
        from xbmcaddon import Addon
        Addon.LANG = args.lang
    if args.api_lang:
        from xbmcaddon import Settings
        Settings.API_LANGUAGE = args.api_lang.replace('_', '-')


import sys  # for exit()
from typing import Optional, Any, List, Dict, Set, TYPE_CHECKING
from typing_extensions import Literal

import xbmcgui

from const import const
from .ff.settings import settings
from .ff.sources import sources
from .ff.routing import URL, dispatch, default_router
from .ff import control
from .ff.control import Finally
from .ff.db import state
from .ff.log_utils import fflog, fflog_exc
from .ff.routing import route, PathArg
from .ff.menu import KodiDirectory, directory
from .ff.info import ffinfo
from .service.client import service_client
from .defs import VideoIds
from .indexers import navigator
from .kolang import L

if TYPE_CHECKING:
    from .service.misc import PluginRequestInfo


#: Number of plugin calls
run_count: int = 0


nav = navigator.Navigator()
default_router.set_default_route_object(nav)
default_router.url = URL(control.plugin_url)


def new_run() -> int:
    """Report new call. Return current call count."""
    # zliczaj liczbę wywołań FF
    global run_count
    if not run_count:
        from .ff.control import pretty_log_info
        pretty_log_info()
    run_count += 1
    return run_count


def reset() -> None:
    """Reset all stuff for reuse code (re-run in the same Python interpreter)."""
    L.reset()
    settings.reset()  # force recreate settings proxy
    control.reset()
    navigator.reset()
    ffinfo.reset()
    # trakt.trakt_credentials_manager.reset()


#: Folders to bypass.
empty_folders: Set[str] = set()


def bypass_scanning(info: 'PluginRequestInfo') -> bool:
    if info.scan_finished:
        empty_folders.clear()
    try:
        root, path, show_id, *waste, num = info.url.path.split('/')
    except Exception:
        return False
    if not root and not waste and path == 'tvshow' and f'/tvshow/{show_id}' == info.media_url.path and num.isdigit() and show_id.isdigit():
        with directory() as kdir:
            if info.scan_started:  # return all episodes (starting from 2nd sezon) in single folder
                from .defs import MediaRef
                from .ff.info import ffinfo
                ffitem = ffinfo.find_item(MediaRef.tvshow(int(show_id)), progress=ffinfo.Progress.NO, tv_episodes=True)
                if ffitem:
                    for sz in ffitem.season_iter():
                        if sz.season and sz.season >= 2:
                            for ep in sz.episode_iter():
                                kdir.add(ep, url=kdir.no_op)
                        empty_folders.add(f'/tvshow/{show_id}/{sz.season}')
        return True
    return False


def main(argv: List[str]) -> None:
    """The main FF entry."""

    def old(url: URL) -> None:
        fflog.error(f'Unsuported URL {url}')
        raise ValueError(f'Unsuported URL {url}')
        # old_main(argv)

    url = URL(argv[0] + argv[2])
    if url.path in empty_folders:
        from xbmcplugin import endOfDirectory
        endOfDirectory(int(sys.argv[1]), updateListing=False, cacheToDisc=False)
        return
    Finally.clear()
    folder_info = service_client.plugin_request_enter(url)
    KodiDirectory.set_current_info(folder_info)
    master: bool = state.enter('plugin')
    state.delete_all(module='directory')
    state.multi_set((
        ('running', True),
        ('url', str(url)),
        ('path', url.path),
    ), module='directory')
    try:
        if folder_info.scan and bypass_scanning(folder_info):
            trakt_db_timestamp = state.get('db.timestamp', module='trakt', default=0)
        else:
            KodiDirectory.ready_for_data()
            trakt_db_timestamp = state.get('db.timestamp', module='trakt', default=0)
            dispatch(url, missing=old)
    except Exception:
        fflog_exc()
        raise
    else:
        # handle queued jobs
        for job in state.jobs('plugin'):
            handle_job(job, argv)
        if KodiDirectory.INFO.refresh:
            new_timestamp = state.get('db.timestamp', module='trakt', default=0)
            fflog(f'!@#$!@#!@#!@#!@#!@#!@#!@#!@#!@#!@#!@#!@#!@#!@ {trakt_db_timestamp=}, {new_timestamp=}')
            if new_timestamp != trakt_db_timestamp:
                control.refresh()
    finally:
        service_client.plugin_request_exit(folder=KodiDirectory.CREATED, focus=KodiDirectory.FOCUS_INDEX)
        state.set('running', False, module='directory')
        state.exit('plugin')
        for fin in Finally.iter():
            fin()
        Finally.clear()


@route
def xplay(type: PathArg[Literal['movie', 'tvshow']], dbid: PathArg[int],
          season: Optional[PathArg[int]] = None, episode: Optional[PathArg[int]] = None) -> None:
    """Play video."""
    print(f'play({type=}, {dbid=}, {season=}, {episode=}) ...')


@route('/play/movie')
def play_movie(dbid: PathArg[int], *, edit: bool = False) -> None:
    """Play movie video."""
    print(f'play.movie({dbid=}) ...')
    sources().play('movie', dbid, edit_search=edit)


@route('/play/tvshow')
def play_tvshow(tv_dbid: PathArg[int], season: PathArg[int], episode: PathArg[int], *, edit: bool = False) -> None:
    """Play episode video."""
    print(f'play.tvshow({tv_dbid=}, {season=}, {episode=}) ...')
    sources().play('show', tv_dbid, season, episode, edit_search=edit)


# Keep:
# plugin://plugin.video.fanfilm/?action=play&name=Rebel+Moon+-+Part+One%3A+A+Child+of+Fire+%282023%29&title=Rebel+Moon+-+Part+One%3A+A+Child+of+Fire&localtitle=Rebel+Moon+%E2%80%93+cz%C4%99%C5%9B%C4%87+1%3A+Dziecko+Ognia&year=2023&imdb=tt14998742&tmdb=848326
# plugin://plugin.video.fanfilm/?action=play&title=What+If...+Strange+Supreme+Intervened%3F&year=2021&imdb=tt10168312&tmdb=91363&season=2&episode=9&tvshowtitle=What+If...%3F&date=2023-12-30


# Kolejnośc ma znaczenie, old_play_tvshow() musi być nad old_play_movie(),
# bo inaczej filmy zjedzą seriale (mają podzbiór argumentów, więc trafią).
@route('/')
def old_play_tvshow(action: Literal['play'], tmdb: int, season: int, episode: int, **kwargs) -> None:
    """Play movie video in old API (up to FanFilm 2023)."""
    dbid = VideoIds(tmdb=tmdb, imdb=kwargs.get('imdb')).dbid
    if dbid:
        fflog(f'old play.tvshow({tmdb=}, {season=}, {episode=}):  {dbid=} ...')
        play_tvshow(dbid, season, episode)
    else:
        fflog(f'old play.tvshow({tmdb=}, {season=}, {episode=}):  {dbid=} FAILED')


# Musi być po serialach, patrz komentarz wyżej.
@route('/')
def old_play_movie(action: Literal['play'], tmdb: int, **kwargs) -> None:
    """Play movie video in old API (up to FanFilm 2023)."""
    dbid = VideoIds(tmdb=tmdb, imdb=kwargs.get('imdb')).dbid
    if dbid:
        fflog(f'old play.movie({tmdb=}):  {dbid=} ...')
        play_movie(dbid)
    else:
        fflog(f'old play.movie({tmdb=}):  {dbid=} FAILED')


@route
def rescan(dbid: Optional[PathArg[int]] = None) -> None:
    """Rescan sources in source window."""
    # from lib.ff import sources
    from lib.ff.cache import cache_clear_sources, cache_clear_providers

    # `dbid` is ignored now. This method clear cache and emulate click in gui.

    cache_clear_sources()
    cache_clear_providers()
    checkWin = xbmcgui.getCurrentWindowId()

    control.execute("Dialog.Close(all,true)")
    control.execute(f"ReplaceWindow({checkWin})")
    control.execute("Action(Select)")


@route
def crash() -> None:
    """Forces crash, raises en exception."""
    raise Exception('Devleper forced CRASH')


def handle_job(job: state.Job, argv: List[str]) -> None:
    """Handle pending job."""

    if const.debug.enabled:
        if const.debug.tty:
            fflog(f'[JOB] \033[96mjob\033[0m: {job}')
        else:
            fflog(f'[JOB] job: {job}')
    if job.command == 'update':
        if job.args and job.args[0]:
            path = job.args[0]
        else:
            path = ''#f'{argv[0]}{argv[2]}'  # path to current plugin call
        control.update(path)
    elif job.command == 'refresh':
        control.refresh()
    elif job.command == 'builtin':
        control.execute(job.args[0])


# --- stara obsługa, raczej nie działa ---

# def old_main(argv: List[str]):
#     """The obsoleted main FF entry."""
#     action_url: ParseResult = urlparse(argv[0])
#     plugin_url: str = f"{action_url.scheme}://{action_url.netloc}/"
#     action_path = action_url.path or "/"
#     params: Params = get_params(argv[2])
#     action: str = params.get("action")

#     master: bool = state.enter("plugin")
#     try:
#         if const.debug.enabled:
#             if const.debug.tty:
#                 yellow, off = '\033[93m', '\033[0m'
#             else:
#                 yellow = off = ''
#             fflog(f"{yellow}[FF]{off} action={action!r}, params={params!r}, master={master!r}")

#         if action == "play" and xbmc.getCondVisibility('Player.Passthrough'):
#             sys.exit()

#         if params.get("busy") == "true":
#             xbmc.executebuiltin("ActivateWindow(busydialognocancel)")

#         # Set current action. After return it's last action.
#         state.set("action", f"{action_path or '/legacy'}:{action}", module="plugin")

#         exception: Optional[Exception] = None
#         try:
#             execute_action(plugin_url, action_path, params)
#         except Exception as e:
#             exception = e
#             fflog_exc()
#         finally:
#             workers.Thread.stop_all()
#             # handle queued jobs
#             for job in state.jobs("plugin"):
#                 handle_job(job, argv)
#             # handle exception
#             if exception:
#                 control.execute("Dialog.Close(busydialognocancel)")
#                 connection_manager.close_all()
#                 workers.Thread.stop_all()
#                 raise exception
#             # Dodane warunki dla sys.exit:
#             excluded_actions = ["tvSearch", "tvSearchnew", "tvSearchterm",
#                                 "movieSearch", "movieSearchnew", "movieSearchterm", "movieSearchEPG"]
#             if (action not in excluded_actions and run_count >= const.core.exit_every_nth):
#                 fflog("sys.exit")
#                 sys.exit()

#     finally:
#         state.exit("plugin")


# def get_params(query_string: str) -> Params:
#     params = dict(parse_qsl(query_string.replace("?", "")))
#     if "url" in params:
#         params["url"] = unquote_plus(params["url"])
#     if "windowedtrailer" in params:
#         params["windowedtrailer"] = int(params["windowedtrailer"]) if params["windowedtrailer"] in ("0", "1") else 0

#     for key, value in params.items():
#         fflog(f"{key.capitalize()}: {value}")

#     return params


# def execute_action(plugin_url: str, action_path: str, params: Params):
#     if action_path == "/":  # root & legacy
#         nav = navigator.navigator()

#         action_map = {
#             None: nav.root,
#             "movieNavigator": nav.movies,
#             "mymovieNavigator": nav.mymovies,
#             "tvNavigator": nav.tvshows,
#             "mytvNavigator": nav.mytvshows,
#             "downloadNavigator": nav.downloads,
#             "libraryNavigator": nav.library,
#             "cacheNavigator": nav.cache,
#             "toolNavigator": nav.tools,
#             "searchNavigator": nav.search,
#             "viewsNavigator": nav.views
#         }

#         action = params.get("action")

#         if action in action_map:
#             action_map[action]()
#         else:
#             extended_actions(plugin_url, params)

#     elif action_path.startswith("/"):
#         if action_path.endswith("/"):
#             action_path = action_path[:-1]
#         name = action_path[1:].replace("/", "_")
#         handler = globals().get(f"on_action_{name}")
#         if handler is None:
#             from xbmcgui import Dialog
#             fflog(f"No {action_path} handler")
#             Dialog().notification("FanFilm", f"No {action_path} handler")
#         else:
#             handler(plugin_url, params)


# def extended_actions(plugin_url: str, params: Params):
#     action = params.get("action")
#     term = params.get("term")
#     query = params.get("query")
#     url = params.get("url")
#     imdb = params.get("imdb")
#     tmdb = params.get("tmdb")
#     name = params.get("name")
#     year = params.get("year")
#     season = params.get("season")
#     episode = params.get("episode")
#     content = params.get("content")
#     select = params.get("select")
#     image = params.get("image")
#     source = params.get("source")
#     title = params.get("title")
#     localtitle = params.get("localtitle")
#     windowedtrailer = params.get("windowedtrailer")
#     if action is None:
#         navigator.navigator().root()
#     elif action == "moviestoresume":
#         from lib.indexers import movies
#         movies.movies().get("moviestoresume")
#     elif action == "episodestoresume":
#         from lib.indexers.episodes import Episodes
#         Episodes().get(None, None, url="episodestoresume")
#     elif action == "removeFromSearchHistory":
#         navigator.navigator().removeFromSearchHistory(term)
#         control.refresh()
#     elif action == "clearCache":
#         navigator.navigator().clearCache()
#     elif action == "clearCacheMeta":
#         navigator.navigator().clearCacheMeta()
#     elif action == "clearCacheBookmarks":
#         navigator.navigator().clearCacheBookmarks()
#     elif action == "clearCacheProviders":
#         navigator.navigator().clearCacheProviders()
#     elif action == "clearCachedSources":
#         navigator.navigator().clearCachedSources()
#     elif action == "clearCacheSearch":
#         navigator.navigator().clearCacheSearch()
#     elif action == "removeFromSearchHistory":
#         navigator.navigator().removeFromSearchHistory(term)
#         control.refresh()
#     elif action == "clearCacheAll":
#         navigator.navigator().clearCacheAll()
#     elif action == "clearViews":
#         navigator.navigator().clearCacheView()
#     elif action == "downloadManager":
#         from lib.ff import downloader
#         try:
#             downloader.downloadManager()
#         except Exception:
#             fflog_exc()
#     elif action == "movies":
#         from lib.indexers import movies
#         movies.movies().get(url)
#     elif action == "moviePage":
#         from lib.indexers import movies
#         movies.movies().get(url)
#     elif action == "movieSearch":
#         from lib.indexers import movies
#         movies.movies().search()
#     elif action == "movieSearchnew":
#         from lib.indexers import movies
#         movies.movies().search_new()
#     elif action == "movieSearchterm":
#         from lib.indexers import movies
#         movies.movies().search_term(name)
#     elif action == "movieSearchEPG":
#         from lib.indexers import movies
#         movies.movies().search_epg(name, year)
#     elif action == "similar":
#         from lib.indexers import movies
#         movies.movies().similar(tmdb)
#     elif action == "moviePerson":
#         from lib.indexers import movies
#         movies.movies().person()
#     elif action == "movieGenres":
#         from lib.indexers import movies
#         movies.movies().genres()
#     elif action == "movieLanguages":
#         from lib.indexers import movies
#         movies.movies(action=action).languages(all_languages=params.get("all"))
#     elif action == "movieCountries":
#         from lib.indexers import movies
#         movies.movies(action=action).countries(all_countries=params.get("all"))
#     elif action == "movieCertificates":
#         from lib.indexers import movies
#         movies.movies().certifications()
#     elif action == "movieYears":
#         from lib.indexers import movies
#         movies.movies().years()
#     elif action == "movieYearsTop":
#         from lib.indexers import movies
#         movies.movies().years_top()
#     elif action == "moviesAwards":
#         from lib.indexers import movies
#         movies.movies().awards()
#     elif action == "moviePersons":
#         from lib.indexers import movies
#         movies.movies().persons(url)
#     elif action == "movieUserlists":
#         from lib.indexers import movies
#         movies.movies().userlists()
#     elif action == "channels":
#         from lib.indexers import channels
#         channels.channels().get()
#     elif action == "tvshows":
#         from lib.indexers import tvshows
#         tvshows.tvshows().get(url)
#     elif action == "tvshowPage":
#         from lib.indexers import tvshows
#         tvshows.tvshows().get(url)
#     elif action == "tvSearch":
#         from lib.indexers import tvshows
#         tvshows.tvshows().search()
#     elif action == "tvSearchnew":
#         from lib.indexers import tvshows
#         tvshows.tvshows().search_new()
#     elif action == "tvSearchterm":
#         from lib.indexers import tvshows
#         tvshows.tvshows().search_term(name)
#     elif action == "tvPerson":
#         from lib.indexers import tvshows
#         tvshows.tvshows().person()
#     elif action == "tvGenres":
#         from lib.indexers import tvshows
#         tvshows.tvshows().genres()
#     elif action == "tvNetworks":
#         from lib.indexers import tvshows
#         tvshows.tvshows().networks()
#     elif action == "tvLanguages":
#         from lib.indexers import tvshows
#         tvshows.tvshows(action=action).languages(all_languages=params.get("all"))
#     elif action == "tvCountries":
#         from lib.indexers import tvshows
#         tvshows.tvshows(action=action).countries(all_countries=params.get("all"))
#     elif action == "tvCertificates":
#         from lib.indexers import tvshows
#         tvshows.tvshows().certifications()
#     elif action == "tvYears":
#         from lib.indexers import tvshows
#         tvshows.tvshows().years()
#     elif action == "tvYearsTop":
#         from lib.indexers import tvshows
#         tvshows.tvshows().years_top()
#     elif action == "tvPersons":
#         from lib.indexers import tvshows
#         tvshows.tvshows().persons(url)
#     elif action == "tvUserlists":
#         from lib.indexers import tvshows
#         tvshows.tvshows().userlists()
#     elif action == "seasons":
#         from lib.indexers.seasons import Seasons
#         Seasons().get(imdb, tmdb)
#     elif action == "episodes":
#         from lib.indexers.episodes import Episodes
#         Episodes().get(imdb, tmdb, season, episode)
#     elif action == "calendar":
#         from lib.indexers.episodes import Episodes
#         Episodes().calendar(url)
#     elif action == "calendars":
#         from lib.indexers.episodes import Episodes
#         Episodes().calendars()
#     elif action == "episodeUserlists":
#         from lib.indexers.episodes import Episodes
#         Episodes().userlists()
#     elif action == "refresh":
#         control.refresh()
#     elif action == "queueItem":
#         control.queueItem()
#     elif action == "openSettings":
#         control.openSettings()
#     elif action == "addView":
#         from lib.ff import views
#         views.addView(content)
#     elif action == "moviePlaycount":
#         from lib.ff import playcount
#         xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
#         playcount.movies(imdb, query, refresh=True)
#     elif action == "episodePlaycount":
#         from lib.ff import playcount
#         xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
#         playcount.episodes(imdb, tmdb, season, episode, query, refresh=True)
#     elif action == "tvPlaycount":
#         from lib.ff import playcount
#         xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
#         playcount.tvshows(name, imdb, tmdb, season, query)
#     elif action == "trailer":
#         from lib.ff import trailer
#         trailer.trailer().play(name, url, windowedtrailer)
#     elif action == "traktManager":
#         trakt.manager(name, imdb, tmdb, content)
#     elif action == "smuSettings":
#         try:
#             import resolveurl
#         except:
#             pass
#         resolveurl.display_settings()
#     elif action == "download":
#         from lib.ff import downloader, sources

#         try:
#             downloader.download(
#                 name,
#                 image,
#                 sources.sources().sourcesResolve(json.loads(source)[0], True),
#             )
#         except Exception:
#             pass
#     elif action == "play":
#         from lib.ff import sources
#         if select:
#             select = int(select)
#         sources.sources().play(imdb, tmdb, season, episode, select)
#     elif action == "rescan":
#         from lib.ff import sources
#         from lib.ff.cache import cache_clear_sources, cache_clear_providers

#         cache_clear_sources()
#         cache_clear_providers()
#         checkWin = xbmcgui.getCurrentWindowId()

#         control.execute("Dialog.Close(all,true)")

#         control.execute(f"ReplaceWindow({checkWin})")
#         control.execute("Action(Select)")
#     elif action == "alterSources":
#         from lib.ff import sources
#         sources.sources().alterSources(url)
#     elif action == "random":
#         rtype = params.get("rtype")
#         if rtype == "movie":
#             from lib.indexers import movies
#             rlist = movies.movies().get(url, create_directory=False)
#             r = f"{plugin_url}?action=play"
#         elif rtype == "episode":
#             from lib.indexers.episodes import Episodes
#             rlist = Episodes().get(imdb, tmdb, season, create_directory=False)
#             r = f"{plugin_url}?action=play"
#         elif rtype == "season":
#             from lib.indexers.seasons import Seasons
#             rlist = Seasons().get(imdb, tmdb, create_directory=False)
#             r = f"{plugin_url}?action=random&rtype=episode"
#         elif rtype == "show":
#             from lib.indexers import tvshows
#             rlist = tvshows.tvshows().get(url, create_directory=False)
#             r = f"{plugin_url}?action=random&rtype=season"
#         from random import randint
#         try:
#             rand = randint(1, len(rlist)) - 1
#             for p in [
#                 "title",
#                 "year",
#                 "imdb",
#                 "tmdb",
#                 "season",
#                 "episode",
#                 "tvshowtitle",
#                 "premiered",
#                 "select",
#             ]:
#                 if rtype == "show" and p == "tvshowtitle":
#                     try:
#                         r += "&" + p + "=" + quote_plus(rlist[rand]["title"])
#                     except:
#                         pass
#                 else:
#                     try:
#                         r += "&" + p + "=" + quote_plus(rlist[rand][p])
#                     except:
#                         pass
#             try:
#                 r += "&meta=" + quote_plus(json.dumps(rlist[rand]))
#             except:
#                 r += "&meta=" + quote_plus("{}")
#             if rtype == "movie":
#                 try:
#                     control.infoDialog(
#                         rlist[rand]["title"],
#                         control.lang(32536),
#                         time=30000,
#                     )
#                 except:
#                     pass
#             elif rtype == "episode":
#                 try:
#                     control.infoDialog(
#                         rlist[rand]["tvshowtitle"]
#                         + " - Season "
#                         + rlist[rand]["season"]
#                         + " - "
#                         + rlist[rand]["title"],
#                         control.lang(32536),
#                         time=30000,
#                     )
#                 except:
#                     pass
#             control.run_plugin(r)
#         except:
#             control.infoDialog(control.lang(32537), time=8000)
#     elif action == "movieToLibrary":
#         from lib.ff import libtools
#         libtools.libmovies().add(name, title, localtitle, year, imdb, tmdb)
#     elif action == "moviesToLibrary":
#         from lib.ff import libtools
#         libtools.libmovies().range(url)
#     elif action == "moviesMultiToLibrary":
#         from lib.ff import libtools
#         libtools.libmovies().multi(select)
#     elif action == "moviesToLibrarySilent":
#         from lib.ff import libtools
#         libtools.libmovies().silent(url)
#     elif action == "tvshowToLibrary":
#         from lib.ff import libtools
#         libtools.libtvshows().add(imdb, tmdb, season, episode)
#     elif action == "tvshowsToLibrary":
#         from lib.ff import libtools
#         libtools.libtvshows().range(url)
#     elif action == "tvshowsToLibrarySilent":
#         from lib.ff import libtools
#         libtools.libtvshows().silent(url)
#     elif action == "updateLibrary":
#         from lib.ff import libtools
#         libtools.libepisodes().update(query)
#     elif action == "service":
#         from lib.ff import libtools
#         libtools.libepisodes().service()
#     elif action == "tmdbauthorize":
#         from lib.ff import tmdbauth
#         tmdbauth.Auth().create_session_id()
#         # sys.exit()
#     elif action == "tmdbdeauthorize":
#         from lib.ff import tmdbauth
#         tmdbauth.Auth().revoke_session_id()
#         # sys.exit()
#     elif action == "colorpicker":
#         from lib.ff.colorpicker import ColorPicker
#         colorpicker = ColorPicker('ColorPicker.xml', control.addonPath, default_color=params.get("default"))
#         if params.get("do") == "open_window":
#             colorpicker.run(params["service"])
#         elif params.get("do") == "save_color":
#             colorpicker.save_color(params["service"], params.get("color"))
#         sys.exit()
#     elif action == "crash":
#         raise Exception('CRASH on demand')
#     control.execute("Dialog.Close(busydialognocancel)")


# def on_action_settings_set(plugin_url: str, params: Params) -> None:
#     """Handle /settings/set endpoint."""
#     name = params.get("name")
#     value = params.get("value")
#     if name:
#         fflog("Remote set setting {name!} to {value!r}")
#         settings.setSetting(name, value)
#     else:
#         log("Missing setting name", LOGWARNING)


# def on_action_dev_trakt_playback_sync(plugin_url: str, params: Params) -> None:
#     trakt.playback_sync()


# def on_action_tv_watched(plugin_url: str, params: Params) -> None:
#     from .ff.trakt2 import trakt
#     action = params.get("action")
#     season = params.get("season")
#     episode = params.get("episode")
#     what = "episodes" if episode is not None else "seasons" if season is not None else "shows"
#     ids = {k: params.get(k) for k in ("imdb", "tmdb")}
#     if action == 'set':
#         x = trakt.add_history_item(what, ids, season=season, episode=episode)
#         fflog(f'[WATCHED]  +1 :: {x!r}')
#     elif action == 'unset':
#         x = trakt.remove_history_item(what, ids, season=season, episode=episode)
#         fflog(f'[WATCHED]  -1 :: {x!r}')
#     else:
#         log(f'Unknown action {action!r} in /tv/watched', LOGWARNING)
#     trakt.sync()
#     control.refresh()


# def on_action_job_refresh(plugin_url: str, params: Params) -> None:
#     control.refresh()


# def on_action_job_update(plugin_url: str, params: Params) -> None:
#     control.update()


# def on_action_trakt_auth(plugin_url: str, params: Params):
#     """Authorize device."""
#     from xbmcgui import Dialog
#     if trakt.auth():
#         Dialog().notification("FanFilm", L("Trakt connected"))
#         state.add_job('service', 'trakt.sync', sender='plugin')
#         control.refresh()
#     else:
#         Dialog().notification("FanFilm", L("Trakt authorize FAILED"))


# def on_action_trakt_unauth(plugin_url: str, params: Params):
#     """Remove device authorization."""
#     from xbmcgui import Dialog
#     if control.yesnoDialog(control.lang(32056)):
#         trakt.unauth()
#         Dialog().notification("FanFilm", L("Trakt disconnected"))
#         control.refresh()


# def on_action_nothing(plugin_url: str, params: Params) -> None:
#     pass


# def on_action_xxx(plugin_url: str, params: Params) -> None:
#     # import traceback
#     # fflog(traceback.format_stack())
#     from lib.kover.k20 import xbmcgui_ListItem as ListItem
#     fflog(dir(ListItem))
#     fflog(getattr(ListItem, '__init__', None))
#     fflog(getattr(ListItem, '__init__', None) is object.__init__)

#     from lib.ff.item import FFItem
#     from lib.defs import MediaRef
#     item = FFItem(MediaRef('show', 12345, 2))
#     fflog(f'{item.getLabel()!r}')
#     fflog(f'{item!r}')
#     return

#     def dump_gets(obj):
#         for n in dir(obj):
#             if n.startswith('get'):
#                 getter = getattr(obj, n)
#                 try:
#                     val = getter()
#                 except TypeError:
#                     try:
#                         val = getter('xxx')
#                     except TypeError:
#                         fflog(f'  {obj.__class__.__name__}.{n}() = ???')
#                         continue
#                 fflog(f'  {obj.__class__.__name__}.{n}() = {val!r}')

#     from lib.kover.k20 import xbmcgui_ListItem as ListItem
#     item = ListItem()
#     dump_gets(item)
#     dump_gets(item.getVideoInfoTag())
#     return
#     # from xbmcgui import ListItem
#     # from lib.kover.k20 import xbmcgui_ListItem as ListItem
#     # item = ListItem('qweqwe')
#     # vtag = item.getVideoInfoTag()
#     # vtag.setSeason(1)
#     # fflog(f'ITEM: {item!r}, {vtag.getSeason()} : {item.getLabel()!r}')
#     # return
#     from lib.ff.item import FFItem
#     from lib.defs import MediaRef
#     # item = FFItem('qweqwe', type='show', dbid=123)
#     # item = FFItem(MediaRef('movie', 12345))
#     item = FFItem(MediaRef('show', 12345, 2))
#     vtag = item.getVideoInfoTag()
#     # item.season = 1
#     # fflog(f'ITEM: {item!r}, {vtag}')
#     # fflog(f'ITEM: {item!r}, {vtag.getSeason()} : {item.getLabel()!r}')
#     fflog(f'ITEM: {item!r}, {vtag.getSeason()} : {item.getLabel()!r} … {item.type!r}, {item.ref}, {item.key}')
#     # vtag.setSeason(None)
#     del item
#     pass


# --- testy (konsola)  ---


if __name__ == '__main__':
    def main_test():
        import re
        from pprint import pformat
        import sty
        from . import cmdline_argv
        from .fake.fake_api import reset as fake_reset, url_at_index, get_directory, print_last_directory
        from .fake.fake_term import print_table, formatting, text_width, text_left
        from .fake.xbmcplugin import _Item
        from const import constdef
        # from .ff.menu import KodiDirectory

        def start_service():
            from .ff.threads import Event
            from .service.http_server import Proxy
            from .service.trakt import TraktSync
            from .service.misc import VolatileDbid
            from .service.main import Works
            from .service.http_server import RequestHandler

            RequestHandler.DEFAULT_PORT = 8123
            service_client._url = f'http://127.0.0.1:{RequestHandler.DEFAULT_PORT}/'
            works = Works()
            works.trakt_sync = TraktSync()
            works.http = Proxy(works=works)
            works.trakt_sync.start()
            works.http.start()
            return works

        def stop_service(works):
            works.trakt_sync.stop()
            works.http.stop()

        def show_info(item: _Item, index: int = 0):
            dim = sty.bg(240)
            it = item.item
            print(f'{sty.ef.bold}{sty.fg(35)}-- Info --{sty.rs.all}')
            print(f'[INFO] {index}. url={item.url}, folder={item.folder}, item={it}')
            vtag = it.getVideoInfoTag()
            descr = formatting(str(vtag.getPlot() or '')).replace('\n', f'{dim}[CR]{sty.rs.bg}')
            if text_width(descr) > 199:
                descr = f'{text_left(descr, 199)}{dim}…{sty.rs.bg}'
            print_table((
                ('Label:', repr(it.getLabel())),
                ('Label2:', repr(it.getLabel2())),
                ('Title:', repr(vtag.getTitle())),
                ('TVShowTitle:', repr(vtag.getTVShowTitle())),
                ('Year:', repr(vtag.getYear())),
                ('Duration:', repr(vtag.getDuration())),
                ('Art:', pformat(it.getArt())),
                ('Descr:', descr),
            ))

        def show_extra(item: _Item, index: int = 0):
            from .ff.info import ffinfo, FFItem, MediaRef
            show_info(item=item, index=index)
            print(33*'-')
            print(f'{item=}')
            it: FFItem = item.item
            denorm = MediaRef(it.ref.real_type, it.dbid)
            print(denorm)
            print(ffinfo.find_item(denorm))
            print_table((
                ('Poperties:', pformat(it.getProperties())),
            ))

        def show_menu(item: _Item, index: int = 0) -> bool:
            nonlocal url
            it = item.item
            cm = it._get_context_menu()
            tab = [('0.', 'Cancel', '')]
            tab.extend((f'{i}.', *m) for i, m in enumerate(cm, 1))
            print(f'{sty.ef.bold}{sty.fg(35)}-- Context menu --{sty.rs.all}')
            cformats = ['{}', f'\b{sty.bg.da_blue}{{}}{sty.rs.all}', '{}']  # cell format
            print_table(tab, cformats=cformats)
            target = ''
            if args.run:
                while True:
                    try:
                        cmd = input('Enter menu number: ')
                    except EOFError:
                        sys.exit()
                    if cmd.isdigit():
                        index = int(cmd)
                        if not index:
                            break
                        if 1 <= index < len(cm) + 1:
                            target = cm[index - 1][1]
                            break
                    print(f'{sty.fg.red}Invalid number{sty.rs.all}')
            if (mch := re.fullmatch(r'RunPlugin\((.*)\)', target)):
                fake_reset()
                history.append(url)
                url = mch[1]
                return True
            elif args.run:
                print(f'{sty.ef.bold}{sty.bg(23)}-- {url} --{sty.rs.all}')
                print_last_directory()
            return False

        plugin = 'plugin.video.fanfilm'  # DEBUG (terminal)
        handle = 1
        resume = 'resume:false'
        argv = list(cmdline_argv)
        # KodiDirectory._DEBUG_PRINT_LIST = True

        args = parse_args()
        # print(args)

        if not sys.stdout.isatty():
            for k in dir(sty):
                o = getattr(sty, k)
                if isinstance(o, sty.Register):
                    o.mute()
        if not args.url:
            args.url = '/'
        if '://' not in args.url:
            assert args.url.startswith('/')
            args.url = f'plugin://plugin.video.fanfilm{args.url or "/"}'  # DEBUG (terminal)
        if args.query:
            args.query = args.query.removeprefix('?')
            if '?' in args.url:
                args.url = f'{args.url}&{args.query}'
            else:
                args.url = f'{args.url}?{args.query}'
        # print(sys.argv)
        if not args.service:
            constdef.locked = False  # type: ignore
            const.tune.service.http_server.try_count = 1
            constdef.locked = True  # type: ignore
        if args.lang:
            from xbmcaddon import Addon
            Addon.LANG = args.lang

        url = args.url
        history: List[str] = []
        if args.service:
            service = start_service()
        else:
            service = None
            service_client.__class__.LOG_EXCEPTION = False
        while True:
            u0, sep, u2 = url.partition('?')
            sys.argv = [u0, args.handle, sep+u2, args.resume]
            print(f'{sty.ef.bold}{sty.bg(23)}-- {url} --{sty.rs.all}')
            try:
                if args.old:
                    old_main(sys.argv)
                else:
                    main(sys.argv)
            except EOFError:
                break
            if args.info:
                item = get_directory()[args.info-1]
                show_info(item, args.info)
                args.info = None
            if args.extra_info:
                item = get_directory()[args.extra_info-1]
                show_extra(item, args.extra_info)
                args.extra_info = None
            if args.menu:
                item = get_directory()[args.menu-1]
                redirect = show_menu(item, args.menu)
                args.menu = None
                if redirect:
                    continue
            if args.run:
                try:
                    while True:
                        cmd = input('Enter list number: ')
                        if cmd.strip():
                            break
                        print_last_directory()
                except EOFError:
                    break
                if cmd[-1:] in 'iI' and cmd[:-1].isdigit():
                    index = int(cmd[:-1])
                    if index:
                        try:
                            item = get_directory()[index-1]
                            it = item.item
                        except IndexError:
                            print(f'{sty.fg.red}Invalid number{sty.rs.all}')
                        else:
                            show_info(item, index)
                elif cmd[-1:] in 'cmCM' and cmd[:-1].isdigit():
                    index = int(cmd[:-1])
                    if index:
                        try:
                            item = get_directory()[index-1]
                        except IndexError:
                            print(f'{sty.fg.red}Invalid number{sty.rs.all}')
                        else:
                            show_menu(item, index)
                elif cmd.isdigit():
                    index = int(cmd)
                    if index:
                        try:
                            history.append(url)
                            url = url_at_index(index - 1)
                        except IndexError:
                            print(f'{sty.fg.red}Invalid number{sty.rs.all}')
                    else:
                        if history:
                            url = history.pop()
                        else:
                            url = '/'
                fake_reset()
            else:
                break
        if service:
            stop_service(service)

    main_test()
