"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from typing import Optional, Union, Sequence, TYPE_CHECKING
from typing_extensions import cast

from lib.ff import control
from ..ff.trakt2 import trakt
from ..ff.tmdb import tmdb
from ..ff.menu import directory, ContentView
from ..ff.routing import route, subobject, RouteObject
from ..ff.tricks import singleton
from ..ff.info import ffinfo
from ..ff.item import FFItem
from ..ff.types import PagedItemList
from ..defs import MediaRef
from ..kolang import L
from const import const
if TYPE_CHECKING:
    from .movies import Movies
    from .tvshows import TVShows
    from .persons import Persons
    from .stump import Keywords
    from .stump import Companies
    from .collections import Collections
    from .lists import TraktLists, TmdbLists, ImdbLists
    from .tools import Tools


def reset() -> None:
    """Reset navigator stuff for reuse code (re-run in the same Python interpreter)."""
    ...


reset()


@singleton
class Navigator(RouteObject):
    """Głowne menu FanFilm."""

    @route('/')
    def home(self) -> None:
        """Create root / main menu."""
        with directory(prefix='/') as kdir:
            kdir.folder(L(32001, 'Movies'), Navigator.movie, thumb='movies.png', icon='DefaultMovies.png')
            kdir.folder(L(32002, 'TV Shows'), Navigator.tvshow, thumb='tvshows.png', icon='DefaultTVShows.png')
            if const.indexer.navigator.lists_submenu:
                if trakt.credentials() or tmdb.credentials():
                    kdir.folder(L(30149, 'My Lists'), self.lists, thumb='userlists.png')
            else:
                if trakt.credentials():
                    kdir.folder(L(30164, 'My Trakt Lists'), self.trakt.home, thumb='trakt.png')
                if tmdb.credentials():
                    kdir.folder(L(30165, 'My TMDB Lists'), self.tmdb.home, thumb='tmdb.png')
                # kdir.folder(L('My IMDB Lists'), self.imdb.home, thumb='imdb.png')
            kdir.folder(L(32008, 'Tools'), Navigator.tools, thumb='tools.png')
            kdir.folder(L(32010, 'Search'), self.search, thumb='search.png')

    @route
    def search(self) -> None:
        """Main search menu."""
        with directory(thumb='search.png') as kdir:
            kdir.folder(L(32001, 'Movies'), self.movie.search, icon='DefaultMovies.png')
            kdir.folder(L(32002, 'TV Shows'), self.tvshow.search, icon='DefaultTVShows.png')
            kdir.folder(L(30175, 'Persons'), self.person.search, thumb='people-search.png', icon='people-search.png')
            kdir.folder(L(30137, 'Keywords'), self.keyword.search)
            kdir.folder(L(30138, 'Companies'), self.company.search)
            kdir.folder(L(30151, 'Movie Collections'), self.collection.search)

    @route
    def settings(self) -> None:
        """Open the settings."""
        control.openSettings()
        # control.execute("Dialog.Close(busydialognocancel)")

    @route('/list')
    def lists(self) -> None:
        """User lists (for all services)."""
        with directory(view='sets') as kdir:
            if trakt.credentials():
                kdir.folder(L(30176, 'Trakt'), self.trakt.home, thumb='trakt.png')
            if tmdb.credentials():
                kdir.folder(L(32775, 'TMDB'), self.tmdb.home, thumb='tmdb.png')
            kdir.folder(L(30177, 'IMDB'), self.imdb.home, thumb='imdb.png')

    @route
    def noop(self) -> None:
        ...

    def show_items(self,
                   items: Sequence[Union[FFItem, MediaRef]],
                   *,
                   page: Optional[int] = None,
                   view: ContentView = 'videos',
                   empty_message: Optional[str] = None,
                   alone: bool = False,
                   link: bool = False,
                   update_folder: bool = False,
                   role_format: Optional[str] = None,
                   ) -> None:
        """Show items in directory, select movie, tvshow or else."""
        # find all used types
        types = {it.ref.real_type for it in items if it}
        # only one type, view could be selected
        if len(types) == 1:
            mtype = next(iter(types))
            kwargs = {'page': page, 'alone': alone, 'empty_message': empty_message, 'link': link,
                      'role_format': role_format, 'menu': None}
            if mtype == 'movie':
                return self.movie.show_items(items, **kwargs)
            if mtype == 'show':
                return self.tvshow.show_items(items, **kwargs)
            if mtype == 'season':
                return self.tvshow.show_items(items, view='seasons', **kwargs)
            if mtype == 'episode':
                return self.tvshow.show_items(items, view='episodes', **kwargs)
            if mtype == 'person':
                return self.person.show_items(items, **kwargs)
            if mtype == 'collection':
                return self.collection.show_items(items, **kwargs)
        # no so good known type or mixed types
        pg_items = cast(PagedItemList, items)  # directory() check if items object is PagedItemList type
        count = 0
        with directory(pg_items, view=view, update=update_folder) as kdir:
            kwargs = {'alone': True, 'link': link, 'menu': None}
            for it in ffinfo.get_items(items):
                count += 1
                mtype = it.ref.type
                if role_format is not None:
                    it.role = role_format.format(it=it, item=it, ref=it.ref, index=count, title=it.title, year=it.year)
                if mtype == 'movie':
                    self.movie.show_item(kdir, it, **kwargs)
                elif mtype == 'show':
                    self.tvshow.show_item(kdir, it, **kwargs)
                elif mtype == 'person':
                    self.person.show_item(kdir, it, **kwargs)
                elif mtype == 'collection':
                    self.collection.show_item(kdir, it, **kwargs)
                else:
                    it.mode = it.Mode.Separator
                    kdir.add(it, url=kdir.no_op)
            if not count:
                kdir.no_content('sets', empty_message=empty_message)

    @subobject
    def movie(self) -> 'Movies':
        """Menu /movie."""
        from .movies import Movies
        return Movies()

    @subobject
    def tvshow(self) -> 'TVShows':
        """Menu /tvshow."""
        from .tvshows import TVShows
        return TVShows()

    @subobject
    def person(self) -> 'Persons':
        """Menu /person."""
        from .persons import Persons
        return Persons()

    @subobject
    def keyword(self) -> 'Keywords':
        """Menu /keyword."""
        from .stump import Keywords
        return Keywords()

    @subobject
    def company(self) -> 'Companies':
        """Menu /keyword."""
        from .stump import Companies
        return Companies()

    @subobject
    def collection(self) -> 'Collections':
        """Menu /collection (TMDB collections)."""
        from .collections import Collections
        return Collections()

    @subobject
    def trakt(self) -> 'TraktLists':
        """Menu /trakt (trakt lists)."""
        from .lists import TraktLists
        return TraktLists()

    @subobject
    def tmdb(self) -> 'TmdbLists':
        """Menu /tmdb (tmdb lists)."""
        from .lists import TmdbLists
        return TmdbLists()

    @subobject
    def imdb(self) -> 'ImdbLists':
        """Menu /imdb (imdb lists)."""
        from .lists import ImdbLists
        return ImdbLists()

    @subobject
    def tools(self) -> 'Tools':
        """Menu /tools."""
        from .tools import Tools
        return Tools()


# singleton
nav = Navigator()


# class navigator:

#     def root(self):
#         self.add_dir_item(
#             32001, "movieNavigator", thumb="movies.png", icon="DefaultMovies.png"
#         )
#         self.add_dir_item(32002, "tvNavigator", thumb="tvshows.png", icon="DefaultTVShows.png")

#         self.add_dir_item(
#             32008, "toolNavigator", thumb="tools.png", icon="DefaultAddonProgram.png"
#         )

#         downloads = (control.settings.getBool("downloads")
#                      and (len(control.listDir(control.settings.getString("movie.download.path"))[0]) > 0
#                           or len(control.listDir(control.settings.getString("tv.download.path"))[0]) > 0))
#         if downloads:
#             self.add_dir_item(
#                 32009, "downloadNavigator", thumb="downloads.png", icon="DefaultFolder.png"
#             )

#         self.add_dir_item(
#             32010, "searchNavigator", thumb="search.png", icon="DefaultFolder.png"
#         )

#         self.endDirectory()

#     def movies(self):
#         self.add_dir_item(32010, "movieSearch", thumb="search.png", icon="DefaultMovies.png")
#         if trakt.credentials() or imdbCredentials or tmdbCredentials:
#             self.add_dir_item(32003, "mymovieNavigator", thumb="mymovies.png", icon="DefaultVideoPlaylists.png")
#         if trakt.credentials():
#             self.add_dir_item(32801, "moviestoresume", thumb="mymovies.png", icon="DefaultVideoPlaylists.png")
#         self.add_dir_item(32017, "movies&url=trending",
#                           thumb="people-watching.png", icon="DefaultRecentlyAddedMovies.png")
#         self.add_dir_item(32018, "movies&url=tmdb_popular", thumb="most-popular.png", icon="DefaultMovies.png")
#         self.add_dir_item(32019, "movies&url=tmdb_toprated", thumb="most-voted.png", icon="DefaultMovies.png")
#         self.add_dir_item(32011, "movieGenres", thumb="genres.png", icon="DefaultMovies.png")
#         self.add_dir_item(32005, "movies&url=tmdb_new", thumb="latest-movies.png", icon="DefaultRecentlyAddedMovies.png")
#         self.add_dir_item(32022, "movies&url=tmbd_cinema",
#                           thumb="in-theaters.png", icon="DefaultRecentlyAddedMovies.png")
#         self.add_dir_item(32007, "channels", thumb="calendar.png", icon="DefaultMovies.png")
#         self.add_dir_item(32020, "movies&url=boxoffice", thumb="box-office.png", icon="DefaultMovies.png")
#         self.add_dir_item(32012, "movieYears", thumb="years.png", icon="DefaultMovies.png")
#         self.add_dir_item(32014, "movieLanguages", thumb="languages.png", icon="DefaultMovies.png")
#         self.add_dir_item(30104, "movieCountries", thumb="country.png", icon="DefaultMovies.png")
#         self.add_dir_item(32631, "moviesAwards", thumb="awards.png", icon="DefaultMovies.png")
#         self.endDirectory()

#     def mymovies(self):
#         self.accountCheck()

#         if trakt.credentials():
#             self.add_dir_item(
#                 32032,
#                 "movies&url=traktcollection",
#                 thumb="trakt.png",
#                 icon="DefaultMovies.png",
#                 queue=True,
#                 context=(32551, "moviesToLibrary&url=traktcollection"),
#             )
#             self.add_dir_item(
#                 32033,
#                 "movies&url=traktwatchlist",
#                 thumb="trakt.png",
#                 icon="DefaultMovies.png",
#                 queue=True,
#                 context=(32551, "moviesToLibrary&url=traktwatchlist"),
#             )
#             self.add_dir_item(
#                 32035,
#                 "movies&url=traktfeatured",
#                 thumb="trakt.png",
#                 icon="DefaultMovies.png",
#                 queue=True,
#             )
#             self.add_dir_item(
#                 32036,
#                 "movies&url=trakthistory",
#                 thumb="trakt.png",
#                 icon="DefaultMovies.png",
#                 queue=True,
#             )

#         if tmdbCredentials:
#             self.add_dir_item(
#                 32802,
#                 "movies&url=tmdbuserwatchlist",
#                 thumb="tmdb.png",
#                 icon="DefaultMovies.png",
#                 queue=True,
#                 context=(32551, "moviesToLibrary&url=tmdbuserwatchlist"),
#             )
#             self.add_dir_item(
#                 32803,
#                 "movies&url=tmdbuserfavourite",
#                 thumb="tmdb.png",
#                 icon="DefaultMovies.png",
#                 queue=True,
#                 context=(32551, "moviesToLibrary&url=tmdbuserfavourite"),
#             )

#         if imdbCredentials:
#             self.add_dir_item(
#                 32804,
#                 "movies&url=imdbwatchlist",
#                 thumb="imdb.png",
#                 icon="DefaultMovies.png",
#                 queue=True,
#                 context=(32551, "moviesToLibrary&url=imdbwatchlist"),
#             )

#         self.add_dir_item(
#             32039, "movieUserlists", thumb="userlists.png", icon="DefaultMovies.png"
#         )

#         self.endDirectory()

#     def tvshows(self):
#         self.add_dir_item(32010, "tvSearch", thumb="search.png", icon="DefaultTVShows.png")
#         if trakt.credentials() or imdbCredentials or tmdbCredentials:
#             self.add_dir_item(32004, "mytvNavigator", thumb="mytvshows.png", icon="DefaultVideoPlaylists.png")
#         if trakt.credentials():
#             self.add_dir_item(32805, "episodestoresume", thumb="mytvshows.png", icon="DefaultVideoPlaylists.png")
#         self.add_dir_item(32017, "tvshows&url=trending", thumb="people-watching.png", icon="DefaultRecentlyAddedEpisodes.png")
#         self.add_dir_item(32018, "tvshows&url=tmdb_popular", thumb="most-popular.png", icon="DefaultMovies.png")
#         self.add_dir_item(32019, "tvshows&url=tmdb_toprated", thumb="most-voted.png", icon="DefaultMovies.png")
#         self.add_dir_item(32024, "tvshows&url=tmbd_airing", thumb="airing-today.png", icon="DefaultTVShows.png")
#         self.add_dir_item(32026, "tvshows&url=tmdb_premiere", thumb="new-tvshows.png", icon="DefaultTVShows.png")
#         self.add_dir_item(32011, "tvGenres", thumb="genres.png", icon="DefaultTVShows.png")
#         self.add_dir_item(32016, "tvNetworks", thumb="networks.png", icon="DefaultTVShows.png")
#         self.add_dir_item(32012, "tvYears", thumb="years.png", icon="DefaultTVShows.png")
#         self.add_dir_item(32014, "tvLanguages", thumb="languages.png", icon="DefaultTVShows.png")
#         self.add_dir_item(30104, "tvCountries", thumb="country.png", icon="DefaultTVShows.png")
#         self.endDirectory()

#     def mytvshows(self):
#         self.accountCheck()

#         if trakt.credentials():
#             self.add_dir_item(
#                 32032,
#                 "tvshows&url=traktcollection",
#                 thumb="trakt.png",
#                 icon="DefaultTVShows.png",
#                 context=(32551, "tvshowsToLibrary&url=traktcollection"),
#             )
#             self.add_dir_item(
#                 32033,
#                 "tvshows&url=traktwatchlist",
#                 thumb="trakt.png",
#                 icon="DefaultTVShows.png",
#                 context=(32551, "tvshowsToLibrary&url=traktwatchlist"),
#             )
#             self.add_dir_item(
#                 32035, "tvshows&url=traktfeatured", thumb="trakt.png", icon="DefaultTVShows.png"
#             )
#             self.add_dir_item(
#                 32036,
#                 "calendar&url=trakthistory",
#                 thumb="trakt.png",
#                 icon="DefaultTVShows.png",
#                 queue=True,
#             )
#             self.add_dir_item(
#                 32037,
#                 "calendar&url=progress",
#                 thumb="trakt.png",
#                 icon="DefaultRecentlyAddedEpisodes.png",
#                 queue=True,
#             )
#             self.add_dir_item(
#                 32038,
#                 "calendar&url=mycalendar",
#                 thumb="trakt.png",
#                 icon="DefaultRecentlyAddedEpisodes.png",
#                 queue=True,
#             )

#         if tmdbCredentials:
#             self.add_dir_item(
#                 32802,
#                 "tvshows&url=tmdbuserwatchlist",
#                 thumb="tmdb.png",
#                 icon="DefaultMovies.png",
#                 queue=True,
#                 context=(32551, "tvshowsToLibrary&url=tmdbuserwatchlist"),
#             )
#             self.add_dir_item(
#                 32803,
#                 "tvshows&url=tmdbuserfavourite",
#                 thumb="tmdb.png",
#                 icon="DefaultMovies.png",
#                 queue=True,
#                 context=(32551, "tvshowsToLibrary&url=tmdbuserfavourite"),
#             )
#         if imdbCredentials:
#             self.add_dir_item(
#                 32804,
#                 "tvshows&url=imdbwatchlist",
#                 thumb="imdb.png",
#                 icon="DefaultTVShows.png",
#                 queue=True,
#                 context=(32551, "tvshowsToLibrary&url=imdbwatchlist"),
#             )

#         self.add_dir_item(32040, "tvUserlists", thumb="userlists.png", icon="DefaultTVShows.png")
#         if trakt.credentials():
#             self.add_dir_item(32041, "episodeUserlists", thumb="userlists.png", icon="DefaultTVShows.png")
#         self.endDirectory()

#     def tools(self):
#         # WIELKIE PORZĄDKI - wywalenie skrótów do ustawień, zostawienie biblioteki i konserwacji
#         self.add_dir_item(
#             32806,
#             "openSettings",
#             thumb="tools.png",
#             icon="",
#             isFolder=False,
#         )
#         self.add_dir_item(
#             32556, "libraryNavigator", thumb="tools.png", icon="DefaultAddonProgram.png"
#         )
#         self.add_dir_item(
#             32049, "viewsNavigator", thumb="tools.png", icon="DefaultAddonProgram.png", isFolder=False
#         )
#         self.add_dir_item(
#             32052, "cacheNavigator", thumb="tools.png", icon="DefaultAddonProgram.png"
#         )

#         self.add_dir_item(
#             32640,
#             "clearViews",
#             thumb="tools.png",
#             icon="",
#             isFolder=False,
#         )

#         if trakt.credentials():
#             self.add_dir_item(L("[B]TRAKT[/B]: Disconnect"), path="trakt/unauth", thumb="trakt.png", icon="",
#                                   isFolder=False)
#         else:
#             self.add_dir_item(32073, path="trakt/auth", thumb="trakt.png", icon="", isFolder=False)

#         control.addItem(handle=control.syshandle, url=f"{control.sysaddon}/xxx", listitem=ListItem('[X] test'), isFolder=False)
#         self.endDirectory()

#     def cache(self):
#         self.add_dir_item(
#             32807,
#             "clearCacheBookmarks",
#             thumb="tools.png",
#             icon="",
#             isFolder=False,
#         )
#         self.add_dir_item(
#             32052,
#             "clearCache",
#             thumb="tools.png",
#             icon="",
#             isFolder=False,
#         )
#         self.add_dir_item(
#             32639,
#             "clearCacheMeta",
#             thumb="tools.png",
#             icon="",
#             isFolder=False,
#         )

#         self.add_dir_item(
#             32795,
#             "clearCachedSources",
#             thumb="tools.png",
#             icon="",
#             isFolder=False,
#         )
#         self.add_dir_item(
#             32792,
#             "clearCacheProviders",
#             thumb="tools.png",
#             icon="",
#             isFolder=False,
#         )
#         self.add_dir_item(
#             32604,
#             "clearCacheSearch",
#             thumb="tools.png",
#             icon="",
#             isFolder=False,
#         )
#         self.add_dir_item(
#             32794,
#             "clearCacheAll",
#             thumb="tools.png",
#             icon="",
#             isFolder=False,
#         )

#         self.endDirectory()

#     def library(self):
#         self.add_dir_item(
#             32558,
#             "updateLibrary&query=tool",
#             thumb="library_update.png",
#             icon="DefaultAddonProgram.png",
#             isFolder=False
#         )
#         self.add_dir_item(
#             32559,
#             url=control.settings.getString("library.movie"),
#             thumb="movies.png",
#             icon="DefaultMovies.png",
#         )
#         self.add_dir_item(
#             32560,
#             url=control.settings.getString("library.tv"),
#             thumb="tvshows.png",
#             icon="DefaultTVShows.png",
#         )

#         if trakt.credentials():
#             self.add_dir_item(
#                 32561,
#                 "moviesToLibrary&url=traktcollection",
#                 thumb="trakt.png",
#                 icon="DefaultMovies.png",
#                 isFolder=False
#             )
#             self.add_dir_item(
#                 32562,
#                 "moviesToLibrary&url=traktwatchlist",
#                 thumb="trakt.png",
#                 icon="DefaultMovies.png",
#                 isFolder=False
#             )
#             self.add_dir_item(
#                 32563,
#                 "tvshowsToLibrary&url=traktcollection",
#                 thumb="trakt.png",
#                 icon="DefaultTVShows.png",
#                 isFolder=False
#             )
#             self.add_dir_item(
#                 32564,
#                 "tvshowsToLibrary&url=traktwatchlist",
#                 thumb="trakt.png",
#                 icon="DefaultTVShows.png",
#                 isFolder=False
#             )

#         self.endDirectory()

#     def downloads(self):
#         movie_downloads = control.settings.getString("movie.download.path")
#         tv_downloads = control.settings.getString("tv.download.path")

#         if len(control.listDir(movie_downloads)[0]) > 0:
#             self.add_dir_item(
#                 32001,
#                 url=movie_downloads,
#                 thumb="movies.png",
#                 icon="DefaultMovies.png",
#             )
#         if len(control.listDir(tv_downloads)[0]) > 0:
#             self.add_dir_item(32002, url=tv_downloads, thumb="tvshows.png", icon="DefaultTVShows.png")

#         # self.add_dir_item( # TODO Menadzer do zrobienia
#         #     32808,
#         #     "downloadManager",
#         #     "downloads.png",
#         #     "DefaultFolder.png",
#         #     isFolder=False
#         # )

#         self.endDirectory()

#     def search(self):  # DODANIE ALL
#         self.add_dir_item(32001, "movieSearch", thumb="search.png", icon="DefaultMovies.png")
#         self.add_dir_item(32002, "tvSearch", thumb="search.png", icon="DefaultTVShows.png")
#         self.add_dir_item(32029, "moviePerson", thumb="people-search.png", icon="DefaultMovies.png")
#         self.add_dir_item(32030, "tvPerson", thumb="people-search.png", icon="DefaultTVShows.png")

#         control.content(control.syshandle, "addons")
#         control.directory(control.syshandle, cacheToDisc=const.folder.cache_to_disc)

#     def views(self):
#         try:
#             items = [
#                 (control.lang(32001), "movies"),
#                 (control.lang(32002), "tvshows"),
#                 (control.lang(32054), "seasons"),
#                 (control.lang(32038), "episodes"),
#             ]

#             select = control.selectDialog(
#                 [i[0] for i in items], control.lang(32049)
#             )

#             if select == -1:
#                 return

#             content = items[select][1]

#             title = control.lang(32059)
#             url = "{}?action=addView&content={}".format(control.sysaddon, content)

#             poster, banner, fanart = (
#                 control.addonPoster(),
#                 control.addonBanner(),
#                 control.addonFanart(),
#             )

#             item = control.item(label=title)
#             item.setInfo(type="Video", infoLabels={"title": title})
#             item.setArt(
#                 {"icon": poster, "thumb": poster, "poster": poster, "banner": banner}
#             )
#             item.setProperty("Fanart_Image", fanart)

#             control.addItem(
#                 handle=control.syshandle, url=url, listitem=item, isFolder=False
#             )
#             control.content(control.syshandle, content)
#             control.directory(control.syshandle, cacheToDisc=const.folder.cache_to_disc)

#             from lib.ff import views

#             views.setView(content, {})
#         except:
#             return

#     def accountCheck(self):
#         if not trakt.credentials() and not imdbCredentials and not tmdbCredentials:
#             control.infoDialog(control.lang(32042), sound=True, icon="WARNING")
#             sys.exit()  # XXX ???

#     def clearCache(self):
#         yes = control.yesnoDialog(control.lang(32056))
#         if not yes:
#             return
#         from lib.ff import cache
#         control.execute("ActivateWindow(busydialognocancel)")

#         cache.cache_clear()
#         control.infoDialog(control.lang(32057), sound=True)

#     def clearCacheMeta(self):
#         yes = control.yesnoDialog(control.lang(32056))
#         if not yes:
#             return
#         from lib.ff import cache
#         control.execute("ActivateWindow(busydialognocancel)")

#         cache.cache_clear_meta()
#         control.infoDialog(control.lang(32057), sound=True)

#     def clearCachedSources(self):
#         yes = control.yesnoDialog(control.lang(32056))
#         if not yes:
#             return
#         from lib.ff import cache
#         control.execute("ActivateWindow(busydialognocancel)")

#         cache.cache_clear_sources()
#         control.infoDialog(control.lang(32057), sound=True)

#     def clearCacheBookmarks(self):
#         yes = control.yesnoDialog(control.lang(32056))
#         if not yes:
#             return
#         from lib.ff import cache
#         control.execute("ActivateWindow(busydialognocancel)")

#         cache.cache_clear_bookmarks()
#         control.infoDialog(control.lang(32057), sound=True)

#     def clearCacheProviders(self):
#         yes = control.yesnoDialog(control.lang(32056))
#         if not yes:
#             return
#         from lib.ff import cache
#         control.execute("ActivateWindow(busydialognocancel)")

#         cache.cache_clear_providers()
#         control.infoDialog(control.lang(32057), sound=True)

#     def clearCacheSearch(self):
#         yes = control.yesnoDialog(control.lang(32056))
#         if not yes:
#             return
#         from lib.ff import cache
#         control.execute("ActivateWindow(busydialognocancel)")

#         cache.cache_clear_search()
#         control.infoDialog(control.lang(32057), sound=True)

#     def removeFromSearchHistory(self, term):
#         yes = control.yesnoDialog(control.lang(32056))
#         if not yes:
#             return
#         from lib.ff import cache
#         control.execute("ActivateWindow(busydialognocancel)")

#         cache.cache_clear_search_by_term(term)
#         control.infoDialog(control.lang(32057), sound=True)

#     def clearCacheView(self):
#         yes = control.yesnoDialog(control.lang(32056))
#         if not yes:
#             return
#         from lib.ff import cache
#         control.execute("ActivateWindow(busydialognocancel)")

#         cache.cache_clear_view()
#         control.infoDialog(control.lang(32057), sound=True)

#     def clearCacheAll(self):
#         yes = control.yesnoDialog(control.lang(32056))
#         if not yes:
#             return
#         from lib.ff import cache
#         control.execute("ActivateWindow(busydialognocancel)")

#         cache.cache_clear_all()
#         control.infoDialog(control.lang(32057), sound=True)

#     @classmethod
#     def add_dir_item(
#         cls,
#         name: str,                     # item name (label)
#         action: Optional[str] = None,  # query action if `url` is None)
#         *,
#         url: Optional[str] = None,     # URL, if not None, `path` and `action` are ignored
#         path: Optional[str] = None,    # query path if `url` is None)
#         thumb: str,
#         icon: str,
#         context=None,
#         queue: bool = False,
#         isFolder: bool = True,
#     ):
#         name = control.lang(name)
#         if url is None:
#             if action is None:
#                 url = f"{control.sysaddon}{path or ''}"
#             else:
#                 url = f"{control.sysaddon}{path or ''}?action={action}"
#         if "://" not in thumb:
#             thumb = os.path.join(artPath, thumb) if artPath is not None else icon
#         cm = []
#         if queue:
#             cm.append((queueMenu, "RunPlugin(%s?action=queueItem)" % control.sysaddon))
#         if context is not None:
#             try:
#                 cm.append(
#                     (
#                         control.lang(context[0]),
#                         "RunPlugin({}?action={})".format(control.sysaddon, context[1]),
#                     )
#                 )
#             except IndexError:
#                 cm.append(
#                     (
#                         context[0],
#                         "RunPlugin({}?action={})".format(control.sysaddon, context[1]),
#                     )
#                 )
#         if const.debug.crash_menu:
#             cm.append(('CRASH', f'RunPlugin({control.sysaddon}?action=crash)'))
#             # cm.append(('TRAKT playback sync', f'RunPlugin({control.sysaddon}dev/trakt/playback/sync)'))
#         item = control.item(label=name)
#         item.addContextMenuItems(cm)
#         item.setArt({"icon": icon, "thumb": thumb})
#         if addonFanart is not None:
#             item.setProperty("Fanart_Image", addonFanart)
#         control.addItem(handle=control.syshandle, url=url, listitem=item, isFolder=isFolder)

#     addDirectoryItem = add_dir_item  # TODO: remove

#     @classmethod
#     def endDirectory(cls):
#         control.content(control.syshandle, "addons")
#         control.directory(control.syshandle, cacheToDisc=const.folder.cache_to_disc)
