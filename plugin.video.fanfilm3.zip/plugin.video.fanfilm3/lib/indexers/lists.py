
from typing import Optional, Union, Any, Sequence, Iterator, ClassVar

from .core import Indexer
from .navigator import nav
from ..ff.routing import route, url_for, RouteObject, PathArg
from ..ff.menu import directory, ContentView
from ..ff.item import FFItem
from ..ff.info import ffinfo
from ..ff.trakt2 import trakt
from ..ff.tmdb import tmdb
from ..ff.calendar import fromisoformat
from ..api.trakt import UserListType, UserGeneralListType as TraktUserGeneralListType
from ..api.tmdb import UserGeneralListType as TmdbUserGeneralListType
from ..defs import RefType, MainMediaType, MainMediaTypeList, Pagina, ItemList
from ..kolang import L
from const import const


# ----- Trakt -----


class TraktLists(RouteObject, Indexer):

    # Fale user name for official list.
    OFFICIAL: ClassVar[str] = '-'

    @route('/')
    def home(self) -> None:
        """User Trakt lists."""
        with directory(view='sets') as kdir:
            kdir.folder(L(30144, 'Likes'), url_for(self.likes), thumb='highly-rated.png')
            kdir.folder(L(30145, 'Collections'), self.collections)
            kdir.folder(L(32036, 'History'), url_for(self.ulist, list_type='history'))
            kdir.folder(L(32033, 'Watchlist'), url_for(self.ulist, list_type='watchlist', sort='added,asc'))
            kdir.folder(L(30146, 'Favorites'), url_for(self.ulist, list_type='favorites'))
            kdir.folder(L(30131, 'Recommendations'), self.recommendations)
            kdir.folder(L(30147, 'Trending Lists'), url_for(self.user_general, list_type='trending'), thumb='people-watching.png')
            kdir.folder(L(30148, 'Popular Lists'), url_for(self.user_general, list_type='popular'), thumb='most-popular.png')
            kdir.folder(L(30149, 'My Lists'), self.mine, thumb='userlists.png')

    @route
    def collections(self) -> None:
        """Trakt collection sub-menu."""
        with directory(view='sets') as kdir:
            if const.indexer.trakt.collection.mixed:
                kdir.folder(L(30150, 'Mixed Collections'), self.collection)
            kdir.folder(L(30151, 'Movie Collections'), url_for(self.collection, media_type='movie'))
            kdir.folder(L(30152, 'TV Show Collections'), url_for(self.collection, media_type='show'))

    @route
    def recommendations(self) -> None:
        """Trakt recommendations sub-menu."""
        with directory(view='sets') as kdir:
            if const.indexer.trakt.recommendation.mixed:
                kdir.folder(L(30153, 'Mixed Recommendations'), self.recommendation)
            kdir.folder(L(30154, 'Movie Recommendations'), url_for(self.recommendation, media_type='movie'))
            kdir.folder(L(30155, 'TV Show Recommendations'), url_for(self.recommendation, media_type='show'))

    @route
    def mine(self, *, page: PathArg[int] = 1, user: str = 'me', media_type: Optional[MainMediaType] = None):
        """Show my lists and my likes."""
        likes = trakt.user_list('likes', page=page, limit=100)
        with directory(likes, view=const.indexer.trakt.mine.view) as kdir:
            kwargs = {} if media_type is None else {'media_type': media_type}
            # user lists
            if page == 1:
                for it in trakt.user_lists():
                    kdir.add(it, url=url_for(self.user_list, list_id=it.dbid, **kwargs), thumb='userlists.png')
            # user likes
            for it in likes:
                kdir.add(it, url=url_for(self.user_list, list_id=it.vtag.getUniqueID('trakt.list'),
                                         user=it.vtag.getUniqueID('trakt.user') or self.OFFICIAL, **kwargs))

            # test sortowania
            from xbmcplugin import addSortMethod, SORT_METHOD_LABEL
            addSortMethod(kdir.handle, SORT_METHOD_LABEL, '%L')

    @route
    def likes(self, *, page: PathArg[int] = 1, user: str = 'me') -> None:
        """User Trakt generic user lists (likes etc.)."""
        with directory(view='sets') as kdir:
            for it in trakt.user_list('likes'):
                kdir.add(it, url=url_for(self.user_list, list_id=it.vtag.getUniqueID('trakt.list'),
                                         user=it.vtag.getUniqueID('trakt.user') or self.OFFICIAL))

    @route
    def collection(self,
                   media_type: PathArg[MainMediaTypeList] = 'movie,show',
                   *,
                   page: PathArg[int] = 1,
                   user: str = 'me',
                   ) -> None:
        """User Trakt generic user lists (likes etc.)."""
        limit = const.trakt.page.limit  # items per page
        items = trakt.user_collection(media_type, user=user, chunk=limit//2)
        paged = Pagina(items, page=page, limit=limit)
        nav.show_items(paged)

    @route
    def recommendation(self, media_type: PathArg[MainMediaTypeList] = 'movie,show', *, page: PathArg[int] = 1) -> None:
        """User Trakt generic user lists (likes etc.)."""
        limit = const.trakt.page.limit  # items per page
        items = trakt.recommendations(media_type, limit=100, chunk=limit//2)  # limit=100 max recommendations (many pages)
        paged = Pagina(items, page=page, limit=limit)
        nav.show_items(paged)

    @route('/{list_type}')
    def ulist(self,
              list_type: UserListType,
              *,
              page: PathArg[int] = 1,
              media_type: Optional[RefType] = None,
              user: str = 'me',
              sort: Optional[str] = None,
              ) -> None:
        """User Trakt generic user lists (likes etc.)."""
        items = trakt.user_list(list_type, media_type=media_type, sort=sort, page=page, user=user)
        if fmt := const.indexer.trakt.lists.watched_date_format:
            for it in items:
                if (val := it.vtag.getLastPlayedAsW3C()) and (date := fromisoformat(val)).year > 1970:
                    it.role = f'{date:{fmt}}'
        nav.show_items(items, alone=True)

    @route('/list/{user}/{list_id}')
    def user_list(self, list_id: str, *,
                  page: PathArg[int] = 1, user: str = 'me', media_type: Optional[MainMediaType] = None) -> None:
        """Show TMDB user list."""
        if not user or user == self.OFFICIAL:
            items = trakt.the_list(list_id, page=page, media_type=media_type)
        else:
            items = trakt.user_list_items(list_id, user=user, page=page, media_type=media_type)
        nav.show_items(items, page=page)

    @route('/{list_type}')
    def user_general(self, list_type: TraktUserGeneralListType, *, page: PathArg[int] = 1) -> None:
        items = trakt.user_general_lists(list_type, page=page)
        with directory(items, view='sets') as kdir:
            for it in items:
                kdir.add(it, url=url_for(self.user_list, list_id=it.vtag.getUniqueID('trakt.list'),
                                         user=it.vtag.getUniqueID('trakt.user') or self.OFFICIAL))

    @route('/progress')
    def shows_progress(self, *, page: PathArg[int] = 1, user: str = 'me') -> None:
        """List of watched shows with theirs progress."""

        def get_next(items: Sequence[FFItem]) -> Iterator[FFItem]:
            for it in items:
                ffinfo.find_last_next_episodes(it)
                if it.progress and (nxt := it.progress.next_episode):
                    # TODO: make a discussion if it is necessary  (show progress mark on next episode)
                    # nxt.progress = it.progress  # ???
                    nxt.descr_style = ffinfo.progress_descr_style(it.progress)
                    yield it

        preselect = False
        watched = trakt.user_list('watched', media_type='show')
        if size := const.indexer.trakt.progress.shows_page_size:
            if preselect := (size and const.indexer.trakt.progress.shows_page_size_exact_match):
                watched = Pagina(get_next(ffinfo.get_en_skel_items(watched)), page=page, limit=size)
            else:
                watched = Pagina(watched, page=page, limit=size)
        items = ffinfo.get_items(watched, tv_episodes=True, progress=ffinfo.Progress.NO)  # w/o progress, the progress will recounted
        if not preselect:
            items = get_next(items)
        paged = ItemList([it.progress.next_episode
                          for it in items if it and it.progress is not None and it.progress.next_episode],
                         page=page, total_pages=watched.total_pages)
        nav.show_items(paged, page=page, alone=True, link=const.indexer.tvshows.progress.episode_folder)


# -----  TMDB  -----


class TmdbLists(RouteObject, Indexer):

    @route('/')
    def home(self) -> None:
        """User TMDB lists."""
        with directory(view='sets') as kdir:
            kdir.folder(L(30146, 'Favorites'), self.favorites, thumb='DefaultMovies.png')
            kdir.folder(L(32033, 'Watchlist'), self.watchlists, thumb='DefaultMovies.png')
            kdir.folder(L(30149, 'My Lists'), self.mine, thumb='userlists.png')

    @route
    def favorites(self) -> None:
        with directory(view='sets') as kdir:
            if const.indexer.tmdb.favorite.mixed:
                kdir.folder(L(30156, 'Mixed Favorites'), self.favorite, thumb='DefaultMovies.png')
            kdir.folder(L(30157, 'Favorite Movies'), url_for(self.favorite, media_type='movie'), thumb='DefaultMovies.png')
            kdir.folder(L(30158, 'Favorite TV Shows'), url_for(self.favorite, media_type='show'), thumb='DefaultTVShows.png')

    @route
    def watchlists(self) -> None:
        with directory(view='sets') as kdir:
            if const.indexer.tmdb.watchlist.mixed:
                kdir.folder(L(30159, 'Mixed Watchlist'), self.watchlist, thumb='DefaultMovies.png')
            kdir.folder(L(30160, 'Watchlist Movies'), url_for(self.watchlist, media_type='movie'), thumb='DefaultMovies.png')
            kdir.folder(L(30161, 'Watchlist TV Shows'), url_for(self.watchlist, media_type='show'), thumb='DefaultTVShows.png')

    @route
    def mine(self, *, page: PathArg[int] = 1, media_type: Optional[MainMediaType] = None) -> None:
        """User TMDB lists."""
        with directory(view=const.indexer.trakt.mine.view) as kdir:
            kwargs = {} if media_type is None else {'media_type': media_type}
            for it in tmdb.user_lists(page=page):
                kdir.add(it, url=url_for(self.user_list, list_id=it.dbid, **kwargs))

            # test sortowania
            from xbmcplugin import addSortMethod, SORT_METHOD_LABEL
            addSortMethod(kdir.handle, SORT_METHOD_LABEL, '%L')

    @route('/list/{list_id}')
    def user_list(self, list_id: int, *, page: PathArg[int] = 1, media_type: Optional[MainMediaType] = None) -> None:
        """Show TMDB user list."""
        items = tmdb.user_list_items(list_id, page=page)
        if media_type:
            items = items.with_content([it for it in items if it.type == media_type])
        nav.show_items(items, page=page)

    @route
    def favorite(self, media_type: PathArg[MainMediaTypeList] = 'movie,show', *, page: PathArg[int] = 1) -> None:
        """Show TMDB user list."""
        items = tmdb.user_general_lists('favorite', media_type, page=page, chunk=10)
        nav.show_items(items, page=page)

    @route
    def watchlist(self, media_type: PathArg[MainMediaTypeList] = 'movie,show', *, page: PathArg[int] = 1) -> None:
        """Show TMDB user list."""
        items = tmdb.user_general_lists('watchlist', media_type, page=page, chunk=10)
        nav.show_items(items, page=page)


# -----  IMDB  -----


class ImdbLists(RouteObject, Indexer):

    @route('/')
    def home(self) -> None:
        """User IMDB lists."""
        with directory(view='sets') as kdir:
            ...
